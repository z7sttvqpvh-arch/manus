/**
 * Browser Automation Module — Tarayici Otomasyonu
 * ================================================
 * ChatGPT ve Gemini Web arayuzlerini Puppeteer ile kontrol eder
 * - Insan gibi davranma (stealth mode)
 * - Mesaj yazma ve cevap okuma
 * - Dosya yukleme
 * - Video analizi
 */

import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import fsp from 'fs/promises';
import path from 'path';

puppeteer.use(StealthPlugin());

let browser = null;
let chatgptPage = null;
let geminiPage = null;

// --- Browser Baslatma -------------------------------------------------------
export async function initBrowser() {
  if (browser) return browser;
  try {
    browser = await puppeteer.launch({
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--single-process=false',
      ],
      defaultViewport: { width: 1280, height: 720 },
    });
    console.log('Tarayici baslatildi');
    return browser;
  } catch (e) {
    console.error('Tarayici baslatma hatasi:', e.message);
    throw e;
  }
}

// --- Browser Kapatma --------------------------------------------------------
export async function closeBrowser() {
  if (browser) {
    await browser.close();
    browser = null;
    chatgptPage = null;
    geminiPage = null;
  }
}

// --- ChatGPT Baglantisi -----------------------------------------------------
export async function connectChatGPT() {
  if (chatgptPage) return chatgptPage;
  const b = await initBrowser();
  chatgptPage = await b.newPage();
  await chatgptPage.goto('https://chatgpt.com', { waitUntil: 'networkidle2', timeout: 60000 });
  
  // Oturum acilmis mi kontrol et
  await chatgptPage.waitForTimeout(2000);
  const loggedIn = await chatgptPage.evaluate(() => {
    return !!document.querySelector('[data-testid="send-button"]') || 
           !!document.querySelector('button[aria-label*="Send"]') ||
           !!document.querySelector('textarea');
  });

  if (!loggedIn) {
    console.log('ChatGPT ye oturum acmaniz gerekiyor. Tarayici acildi, lutfen manuel olarak giris yapin.');
    console.log('   URL: https://chatgpt.com');
    console.log('   Giris yaptiktan sonra sisteme devam edebilirsiniz.');
    await chatgptPage.waitForTimeout(30000); // 30 saniye bekle
  }

  return chatgptPage;
}

// --- Gemini Web Baglantisi --------------------------------------------------
export async function connectGemini() {
  if (geminiPage) return geminiPage;
  const b = await initBrowser();
  geminiPage = await b.newPage();
  await geminiPage.goto('https://gemini.google.com', { waitUntil: 'networkidle2', timeout: 60000 });
  
  await geminiPage.waitForTimeout(2000);
  const loggedIn = await geminiPage.evaluate(() => {
    return !!document.querySelector('[aria-label*="Message"]') ||
           !!document.querySelector('textarea') ||
           !!document.querySelector('[role="textbox"]');
  });

  if (!loggedIn) {
    console.log('Gemini ye oturum acmaniz gerekiyor. Tarayici acildi, lutfen manuel olarak giris yapin.');
    console.log('   URL: https://gemini.google.com');
    console.log('   Giris yaptiktan sonra sisteme devam edebilirsiniz.');
    await geminiPage.waitForTimeout(30000);
  }

  return geminiPage;
}

// --- ChatGPT'ye Mesaj Gonder ------------------------------------------------
export async function sendMessageToChatGPT(message) {
  const page = await connectChatGPT();
  
  try {
    // Textarea'yi bul
    const textarea = await page.$('textarea');
    if (!textarea) throw new Error('ChatGPT textarea bulunamadi');

    // Mesaji yaz (insan gibi, karakter karakter)
    await textarea.click();
    await page.waitForTimeout(300);
    
    // Mesaji yapistir (daha hizli)
    await page.evaluate((msg) => {
      const ta = document.querySelector('textarea');
      if (ta) ta.value = msg;
      ta?.dispatchEvent(new Event('input', { bubbles: true }));
    }, message);

    await page.waitForTimeout(500);

    // Gonder butonunu bul ve tikla
    const sendBtn = await page.$('button[aria-label*="Send"], button[data-testid="send-button"]');
    if (!sendBtn) throw new Error('Gonder butonu bulunamadi');
    
    await sendBtn.click();
    console.log('ChatGPT ye mesaj gonderildi');

    // Cevabi bekle (max 2 dakika)
    const response = await waitForChatGPTResponse(page, 120000);
    return response;

  } catch (e) {
    console.error('ChatGPT mesaj hatasi:', e.message);
    throw e;
  }
}

// --- ChatGPT Cevabini Bekle -------------------------------------------------
async function waitForChatGPTResponse(page, timeout = 120000) {
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    // Son mesaji oku
    const lastMessage = await page.evaluate(() => {
      const msgs = Array.from(document.querySelectorAll('[data-message-id], [role="article"]'));
      if (!msgs.length) return null;
      const last = msgs[msgs.length - 1];
      return last?.innerText || last?.textContent || null;
    });

    if (lastMessage && lastMessage.length > 20) {
      console.log('ChatGPT cevabi alindi');
      return lastMessage;
    }

    await page.waitForTimeout(1000);
  }

  throw new Error('ChatGPT cevap verme timeout');
}

// --- Gemini'ye Mesaj Gonder -------------------------------------------------
export async function sendMessageToGemini(message) {
  const page = await connectGemini();
  
  try {
    // Textarea'yi bul
    const textarea = await page.$('textarea, [role="textbox"]');
    if (!textarea) throw new Error('Gemini textarea bulunamadi');

    await textarea.click();
    await page.waitForTimeout(300);

    // Mesaji yapistir
    await page.evaluate((msg) => {
      const ta = document.querySelector('textarea, [role="textbox"]');
      if (ta) {
        ta.value = msg;
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }, message);

    await page.waitForTimeout(500);

    // Gonder butonunu tikla (Enter tusu veya buton)
    await page.keyboard.press('Enter');
    console.log('Gemini ye mesaj gonderildi');

    // Cevabi bekle
    const response = await waitForGeminiResponse(page, 120000);
    return response;

  } catch (e) {
    console.error('Gemini mesaj hatasi:', e.message);
    throw e;
  }
}

// --- Gemini Cevabini Bekle --------------------------------------------------
async function waitForGeminiResponse(page, timeout = 120000) {
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    const lastMessage = await page.evaluate(() => {
      const msgs = Array.from(document.querySelectorAll('[data-message-id], [role="article"], .response-text'));
      if (!msgs.length) return null;
      const last = msgs[msgs.length - 1];
      return last?.innerText || last?.textContent || null;
    });

    if (lastMessage && lastMessage.length > 20) {
      console.log('Gemini cevabi alindi');
      return lastMessage;
    }

    await page.waitForTimeout(1000);
  }

  throw new Error('Gemini cevap verme timeout');
}

// --- Dosya Yukleme (Video Analizi icin) ----------------------------------
export async function uploadFileToGemini(filePath) {
  const page = await connectGemini();
  
  try {
    // Dosya yukleme input'unu bul
    const fileInput = await page.$('input[type="file"]');
    if (!fileInput) throw new Error('Dosya yukleme input bulunamadi');

    // Dosyayi yukle
    await fileInput.uploadFile(filePath);
    console.log('Dosya Gemini ye yuklendi');

    // Yuklemenin tamamlanmasini bekle
    await page.waitForTimeout(3000);
    return true;

  } catch (e) {
    console.error('Dosya yukleme hatasi:', e.message);
    throw e;
  }
}

// --- Icerik Uretim Prompt'u Olustur -----------------------------------------
export function generateContentPrompt(channel, topic, maxCandidates = 5) {
  return `Sen YouTube Shorts icin yuksek kalite Turkce icerik uretim motorusun.

KURALLAR:
- JSON disinda HICBIR SEY dondurme
- Ilk cumle (hook) cok guclu ve merak uyandirici olsun
- Baslik ve icerik tam uyumlu olsun
- voiceText 20-35 saniye arasinda okunabilir uzunlukta olsun (yaklasik 60-100 kelime)
- Turkce dil bilgisi mukemmel olsun
- Insan gibi, dogal konusma dili kullan

KANAL BILGISI:
- Kanal Adi: ${channel.name}
- Kategori: ${channel.category}

KONU: ${topic}

${maxCandidates} adet farkli aday uret.

JSON SEMASI (kesinlikle bu formatta):
{
  "candidates": [
    {
      "hook": "Ilk cumle - cok guclu merak uyandirici",
      "title": "YouTube basligi (max 70 karakter)",
      "firstFrameText": "Ekranda gorunecek kisa metin (max 50 karakter)",
      "voiceText": "Seslendirilecek tam metin (60-100 kelime)",
      "cta": "Sona eklenen harekete gecirici cagri",
      "thumbnailText": "Thumbnail ustundeki buyuk yazi (max 40 karakter, BUYUK HARF)",
      "description": "YouTube aciklamasi (hashtag dahil)",
      "tags": ["#tag1", "#tag2"],
      "scenePlan": [
        {"sceneType": "intro|body|end", "intent": "hook|explain|cta", "visualQuery": "gorsel arama terimi", "durationHint": 5}
      ]
    }
  ]
}`;
}

// --- Video Viral Analizi Prompt'u --------------------------------------------
export function generateVideoAnalysisPrompt() {
  return `Bu YouTube Shorts videosunu analiz et ve asagidaki sorulara cevap ver:

1. **Viral Potansiyeli (0-100):** Bu video viral olma ihtimali nedir? Neden?

2. **Hook Etkisi:** Ilk 3 saniye yeterince guclu mu? Izleyiciyi cekiyor mu?

3. **Tutma Analizi:** 
   - Hangi saniyede izleyici sikilmaya baslayabilir?
   - Hangi bolumler en ilgi cekici?
   - Hangi bolumler kesilebilir?

4. **Thumbnail & Baslik:** Baslik ve gorsel merak uyandiriyor mu?

5. **CTA (Call-to-Action):** Son mesaj yeterince guclu mu?

6. **Iyilestirme Onerileri:** 
   - Neleri degistirmeliyiz?
   - Hangi kisimlar daha uzun olmali?
   - Hangi kisimlar daha kisa olmali?

7. **Hedef Kitle:** Bu video hangi yas grubu/demografiye hitap ediyor?

8. **Psikolojik Tetikleyiciler:** Hangi psikolojik mekanizmalar kullanilmis?

Cevaplarini JSON formatinda ver:
{
  "viralScore": 0-100,
  "hookStrength": "aciklama",
  "retentionAnalysis": {
    "boringPointSeconds": [3, 15, 28],
    "bestSegments": ["0-5s: hook", "10-15s: aciklama"],
    "improvementAreas": ["5-10s: daha hizli olmali"]
  },
  "thumbnailTitleScore": 0-100,
  "ctaStrength": "aciklama",
  "improvements": ["oneri 1", "oneri 2"],
  "targetAudience": "yas ve demografik",
  "psychologicalTriggers": ["tetikleyici 1", "tetikleyici 2"],
  "finalRecommendation": "genel tavsiye"
}`;
}

// --- Icerik Uretim (ChatGPT/Gemini araciligiyla) --------------------------
export async function generateContentViaAI(channel, topic, aiService = 'gemini') {
  try {
    const prompt = generateContentPrompt(channel, topic);
    let response;

    if (aiService === 'chatgpt') {
      response = await sendMessageToChatGPT(prompt);
    } else {
      response = await sendMessageToGemini(prompt);
    }

    // JSON'i cikart
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('JSON bulunamadi');

    const data = JSON.parse(jsonMatch[0]);
    const candidates = (data.candidates || []).map(c => ({
      id: `cand_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
      ...c,
    }));

    console.log(` ${candidates.length} aday uretildi`);
    return candidates;

  } catch (e) {
    console.error('Icerik uretim hatasi:', e.message);
    throw e;
  }
}

// --- Video Analizi (ChatGPT/Gemini araciligiyla) --------------------------
export async function analyzeVideoViaAI(videoPath, aiService = 'gemini') {
  try {
    const prompt = generateVideoAnalysisPrompt();
    let response;

    if (aiService === 'chatgpt') {
      // ChatGPT'ye dosya yukleme daha karmasik, simdilik sadece prompt gonder
      const msg = `Lutfen asagidaki analiz yapabilmem icin video yukleme ozelligini kullan.\n\n${prompt}`;
      response = await sendMessageToChatGPT(msg);
    } else {
      // Gemini'ye dosya yukle
      await uploadFileToGemini(videoPath);
      response = await sendMessageToGemini(prompt);
    }

    // JSON'i cikart
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Analiz JSON bulunamadi');

    const analysis = JSON.parse(jsonMatch[0]);
    console.log(' Video analizi tamamlandi');
    return analysis;

  } catch (e) {
    console.error('Video analizi hatasi:', e.message);
    throw e;
  }
}

// --- Tarayici Durumu Kontrol ------------------------------------------------
export async function getBrowserStatus() {
  return {
    browserActive: !!browser,
    chatgptConnected: !!chatgptPage,
    geminiConnected: !!geminiPage,
  };
}

// --- Tarayici Sayfasini Ac (Manuel Giris icin) ------------------------------
export async function openBrowserForManualLogin(service = 'gemini') {
  const b = await initBrowser();
  const page = await b.newPage();
  
  const url = service === 'chatgpt' ? 'https://chatgpt.com' : 'https://gemini.google.com';
  await page.goto(url, { waitUntil: 'networkidle2' });
  
  console.log(` Tarayici acildi: ${url}`);
  console.log('  Lutfen manuel olarak giris yapin ve sistem devam edecektir.');
  
  if (service === 'chatgpt') {
    chatgptPage = page;
  } else {
    geminiPage = page;
  }

  return page;
}
