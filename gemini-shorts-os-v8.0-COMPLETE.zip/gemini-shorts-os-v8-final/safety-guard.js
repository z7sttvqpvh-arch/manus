/**
 * Safety Guard — Politika Denetcisi
 * ==================================
 * Videolari "Shadow Ban" ve platform kisitlamalarina karsi koruma
 * - Yasakli kelime tespiti
 * - Telif hakki riski analizi
 * - Topluluk kurallari uygunlugu
 * - Hassas icerik uyarilari
 */

// --- Yasakli Kelimeler (YouTube/TikTok) --------------------------------------
const BANNED_KEYWORDS = {
  high_risk: [
    'olum', 'intihar', 'uyusturucu', 'haram', 'teror', 'siddet', 'cinsel istismar',
    'pedofili', 'tecavuz', 'bomba', 'silah', 'katliam', 'nefret', 'irkcilik',
    'ayrimcilik', 'kotuye kullanim', 'spam', 'dolandiricilik', 'sahte',
  ],
  medium_risk: [
    'alkol', 'sigara', 'kumar', 'borc', 'yoksulluk', 'hastalik', 'cerrahi',
    'kan', 'yaralanma', 'aci', 'korku', 'fobia', 'paranoia', 'psikoz',
  ],
  low_risk: [
    'seks', 'ciplak', 'ic camasiri', 'masoz', 'masaj', 'fantezi', 'rol oynama',
  ],
};

// --- Telif Hakki Riski Kelimeleri --------------------------------------------
const COPYRIGHT_RISK_KEYWORDS = [
  'muzik', 'sarki', 'film', 'dizi', 'oyuncu', 'yonetmen', 'produktor',
  'lisansli', 'resmi', 'orijinal', 'cover', 'remix', 'parodi',
];

// --- Hassas Konular ---------------------------------------------------------
const SENSITIVE_TOPICS = [
  'din', 'siyaset', 'secim', 'hukumet', 'devlet', 'asker', 'polis',
  'mahkeme', 'avukat', 'hukuk', 'vergi', 'gumruk', 'sinir',
];

// --- Metin Analizi (Yasakli Kelimeler) --------------------------------------
export function analyzeTextForBannedWords(text) {
  const lowerText = text.toLowerCase();
  const results = {
    high_risk: [],
    medium_risk: [],
    low_risk: [],
    totalRiskScore: 0,
  };

  // High Risk
  for (const word of BANNED_KEYWORDS.high_risk) {
    if (lowerText.includes(word)) {
      results.high_risk.push(word);
      results.totalRiskScore += 30;
    }
  }

  // Medium Risk
  for (const word of BANNED_KEYWORDS.medium_risk) {
    if (lowerText.includes(word)) {
      results.medium_risk.push(word);
      results.totalRiskScore += 15;
    }
  }

  // Low Risk
  for (const word of BANNED_KEYWORDS.low_risk) {
    if (lowerText.includes(word)) {
      results.low_risk.push(word);
      results.totalRiskScore += 5;
    }
  }

  return results;
}

// --- Telif Hakki Riski Analizi ----------------------------------------------
export function analyzeCopyrightRisk(text) {
  const lowerText = text.toLowerCase();
  const riskKeywords = [];
  let copyrightRiskScore = 0;

  for (const keyword of COPYRIGHT_RISK_KEYWORDS) {
    if (lowerText.includes(keyword)) {
      riskKeywords.push(keyword);
      copyrightRiskScore += 10;
    }
  }

  return {
    riskKeywords,
    copyrightRiskScore: Math.min(100, copyrightRiskScore),
    hasCopyrightRisk: copyrightRiskScore > 30,
    advice: copyrightRiskScore > 30 
      ? 'Telif hakki riski yuksek. Orijinal icerik kullanmaya dikkat et.'
      : 'Telif hakki riski dusuk.',
  };
}

// --- Hassas Konu Tespiti ----------------------------------------------------
export function detectSensitiveTopics(text) {
  const lowerText = text.toLowerCase();
  const detectedTopics = [];

  for (const topic of SENSITIVE_TOPICS) {
    if (lowerText.includes(topic)) {
      detectedTopics.push(topic);
    }
  }

  return {
    detectedTopics,
    hasSensitiveContent: detectedTopics.length > 0,
    advice: detectedTopics.length > 0
      ? `Hassas konular tespit edildi: ${detectedTopics.join(', ')}. Tarafsiz ve bilgilendirici tonda kaliniz.`
      : 'Hassas konu tespit edilmedi.',
  };
}

// --- Genel Guvenlik Raporu --------------------------------------------------
export function generateSafetyReport(text) {
  const bannedWords = analyzeTextForBannedWords(text);
  const copyright = analyzeCopyrightRisk(text);
  const sensitive = detectSensitiveTopics(text);

  const totalRiskScore = bannedWords.totalRiskScore + copyright.copyrightRiskScore;
  const shadowBanRisk = totalRiskScore > 50 ? 'HIGH' : totalRiskScore > 25 ? 'MEDIUM' : 'LOW';

  return {
    timestamp: new Date().toISOString(),
    textLength: text.length,
    bannedWords,
    copyright,
    sensitive,
    totalRiskScore: Math.min(100, totalRiskScore),
    shadowBanRisk,
    recommendation: getSafetyRecommendation(shadowBanRisk, bannedWords, copyright, sensitive),
    canPublish: shadowBanRisk === 'LOW' && bannedWords.high_risk.length === 0,
  };
}

// --- Guvenlik Onerisi -------------------------------------------------------
function getSafetyRecommendation(riskLevel, banned, copyright, sensitive) {
  const recommendations = [];

  if (riskLevel === 'HIGH') {
    recommendations.push('️ YUKSEK RISK: Bu video Shadow Ban yeme riski tasiyor.');
  } else if (riskLevel === 'MEDIUM') {
    recommendations.push('️ ORTA RISK: Bazi kisitlamalar yasayabilirsiniz.');
  } else {
    recommendations.push(' DUSUK RISK: Yayinlanmaya hazir.');
  }

  if (banned.high_risk.length > 0) {
    recommendations.push(`❌ Yasakli kelimeler: ${banned.high_risk.join(', ')}`);
  }

  if (banned.medium_risk.length > 0) {
    recommendations.push(`️ Riskli kelimeler: ${banned.medium_risk.join(', ')}`);
  }

  if (copyright.hasCopyrightRisk) {
    recommendations.push(`📜 ${copyright.advice}`);
  }

  if (sensitive.hasSensitiveContent) {
    recommendations.push(`🔒 ${sensitive.advice}`);
  }

  return recommendations;
}

// --- Metin Duzeltme Onerisi -------------------------------------------------
export function suggestTextFixes(text) {
  const fixes = [];
  const lowerText = text.toLowerCase();

  // Yasakli kelimeleri degistir
  for (const word of BANNED_KEYWORDS.high_risk) {
    if (lowerText.includes(word)) {
      const replacement = getAlternativeWord(word);
      fixes.push({
        original: word,
        replacement,
        reason: 'Yasakli kelime',
      });
    }
  }

  return fixes;
}

// --- Alternatif Kelime Onerisi ----------------------------------------------
function getAlternativeWord(word) {
  const alternatives = {
    'olum': 'son',
    'intihar': 'kendi hayatini bitirmek',
    'uyusturucu': 'madde',
    'haram': 'yasak',
    'teror': 'siddet eylemi',
    'siddet': 'agresif davranis',
    'cinsel istismar': 'kotuye kullanim',
    'pedofili': 'cocuk istismari',
    'tecavuz': 'cinsel saldiri',
    'bomba': 'patlayici',
    'silah': 'alet',
    'katliam': 'toplu olum',
    'nefret': 'olumsuz duygu',
    'irkcilik': 'ayrimcilik',
    'ayrimcilik': 'esitsiz muamele',
    'kotuye kullanim': 'yanlis kullanim',
    'spam': 'tekrarlayan icerik',
    'dolandiricilik': 'aldatma',
    'sahte': 'gercek olmayan',
  };

  return alternatives[word] || word;
}

// --- Gemini'ye Gonderilecek Guvenlik Sorusu ----------------------------------
export function generateSafetyCheckPrompt(text, category) {
  return `Asagidaki video aciklamasi ve basligi, YouTube/TikTok topluluk kurallarina uygun mu? 
  
Kategori: ${category}
Metin: "${text}"

Kontrol et:
1. Yasakli icerik (siddet, uyusturuc, cinsel icerik vb.) var mi?
2. Telif hakki ihlali riski var mi?
3. Nefret soylemi veya ayrimcilik var mi?
4. Yaniltici veya sahte bilgi var mi?

Cevap JSON formatinda:
{
  "isSafe": true/false,
  "risks": ["risk1", "risk2"],
  "suggestions": ["oneri1", "oneri2"],
  "shadowBanRisk": "LOW/MEDIUM/HIGH"
}

JSON disinda HICBIR SEY yazma.`;
}

// --- Guvenlik Skoru Hesapla -------------------------------------------------
export function calculateSafetyScore(report) {
  let score = 100;

  // Yasakli kelimeler
  score -= report.bannedWords.high_risk.length * 20;
  score -= report.bannedWords.medium_risk.length * 10;
  score -= report.bannedWords.low_risk.length * 5;

  // Telif hakki riski
  if (report.copyright.hasCopyrightRisk) {
    score -= 15;
  }

  // Hassas konular
  if (report.sensitive.hasSensitiveContent) {
    score -= report.sensitive.detectedTopics.length * 5;
  }

  return Math.max(0, score);
}
