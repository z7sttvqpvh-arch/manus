/**
 * Gemini Executive Shorts OS — Pro Edition
 * ==========================================
 * Gelismis YouTube Shorts otomasyon motoru
 * - Coklu Gemini API key yonetimi (round-robin + saglik takibi)
 * - Gelismis icerik puanlama ve onarim dongusu
 * - Makine ogrenmesi tabanli icerik kalite takibi
 * - TTS (Text-to-Speech) entegrasyonu
 * - FFmpeg ile profesyonel video render
 * - YouTube OAuth2 otomatik token yenileme
 * - Gercek zamanli SSE log akisi
 * - Guvenli API endpoint'leri
 * - Otomatik zamanlayici ve coklu kanal destegi
 */

import http from 'http';
import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir   = path.join(__dirname, 'public');
const dataDir     = path.join(__dirname, 'data');
const storageDir  = path.join(__dirname, 'storage');
const outputsDir  = path.join(storageDir, 'outputs');
const dbPath      = path.join(dataDir, 'db.json');
const configPath  = path.join(__dirname, 'config.json');
const logPath     = path.join(__dirname, 'logs', 'server.log');

// --- SSE istemcileri --------------------------------------------------------
const sseClients = new Set();

// --- Varsayilan veritabani semasi -------------------------------------------
const defaultDb = {
  keys: [],
  channels: [],
  jobs: [],
  settings: {
    autoMode: false,
    autoIntervalMinutes: 180,
    uploadEnabled: false,
    model: 'gemini-2.0-flash',
    targetVideoSeconds: 30,
    publishThreshold: 78,
    maxCandidates: 5,
    maxRepairRounds: 3,
    maxDailyPerChannel: 2,
    minUploadIntervalMinutes: 120,
    ttsEnabled: false,
    ttsVoice: 'tr-TR-EmelNeural',
    watermark: '',
    defaultPrivacy: 'public',
    notifyWebhook: '',
    maxJobHistory: 100,
    concurrentJobs: false,
  },
  learning: {
    badOpenings: [],
    goodPatterns: [],
    badPatterns: [],
    topicHistory: [],
    performanceLog: [],
  },
  stats: {
    totalJobs: 0,
    successJobs: 0,
    failedJobs: 0,
    totalUploads: 0,
    totalApiCalls: 0,
  }
};

// --- Boot & DB --------------------------------------------------------------
await ensureBoot();
let db = await loadDb();
const fileLocks = new Map();
let schedulerTimer = null;
let activeJobs = new Map(); // channelId -> job
ensureScheduler();

// --- Yardimci fonksiyonlar --------------------------------------------------
function uid(prefix = 'id') { return `${prefix}_${crypto.randomBytes(8).toString('hex')}`; }
function nowIso() { return new Date().toISOString(); }
function delay(ms) { return new Promise(r => setTimeout(r, ms)); }
function rand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function clamp(v, min, max) { return Math.min(max, Math.max(min, v)); }

async function ensureBoot() {
  const dirs = [
    dataDir, outputsDir,
    path.join(storageDir, 'temp'),
    path.join(storageDir, 'audio'),
    path.join(storageDir, 'thumbnails'),
    path.join(storageDir, 'backgrounds'),
    path.join(storageDir, 'subtitles'),
    path.join(__dirname, 'logs'),
  ];
  for (const d of dirs) await fsp.mkdir(d, { recursive: true });
  try { await fsp.access(dbPath); } catch {
    await fsp.writeFile(dbPath, JSON.stringify(defaultDb, null, 2));
  }
  try { await fsp.access(configPath); } catch {
    await fsp.writeFile(configPath, JSON.stringify({
      port: 3001,
      model: 'gemini-2.0-flash',
      autoMode: false,
      autoIntervalMinutes: 180,
      maxCandidates: 5,
      maxRepairRounds: 3,
      publishThreshold: 78,
      targetVideoSeconds: 30,
      uploadEnabled: false,
      maxDailyPerChannel: 2,
      minUploadIntervalMinutes: 120,
    }, null, 2));
  }
}

async function loadDb() {
  let cfg = {};
  try { cfg = JSON.parse(await fsp.readFile(configPath, 'utf8')); } catch {}
  let raw = { ...defaultDb };
  try { raw = JSON.parse(await fsp.readFile(dbPath, 'utf8')); } catch {}
  raw.settings  = { ...defaultDb.settings, ...cfg, ...(raw.settings || {}) };
  raw.keys      = raw.keys || [];
  raw.channels  = raw.channels || [];
  raw.jobs      = raw.jobs || [];
  raw.learning  = { ...defaultDb.learning, ...(raw.learning || {}) };
  raw.stats     = { ...defaultDb.stats, ...(raw.stats || {}) };
  return raw;
}

async function saveDb() {
  while (fileLocks.get('db')) await delay(10);
  fileLocks.set('db', true);
  try {
    await fsp.writeFile(dbPath, JSON.stringify(db, null, 2));
  } finally {
    fileLocks.delete('db');
  }
}

// --- Loglama & SSE ----------------------------------------------------------
async function log(msg, level = 'info') {
  const line = `[${nowIso()}] [${level.toUpperCase()}] ${msg}\n`;
  await fsp.appendFile(logPath, line).catch(() => {});
  if (level !== 'debug') console.log(`[${level.toUpperCase()}] ${msg}`);
  broadcastSSE({ type: 'log', level, msg, ts: nowIso() });
}

function broadcastSSE(data) {
  const payload = `data: ${JSON.stringify(data)}\n\n`;
  for (const res of sseClients) {
    try { res.write(payload); } catch { sseClients.delete(res); }
  }
}

// --- HTTP yardimcilari -------------------------------------------------------
function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  });
  res.end(body);
}

async function parseBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > 10e6) { req.destroy(); reject(new Error('Body too large')); }
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

function serveFile(res, filePath, contentType = 'text/html; charset=utf-8') {
  fs.readFile(filePath, (err, data) => {
    if (err) return sendJson(res, 404, { error: 'Not found' });
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
}

function serveStaticFile(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const types = {
    '.html': 'text/html; charset=utf-8',
    '.css':  'text/css',
    '.js':   'application/javascript',
    '.json': 'application/json',
    '.png':  'image/png',
    '.jpg':  'image/jpeg',
    '.mp4':  'video/mp4',
    '.wav':  'audio/wav',
    '.mp3':  'audio/mpeg',
    '.txt':  'text/plain; charset=utf-8',
  };
  serveFile(res, filePath, types[ext] || 'application/octet-stream');
}

// --- Gemini API Key Yonetimi -------------------------------------------------
async function pickHealthyKey() {
  const now = Date.now();
  const enabled = db.keys.filter(k =>
    k.enabled !== false &&
    (!k.cooldownUntil || k.cooldownUntil <= now)
  );
  if (!enabled.length) return null;
  // En az basarisiz, en dusuk latency, en eski kullanim
  enabled.sort((a, b) =>
    (a.failCount || 0) - (b.failCount || 0) ||
    (a.recentLatency || 0) - (b.recentLatency || 0) ||
    (a.lastUsedAt || 0) - (b.lastUsedAt || 0)
  );
  const key = enabled[0];
  key.lastUsedAt = now;
  await saveDb();
  return key;
}

async function markKeyFailure(key, type = 'generic') {
  if (!key) return;
  key.failCount = (key.failCount || 0) + 1;
  const delays = {
    high_demand: 20000,
    quota:       90000,
    timeout:     15000,
    generic:     25000,
  };
  key.cooldownUntil = Date.now() + (delays[type] || 25000) + Math.floor(Math.random() * 8000);
  key.lastError = type;
  key.lastErrorAt = nowIso();
  await saveDb();
}

async function markKeySuccess(key, latency) {
  if (!key) return;
  key.successCount = (key.successCount || 0) + 1;
  key.recentLatency = latency;
  key.lastError = null;
  key.cooldownUntil = null;
  key.lastSuccessAt = nowIso();
  // Hareketli ortalama latency
  key.avgLatency = key.avgLatency
    ? Math.round((key.avgLatency * 0.8 + latency * 0.2))
    : latency;
  await saveDb();
}

// --- Gemini API Cagrisi ------------------------------------------------------
async function geminiCall(systemPrompt, userPrompt, { json = false, model = null } = {}) {
  const useModel = model || db.settings.model || 'gemini-2.0-flash';
  let attempts = 0;
  let lastError = null;
  const maxAttempts = Math.max(5, (db.keys.length || 1) * 2);

  while (attempts < maxAttempts) {
    attempts++;
    const key = await pickHealthyKey();
    if (!key) {
      await log('Uygun API key bulunamadi, 4 saniye bekleniyor...', 'warn');
      await delay(4000);
      continue;
    }
    const started = Date.now();
    try {
      const ctrl = new AbortController();
      const timeout = setTimeout(() => ctrl.abort(), 30000);
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${useModel}:generateContent?key=${encodeURIComponent(key.apiKey)}`;
      const body = {
        contents: [{ parts: [{ text: `${systemPrompt}\n\n${userPrompt}` }] }],
        generationConfig: {
          ...(json ? { responseMimeType: 'application/json' } : {}),
          temperature: 0.85,
          topP: 0.95,
          maxOutputTokens: 4096,
        },
        safetySettings: [
          { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' },
        ],
      };
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: ctrl.signal,
      });
      clearTimeout(timeout);
      const txt = await r.text();
      if (!r.ok) {
        const low = txt.toLowerCase();
        if (low.includes('high demand') || low.includes('try again later')) await markKeyFailure(key, 'high_demand');
        else if (r.status === 429) await markKeyFailure(key, 'quota');
        else await markKeyFailure(key, 'generic');
        lastError = new Error(`Gemini ${r.status}: ${txt.slice(0, 200)}`);
        await log(`API hata (${r.status}) key:${key.name}, deneme ${attempts}/${maxAttempts}`, 'warn');
        continue;
      }
      await markKeySuccess(key, Date.now() - started);
      db.stats.totalApiCalls = (db.stats.totalApiCalls || 0) + 1;
      const parsed = JSON.parse(txt);
      const text = parsed?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('\n') || '';
      return text;
    } catch (e) {
      const errType = /abort/i.test(String(e)) ? 'timeout' : 'generic';
      await markKeyFailure(key, errType);
      lastError = e;
      await log(`API exception: ${e.message}, deneme ${attempts}/${maxAttempts}`, 'warn');
    }
  }
  throw lastError || new Error('Kullanilabilir Gemini key bulunamadi');
}

// --- Icerik Puanlama Motoru --------------------------------------------------
function jaccardSim(a, b) {
  const as = new Set(a.toLowerCase().split(/\W+/).filter(Boolean));
  const bs = new Set(b.toLowerCase().split(/\W+/).filter(Boolean));
  const inter = [...as].filter(x => bs.has(x)).length;
  const union = new Set([...as, ...bs]).size || 1;
  return inter / union;
}

const HOOK_PATTERNS = [
  /kimse(nin)? (bilmedigi|soylemedigi|fark etmedigi)/i,
  /neden (cogu|herkes|insanlar)/i,
  /\d+ (saniye|dakika|adim|kural|sebep|sir)/i,
  /gercek(ten)? (sasirtici|ilginc|onemli)/i,
  /aslinda|fark etmeden|farkinda olmadan/i,
];

const HUMAN_PATTERNS = [
  /cunku|ama|aslinda|bazen|genellikle/i,
  /cogu (kisi|insan)|bircok insan/i,
  /dusun(un)?|hayal et|fark et/i,
  /sen de|sende de|hepimiz/i,
];

const POLICY_RISK_PATTERNS = [
  /olum|intihar|ilac (tedavisi|dozu)|hastalik tedavisi/i,
  /kumar|bahis|illegal|yasadisi/i,
  /nefret|irkci|ayrimci/i,
];

function scoreCandidate(c, recentTitles = [], learningData = {}) {
  const voice = c.voiceText || '';
  const hook  = c.hook || '';
  const title = c.title || '';
  const thumb = c.thumbnailText || '';

  // Hook gucu
  const hookPatternMatch = HOOK_PATTERNS.filter(p => p.test(hook)).length;
  const hookLen = clamp(hook.length, 0, 120);
  const hookImpact = clamp(60 + hookPatternMatch * 8 + Math.floor(hookLen / 4), 0, 100);

  // Netlik
  const sentences = voice.split(/[.!?]+/).filter(s => s.trim().length > 5);
  const avgSentLen = sentences.length
    ? sentences.reduce((s, x) => s + x.split(' ').length, 0) / sentences.length
    : 20;
  const clarity = avgSentLen < 18 ? 88 : avgSentLen < 25 ? 78 : 65;

  // Ozgunluk (tekrar riski)
  const maxSim = recentTitles.length
    ? Math.max(...recentTitles.map(t => jaccardSim(t, title)))
    : 0;
  const noveltyPenalty = maxSim > 0.5 ? 30 : maxSim > 0.35 ? 15 : 0;

  // Baslik gucu
  const titlePatterns = /\?|neden|kimse|sey|gercek|hata|sebep|sir|nasil|\d+/i;
  const titleStrength = titlePatterns.test(title) ? 86 : 72;

  // Insan benzeri dil
  const humanMatches = HUMAN_PATTERNS.filter(p => p.test(voice)).length;
  const humanLikeness = clamp(65 + humanMatches * 7, 0, 100);

  // Thumbnail merak
  const thumbPatterns = /neden|sir|kimse|hata|gercek|sasirtici|\d+/i;
  const thumbnailCuriosity = thumbPatterns.test(thumb) ? 84 : 68;

  // Politika riski
  const policyRisk = POLICY_RISK_PATTERNS.some(p => p.test(voice + ' ' + title)) ? 35 : 6;

  // Ogrenme bonusu/cezasi
  const goodBonus = (learningData.goodPatterns || []).some(p =>
    voice.toLowerCase().includes(p.toLowerCase())
  ) ? 5 : 0;
  const badPenalty = (learningData.badPatterns || []).some(p =>
    voice.toLowerCase().includes(p.toLowerCase())
  ) ? 10 : 0;

  // Genel tutma orani tahmini
  const retentionProxy = clamp(
    Math.round((hookImpact * 0.30 + clarity * 0.20 + titleStrength * 0.20 + humanLikeness * 0.15 + thumbnailCuriosity * 0.15))
    - noveltyPenalty + goodBonus - badPenalty,
    0, 100
  );

  const repetitionRisk = noveltyPenalty > 0 ? 30 + noveltyPenalty : 10;

  return {
    hookImpact, clarity, novelty: 100 - noveltyPenalty,
    titleStrength, humanLikeness, thumbnailCuriosity,
    retentionProxy, repetitionRisk, policyRisk,
    goodBonus, badPenalty,
  };
}

// --- Varsayilan Konu Uretici -------------------------------------------------
const TOPIC_POOLS = {
  psychology: [
    'Insanlar neden ayni hatalari tekrar eder',
    'Kendi kendini sabote etme davranisi',
    'Ilk izlenim neden bu kadar guclu',
    'Onay ihtiyacinin arkasindaki gercek',
    'Neden bazi insanlar surekli gec kalir',
    'Sosyal medyanin ozguvene etkisi',
    'Erken kalkmanin psikolojik faydalari',
    'Kalabalikta yalnizlik hissi neden olusur',
  ],
  shock: [
    'Cogu kisinin bilmedigi zihinsel hata',
    'Bir kararin hayati nasil saptirdigi',
    'Kimsenin fark etmedigi gunluk tuzak',
    'Beyin sizi nasil kandiriyor',
    'Gunluk aliskanliklarin gizli maliyeti',
    'Sosyal baskinin gorunmez etkisi',
  ],
  motivation: [
    'Disiplini olduren gorunmez aliskanlik',
    'Ertelemenin arkasindaki gercek neden',
    'Ilerlemeyi durduran kucuk hata',
    'Hedef belirlerken yapilan en buyuk hata',
    'Motivasyonun bitmesinin gercek sebebi',
    'Basarili insanlarin sabah rutini',
  ],
  knowledge: [
    'Beynin karar verirken kullandigi kisa yol',
    'Az bilinen psikolojik etki',
    'Gunluk hayatta calisan zihinsel yanilgi',
    'Hafizayi guclendiren basit teknik',
    'Ogrenmeyi hizlandiran norolojik sir',
    'Dikkat daginikliginin gercek nedeni',
  ],
  finance: [
    'Zenginlerin para hakkinda bildigi sir',
    'Tasarruf etmeyi zorlastiran psikolojik tuzak',
    'Yatirimda yapilan en yaygin hata',
    'Finansal ozgurluge giden gizli yol',
  ],
  health: [
    'Uyku duzeninin beyne etkisi',
    'Bagirsak sagliginin ruh haline etkisi',
    'Hareketsiz yasamin gizli tehlikeleri',
    'Stres yonetiminin bilimsel yontemi',
  ],
};

function defaultIdea(channel) {
  const pool = TOPIC_POOLS[channel.category] || TOPIC_POOLS.psychology;
  // Son kullanilan konulari filtrele
  const recentTopics = (db.learning.topicHistory || []).slice(-20);
  const filtered = pool.filter(t => !recentTopics.some(r => jaccardSim(r, t) > 0.4));
  return rand(filtered.length ? filtered : pool);
}

// --- Fallback Icerik Uretici -------------------------------------------------
function fallbackCandidates(topic, channel, count = 5) {
  const hooks = [
    `Cogu kisinin fark etmedigi sey su: ${topic}`,
    `${topic} sandigindan cok daha buyuk bir sorun`,
    `Kimse bunu boyle anlatmiyor: ${topic}`,
    `${topic} neden seni geri cekiyor?`,
    `Bunu bilmeden ${topic} hakkinda konusma`,
  ];
  return Array.from({ length: count }).map((_, i) => ({
    id: uid('cand'),
    hook: hooks[i % hooks.length],
    title: hooks[i % hooks.length],
    firstFrameText: hooks[i % hooks.length].slice(0, 48),
    voiceText: `${topic}. Cogu insan sorunun ne oldugunu anladigini saniyor ama asil mesele gorunmeyen aliskanlikta basliyor. Bunu fark ettiginde davranisini degistirmen cok daha kolay hale geliyor. Cunku farkindalik her seyin baslangicidir.`,
    cta: 'Sence bu sende de var mi? Yorum yaz.',
    thumbnailText: 'KIMSE BUNU BOYLE ANLATMIYOR',
    description: `${topic} uzerine kisa bir psikoloji anlatimi. #shorts #psikoloji #motivasyon`,
    tags: ['#shorts', '#psikoloji', '#motivasyon', '#kisiselgelisim'],
    scenePlan: [
      { sceneType: 'intro',  intent: 'hook',    visualQuery: channel.category || 'psychology', durationHint: 4 },
      { sceneType: 'body',   intent: 'explain',  visualQuery: topic,                            durationHint: 18 },
      { sceneType: 'end',    intent: 'cta',      visualQuery: 'minimal background',             durationHint: 6 },
    ],
  }));
}

// --- Gemini ile Icerik Uretimi -----------------------------------------------
async function generateCandidates(channel, topic) {
  if (!db.keys.length) {
    await log('API key yok, fallback icerik kullaniliyor', 'warn');
    return fallbackCandidates(topic, channel, db.settings.maxCandidates);
  }

  const goodPatterns = (db.learning.goodPatterns || []).slice(-5).join(', ') || 'yok';
  const badPatterns  = (db.learning.badPatterns  || []).slice(-5).join(', ') || 'yok';

  const system = `Sen YouTube Shorts icin yuksek kalite Turkce icerik uretim motorusun.
Kurallar:
- JSON disinda HICBIR SEY dondurme
- Ilk cumle (hook) cok guclu ve merak uyandirici olsun
- Baslik ve icerik tam uyumlu olsun
- voiceText 20-35 saniye arasinda okunabilir uzunlukta olsun (yaklasik 60-100 kelime)
- Turkce dil bilgisi mukemmel olsun
- Insan gibi, dogal konusma dili kullan
- Basarili gecmis kaliplar: ${goodPatterns}
- Kacinilacak kaliplar: ${badPatterns}`;

  const user = `Kanal tipi: ${channel.category}
Konu: ${topic}
Kanal adi: ${channel.name}
${db.settings.maxCandidates} adet farkli aday uret.

JSON semasi (kesinlikle bu formatta):
{
  "candidates": [
    {
      "hook": "Ilk cumle - cok guclu merak uyandirici",
      "title": "YouTube basligi (max 70 karakter)",
      "firstFrameText": "Ekranda gorunecek kisa metin (max 50 karakter)",
      "voiceText": "Seslendirilecek tam metin (60-100 kelime)",
      "cta": "Sona eklenen harekete gecirici cagri",
      "thumbnailText": "Thumbnail ustundeki buyuk yazi (max 40 karakter, buyuk harf)",
      "description": "YouTube aciklamasi (hashtag dahil)",
      "tags": ["#tag1", "#tag2"],
      "scenePlan": [
        {"sceneType": "intro|body|end", "intent": "hook|explain|cta", "visualQuery": "gorsel arama terimi", "durationHint": 5}
      ]
    }
  ]
}`;

  try {
    const txt = await geminiCall(system, user, { json: true });
    // JSON blogunu temizle
    const cleaned = txt.replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim();
    const data = JSON.parse(cleaned);
    const candidates = (data.candidates || []).slice(0, db.settings.maxCandidates);
    return candidates.map(c => ({ id: uid('cand'), ...c }));
  } catch (e) {
    await log(`generateCandidates hata: ${e.message} — fallback kullaniliyor`, 'warn');
    return fallbackCandidates(topic, channel, db.settings.maxCandidates);
  }
}

// --- Yargi & Onarim Dongusu -------------------------------------------------
async function judgeAndRepair(candidates, channel) {
  const recentTitles = db.jobs
    .filter(j => j.status === 'completed')
    .slice(-15)
    .map(j => j.winner?.title || '')
    .filter(Boolean);

  let enriched = candidates.map(c => ({
    ...c,
    scores: scoreCandidate(c, recentTitles, db.learning),
    judgeNotes: [],
  }));

  // Ilk degerlendirme
  enriched = enriched.map(c => {
    const notes = [];
    if (c.scores.hookImpact    < 82) notes.push('Hook daha guclu olmali');
    if (c.scores.titleStrength < 78) notes.push('Baslik daha merak uyandirmali');
    if (c.scores.repetitionRisk > 22) notes.push('Tekrar riski yuksek');
    if (c.scores.humanLikeness < 75) notes.push('Daha dogal konusma dili gerekli');
    if (c.scores.clarity       < 72) notes.push('Cumleler daha kisa ve net olmali');
    return { ...c, judgeNotes: notes };
  });

  // Onarim donguleri
  for (let round = 0; round < db.settings.maxRepairRounds; round++) {
    enriched = enriched.map(c => {
      if (!c.judgeNotes.length) return c;
      let voice = c.voiceText || '';
      let hook  = c.hook || '';
      let title = c.title || '';

      if (c.judgeNotes.some(n => n.includes('Hook'))) {
        const stripped = hook.replace(/^(Cogu kisi|Kimse|Herkes)\s*/i, '');
        hook = `Kimsenin fark etmedigi gercek: ${stripped}`;
      }
      if (c.judgeNotes.some(n => n.includes('Baslik'))) {
        title = title.startsWith('Neden') ? title : `Neden ${title.slice(0, 55)}`;
      }
      if (c.judgeNotes.some(n => n.includes('dogal'))) {
        voice = voice
          .replace(/Cogu kisi/g, 'Bircok insan')
          .replace(/sorun/g, 'mesele')
          .replace(/yapilmaktadir/g, 'yapiliyor')
          .replace(/edilmektedir/g, 'ediliyor');
      }
      if (c.judgeNotes.some(n => n.includes('kisa'))) {
        // Uzun cumleleri bol (basit yaklasim)
        voice = voice.replace(/([^.!?]{80,}?)(\s+(?:ve|ama|cunku|ancak)\s+)/g, '$1. ');
      }

      const updated = { ...c, hook, title, voiceText: voice };
      const scores = scoreCandidate(updated, recentTitles, db.learning);
      const judgeNotes = [];
      if (scores.hookImpact    < 82) judgeNotes.push('Hook daha guclu olmali');
      if (scores.titleStrength < 78) judgeNotes.push('Baslik daha merak uyandirmali');
      if (scores.repetitionRisk > 22) judgeNotes.push('Tekrar riski yuksek');
      if (scores.humanLikeness < 75) judgeNotes.push('Daha dogal konusma dili gerekli');
      if (scores.clarity       < 72) judgeNotes.push('Cumleler daha kisa ve net olmali');
      return { ...updated, scores, judgeNotes };
    });
  }

  enriched.sort((a, b) => b.scores.retentionProxy - a.scores.retentionProxy);
  return enriched;
}

// --- TTS (Text-to-Speech) ----------------------------------------------------
async function generateTTS(text, outputPath) {
  // edge-tts veya sistem TTS kullan
  return new Promise((resolve) => {
    const proc = spawn('edge-tts', [
      '--voice', db.settings.ttsVoice || 'tr-TR-EmelNeural',
      '--text', text,
      '--write-media', outputPath,
    ]);
    proc.on('error', () => resolve(false));
    proc.on('close', code => resolve(code === 0));
  });
}

// --- FFmpeg Kontrol ----------------------------------------------------------
async function ffmpegExists() {
  return new Promise(resolve => {
    const p = spawn('ffmpeg', ['-version']);
    p.on('error', () => resolve(false));
    p.on('close', code => resolve(code === 0));
  });
}

async function execSpawn(cmd, args, opts = {}) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { stdio: opts.stdio || 'ignore', ...opts });
    p.on('error', reject);
    p.on('close', code => code === 0 ? resolve() : reject(new Error(`${cmd} exit ${code}`)));
  });
}

// --- Video Render ------------------------------------------------------------
async function renderWinner(job) {
  const winner  = job.winner;
  const outMp4  = path.join(outputsDir, `${job.id}.mp4`);
  const outTxt  = path.join(outputsDir, `${job.id}.txt`);
  const ffmpegOk = await ffmpegExists();

  if (!ffmpegOk) {
    await fsp.writeFile(outTxt, JSON.stringify(winner, null, 2));
    await log('FFmpeg bulunamadi, metin ciktisi olusturuldu', 'warn');
    return { outputPath: outTxt, rendered: false, reason: 'ffmpeg_missing' };
  }

  const bgDir = path.join(storageDir, 'backgrounds');
  const bgs   = (await fsp.readdir(bgDir)).filter(x => /\.(mp4|mov)$/i.test(x));
  const dur   = db.settings.targetVideoSeconds || 30;

  // Ses olustur
  const audioPath = path.join(storageDir, 'audio', `${job.id}.wav`);
  let audioReady = false;

  // TTS dene
  if (db.settings.ttsEnabled) {
    audioReady = await generateTTS(winner.voiceText || '', audioPath);
    if (audioReady) await log('TTS ses dosyasi olusturuldu');
  }

  // TTS yoksa sessiz ses
  if (!audioReady) {
    try {
      await execSpawn('ffmpeg', [
        '-y', '-f', 'lavfi',
        '-i', `anullsrc=r=44100:cl=stereo`,
        '-t', String(dur),
        audioPath,
      ]);
      audioReady = true;
    } catch (e) {
      await log(`Sessiz ses olusturulamadi: ${e.message}`, 'error');
    }
  }

  // Metin guvenli hale getir (ffmpeg drawtext icin)
  const safeText = (t) => (t || '').replace(/[:'\\]/g, '').replace(/\n/g, ' ').slice(0, 80);
  const safeTitle   = safeText(winner.firstFrameText || winner.title);
  const safeVoice   = safeText((winner.voiceText || '').slice(0, 160));
  const safeCta     = safeText(winner.cta);
  const safeThumb   = safeText(winner.thumbnailText);
  const watermark   = safeText(db.settings.watermark || '');

  // Font ayari
  const fontArgs = [
    'fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
  ];

  let vfParts = [];

  if (bgs.length) {
    // Arka plan videosu varsa
    const bg = path.join(bgDir, bgs[0]);
    vfParts = [
      'scale=1080:1920:force_original_aspect_ratio=increase',
      'crop=1080:1920',
      // Ust baslik kutusu
      'drawbox=x=0:y=60:w=1080:h=280:color=black@0.6:t=fill',
      // Baslik
      `drawtext=${fontArgs.join(':')}:text='${safeTitle}':fontcolor=white:fontsize=54:x=(w-text_w)/2:y=90:line_spacing=8`,
      // Thumbnail yazisi
      `drawtext=${fontArgs.join(':')}:text='${safeThumb}':fontcolor=#FFD700:fontsize=44:x=(w-text_w)/2:y=200`,
      // Alt ses metni kutusu
      'drawbox=x=0:y=900:w=1080:h=500:color=black@0.5:t=fill',
      // Ses metni
      `drawtext=${fontArgs.join(':')}:text='${safeVoice}':fontcolor=white:fontsize=34:x=40:y=920:line_spacing=10:wrap_text=1`,
      // CTA
      'drawbox=x=0:y=1700:w=1080:h=120:color=#2563eb@0.85:t=fill',
      `drawtext=${fontArgs.join(':')}:text='${safeCta}':fontcolor=white:fontsize=36:x=(w-text_w)/2:y=1730`,
    ];
    if (watermark) {
      vfParts.push(`drawtext=${fontArgs.join(':')}:text='${watermark}':fontcolor=white@0.4:fontsize=28:x=w-text_w-20:y=20`);
    }

    const args = [
      '-y', '-stream_loop', '-1', '-i', bg,
      '-i', audioPath,
      '-vf', vfParts.join(','),
      '-shortest',
      '-t', String(dur),
      '-c:v', 'libx264', '-preset', 'fast', '-crf', '23',
      '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-b:a', '128k',
      '-movflags', '+faststart',
      outMp4,
    ];
    try {
      await execSpawn('ffmpeg', args);
    } catch (e) {
      await log(`Video render hatasi (bg): ${e.message}`, 'error');
      return { outputPath: outTxt, rendered: false, reason: e.message };
    }
  } else {
    // Arka plan videosu yoksa gradient arka plan
    vfParts = [
      // Koyu mavi gradient arka plan
      'drawbox=x=0:y=0:w=1080:h=1920:color=#0f1729:t=fill',
      // Ust dekoratif cizgi
      'drawbox=x=0:y=0:w=1080:h=6:color=#2563eb:t=fill',
      // Baslik kutusu
      'drawbox=x=20:y=80:w=1040:h=260:color=#1e2a45@0.9:t=fill',
      // Baslik
      `drawtext=${fontArgs.join(':')}:text='${safeTitle}':fontcolor=white:fontsize=52:x=(w-text_w)/2:y=110:line_spacing=8`,
      // Thumbnail yazisi
      `drawtext=${fontArgs.join(':')}:text='${safeThumb}':fontcolor=#FFD700:fontsize=42:x=(w-text_w)/2:y=220`,
      // Icerik alani
      'drawbox=x=20:y=400:w=1040:h=1100:color=#1a2035@0.8:t=fill',
      // Ses metni
      `drawtext=${fontArgs.join(':')}:text='${safeVoice}':fontcolor=#e2e8f0:fontsize=36:x=50:y=430:line_spacing=12`,
      // Alt CTA kutusu
      'drawbox=x=0:y=1720:w=1080:h=140:color=#2563eb:t=fill',
      `drawtext=${fontArgs.join(':')}:text='${safeCta}':fontcolor=white:fontsize=36:x=(w-text_w)/2:y=1750`,
      // Alt dekoratif cizgi
      'drawbox=x=0:y=1914:w=1080:h=6:color=#2563eb:t=fill',
    ];
    if (watermark) {
      vfParts.push(`drawtext=${fontArgs.join(':')}:text='${watermark}':fontcolor=white@0.35:fontsize=26:x=w-text_w-20:y=20`);
    }

    const args = [
      '-y',
      '-f', 'lavfi', '-i', `color=c=#0f1729:s=1080x1920:r=30`,
      '-i', audioPath,
      '-vf', vfParts.join(','),
      '-t', String(dur),
      '-c:v', 'libx264', '-preset', 'fast', '-crf', '23',
      '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-b:a', '128k',
      '-movflags', '+faststart',
      outMp4,
    ];
    try {
      await execSpawn('ffmpeg', args);
    } catch (e) {
      await log(`Video render hatasi (no-bg): ${e.message}`, 'error');
      // Fallback: metin ciktisi
      await fsp.writeFile(outTxt, JSON.stringify(winner, null, 2));
      return { outputPath: outTxt, rendered: false, reason: e.message };
    }
  }

  await log(`Video render tamamlandi: ${outMp4}`);
  return { outputPath: outMp4, rendered: true };
}

// --- YouTube Upload ----------------------------------------------------------
async function refreshGoogleAccessToken(channel) {
  if (!channel.clientId || !channel.clientSecret || !channel.refreshToken) {
    throw new Error('YouTube OAuth alanlari eksik (clientId, clientSecret, refreshToken)');
  }
  const form = new URLSearchParams({
    client_id:     channel.clientId,
    client_secret: channel.clientSecret,
    refresh_token: channel.refreshToken,
    grant_type:    'refresh_token',
  });
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form,
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Token yenileme basarisiz (${res.status}): ${err}`);
  }
  const j = await res.json();
  if (!j.access_token) throw new Error('Access token alinamadi');
  channel.accessToken = j.access_token;
  channel.accessTokenFetchedAt = Date.now();
  await saveDb();
  return channel.accessToken;
}

async function uploadToYouTube(channel, filePath, title, description, tags = []) {
  const tokenAge = Date.now() - (channel.accessTokenFetchedAt || 0);
  const accessToken = (channel.accessToken && tokenAge < 3_500_000)
    ? channel.accessToken
    : await refreshGoogleAccessToken(channel);

  const metadata = {
    snippet: {
      title:       title.slice(0, 100),
      description: description.slice(0, 5000),
      tags:        tags.map(t => t.replace('#', '')).slice(0, 30),
      categoryId:  '27', // Egitim
    },
    status: {
      privacyStatus:          channel.privacyStatus || db.settings.defaultPrivacy || 'public',
      selfDeclaredMadeForKids: false,
      madeForKids:             false,
    },
  };

  // Resumable upload baslat
  const initRes = await fetch(
    'https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status',
    {
      method: 'POST',
      headers: {
        Authorization:             `Bearer ${accessToken}`,
        'Content-Type':            'application/json; charset=UTF-8',
        'X-Upload-Content-Type':   'video/mp4',
      },
      body: JSON.stringify(metadata),
    }
  );
  if (!initRes.ok) {
    throw new Error(`Upload baslatma hatasi (${initRes.status}): ${await initRes.text()}`);
  }
  const uploadUrl = initRes.headers.get('location');
  if (!uploadUrl) throw new Error('Upload URL alinamadi');

  const stat = await fsp.stat(filePath);
  const file = await fsp.readFile(filePath);

  const upRes = await fetch(uploadUrl, {
    method: 'PUT',
    headers: {
      Authorization:  `Bearer ${accessToken}`,
      'Content-Length': String(stat.size),
      'Content-Type': 'video/mp4',
    },
    body: file,
  });
  if (!upRes.ok) {
    throw new Error(`Upload hatasi (${upRes.status}): ${await upRes.text()}`);
  }
  const result = await upRes.json();
  db.stats.totalUploads = (db.stats.totalUploads || 0) + 1;
  await saveDb();
  return result;
}

// --- Yayin Kontrolu ----------------------------------------------------------
async function shouldPublish(channel) {
  const now = Date.now();
  const minInterval = db.settings.minUploadIntervalMinutes * 60_000;
  const since = now - minInterval;

  const recentUploads = db.jobs.filter(j =>
    j.channelId === channel.id &&
    j.status === 'completed' &&
    j.publishedAt &&
    new Date(j.publishedAt).getTime() > since
  );

  const todayUploads = db.jobs.filter(j => {
    if (j.channelId !== channel.id || j.status !== 'completed' || !j.publishedAt) return false;
    const d = new Date(j.publishedAt);
    const today = new Date();
    return d.getFullYear() === today.getFullYear() &&
           d.getMonth()    === today.getMonth() &&
           d.getDate()     === today.getDate();
  });

  return recentUploads.length === 0 && todayUploads.length < db.settings.maxDailyPerChannel;
}

// --- Webhook Bildirimi -------------------------------------------------------
async function sendWebhook(event, data) {
  const url = db.settings.notifyWebhook;
  if (!url) return;
  try {
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event, data, ts: nowIso() }),
    });
  } catch (e) {
    await log(`Webhook gonderilemedi: ${e.message}`, 'warn');
  }
}

// --- Ogrenme Sistemi ---------------------------------------------------------
async function updateLearning(job) {
  if (!job.winner || !job.winner.scores) return;
  const scores = job.winner.scores;
  const voice  = job.winner.voiceText || '';

  // Basarili kaliplari kaydet
  if (scores.retentionProxy >= 85 && job.status === 'completed') {
    const words = voice.toLowerCase().split(/\W+/).filter(w => w.length > 4);
    const topWords = words.slice(0, 5);
    for (const w of topWords) {
      if (!db.learning.goodPatterns.includes(w)) {
        db.learning.goodPatterns.push(w);
        if (db.learning.goodPatterns.length > 50) db.learning.goodPatterns.shift();
      }
    }
  }

  // Basarisiz kaliplari kaydet
  if (scores.retentionProxy < 60 || job.status === 'failed') {
    const opening = voice.split('.')[0]?.toLowerCase().trim();
    if (opening && opening.length > 5 && !db.learning.badOpenings.includes(opening)) {
      db.learning.badOpenings.push(opening);
      if (db.learning.badOpenings.length > 30) db.learning.badOpenings.shift();
    }
  }

  // Konu gecmisini guncelle
  if (job.topic) {
    db.learning.topicHistory.push(job.topic);
    if (db.learning.topicHistory.length > 50) db.learning.topicHistory.shift();
  }

  // Performans logu
  db.learning.performanceLog.push({
    ts:             nowIso(),
    jobId:          job.id,
    topic:          job.topic,
    retentionProxy: scores.retentionProxy,
    status:         job.status,
  });
  if (db.learning.performanceLog.length > 200) db.learning.performanceLog.shift();

  await saveDb();
}

// --- Ana Is Akisi ------------------------------------------------------------
async function runJob(channelId, forceTopic = null) {
  // Eszamanli is kontrolu
  if (!db.settings.concurrentJobs && activeJobs.size > 0) {
    return { ok: false, reason: 'job_active', activeJobs: [...activeJobs.keys()] };
  }
  if (activeJobs.has(channelId)) {
    return { ok: false, reason: 'channel_job_active', channelId };
  }

  const channel = db.channels.find(c => c.id === channelId && c.enabled !== false);
  if (!channel) return { ok: false, reason: 'channel_not_found' };

  const topic = forceTopic || defaultIdea(channel);
  const job = {
    id:          uid('job'),
    channelId,
    channelName: channel.name,
    status:      'generating',
    createdAt:   nowIso(),
    topic,
    candidates:  [],
    winner:      null,
    render:      null,
    upload:      null,
    publishedAt: null,
    error:       null,
    uploadError: null,
    duration:    null,
  };

  db.jobs.unshift(job);
  // Is gecmisini sinirla
  if (db.jobs.length > db.settings.maxJobHistory) {
    db.jobs = db.jobs.slice(0, db.settings.maxJobHistory);
  }
  db.stats.totalJobs = (db.stats.totalJobs || 0) + 1;
  await saveDb();

  activeJobs.set(channelId, job.id);
  broadcastSSE({ type: 'job_start', jobId: job.id, channelId, topic });
  await log(`Is basladi [${job.id}] kanal:${channel.name} konu:"${topic}"`);

  const jobStart = Date.now();
  try {
    // 1. Icerik uret
    await log(`[${job.id}] Icerik uretiliyor...`);
    const candidates = await generateCandidates(channel, topic);
    job.candidates = await judgeAndRepair(candidates, channel);

    // 2. Kazanani sec
    const winner = job.candidates.find(c =>
      c.scores.retentionProxy >= db.settings.publishThreshold &&
      c.scores.policyRisk     <= 20 &&
      c.scores.repetitionRisk <= 25
    ) || job.candidates[0];
    job.winner = winner;
    job.status = 'rendering';
    await saveDb();
    broadcastSSE({ type: 'job_update', jobId: job.id, status: 'rendering', winner: winner?.title });

    // 3. Video render
    await log(`[${job.id}] Video render ediliyor... (kazanan: ${winner?.title})`);
    const render = await renderWinner(job);
    job.render = render;

    // 4. Upload kontrolu
    if (
      db.settings.uploadEnabled &&
      channel.uploadEnabled &&
      render.rendered &&
      await shouldPublish(channel)
    ) {
      job.status = 'uploading';
      await saveDb();
      broadcastSSE({ type: 'job_update', jobId: job.id, status: 'uploading' });
      await log(`[${job.id}] YouTube'a yukleniyor...`);
      try {
        const uploaded = await uploadToYouTube(
          channel,
          render.outputPath,
          winner.title,
          winner.description,
          winner.tags || []
        );
        job.upload = uploaded;
        job.publishedAt = nowIso();
        await log(`[${job.id}] YouTube yukleme basarili: ${uploaded.id}`);
        await sendWebhook('upload_success', { jobId: job.id, videoId: uploaded.id, title: winner.title });
      } catch (e) {
        job.uploadError = e.message;
        await log(`[${job.id}] YouTube yukleme hatasi: ${e.message}`, 'error');
        await sendWebhook('upload_error', { jobId: job.id, error: e.message });
      }
    }

    job.status   = 'completed';
    job.duration = Date.now() - jobStart;
    db.stats.successJobs = (db.stats.successJobs || 0) + 1;
    await saveDb();
    await updateLearning(job);
    broadcastSSE({ type: 'job_complete', jobId: job.id, duration: job.duration });
    await log(`[${job.id}] Is tamamlandi (${Math.round(job.duration / 1000)}s)`);
    await sendWebhook('job_complete', { jobId: job.id, title: winner.title, rendered: render.rendered });
    return { ok: true, job };

  } catch (e) {
    job.status = 'failed';
    job.error  = e.message;
    job.duration = Date.now() - jobStart;
    db.stats.failedJobs = (db.stats.failedJobs || 0) + 1;
    await saveDb();
    await updateLearning(job);
    broadcastSSE({ type: 'job_error', jobId: job.id, error: e.message });
    await log(`[${job.id}] Is basarisiz: ${e.message}`, 'error');
    await sendWebhook('job_failed', { jobId: job.id, error: e.message });
    return { ok: false, error: e.message };
  } finally {
    activeJobs.delete(channelId);
  }
}

// --- Otomatik Zamanlayici ----------------------------------------------------
function ensureScheduler() {
  if (schedulerTimer) clearInterval(schedulerTimer);
  schedulerTimer = setInterval(async () => {
    try {
      db = await loadDb();
      if (!db.settings.autoMode) return;
      const channels = db.channels.filter(c => c.enabled !== false);
      for (const channel of channels) {
        if (activeJobs.has(channel.id)) continue;
        const lastJob = db.jobs.find(j => j.channelId === channel.id);
        if (lastJob) {
          const elapsed = Date.now() - new Date(lastJob.createdAt).getTime();
          const interval = db.settings.autoIntervalMinutes * 60_000;
          if (elapsed < interval) continue;
        }
        await log(`Otomatik is tetiklendi: ${channel.name}`);
        runJob(channel.id).catch(e => log(`Otomatik is hatasi: ${e.message}`, 'error'));
        if (!db.settings.concurrentJobs) break; // Tek seferde bir is
      }
    } catch (e) {
      await log(`Zamanlayici hatasi: ${e.message}`, 'error');
    }
  }, 30_000); // 30 saniyede bir kontrol
}

// --- API Endpoint'leri -------------------------------------------------------
async function handleApi(req, res, pathname, url) {
  // -- GET /api/health ------------------------------------------------------
  if (req.method === 'GET' && pathname === '/api/health') {
    return sendJson(res, 200, {
      ok: true,
      version: '2.0.0',
      uptime: process.uptime(),
      settings: db.settings,
      keys: db.keys.length,
      channels: db.channels.length,
      activeJobs: [...activeJobs.entries()].map(([ch, jid]) => ({ channelId: ch, jobId: jid })),
      stats: db.stats,
    });
  }

  // -- GET /api/state -------------------------------------------------------
  if (req.method === 'GET' && pathname === '/api/state') {
    return sendJson(res, 200, {
      keys:      db.keys.map(k => ({ ...k, apiKey: k.apiKey ? '••••' + k.apiKey.slice(-4) : '' })),
      channels:  db.channels,
      jobs:      db.jobs.slice(0, 30),
      settings:  db.settings,
      stats:     db.stats,
      learning:  {
        goodPatterns: db.learning.goodPatterns.slice(-10),
        badPatterns:  db.learning.badPatterns.slice(-10),
        topicHistory: db.learning.topicHistory.slice(-10),
        performanceLog: db.learning.performanceLog.slice(-20),
      },
      activeJobs: [...activeJobs.entries()].map(([ch, jid]) => ({ channelId: ch, jobId: jid })),
    });
  }

  // -- GET /api/logs --------------------------------------------------------
  if (req.method === 'GET' && pathname === '/api/logs') {
    try {
      const lines = (await fsp.readFile(logPath, 'utf8')).split('\n').filter(Boolean);
      return sendJson(res, 200, { logs: lines.slice(-200) });
    } catch {
      return sendJson(res, 200, { logs: [] });
    }
  }

  // -- GET /api/stats -------------------------------------------------------
  if (req.method === 'GET' && pathname === '/api/stats') {
    const perf = db.learning.performanceLog || [];
    const avg  = perf.length ? Math.round(perf.reduce((s, p) => s + (p.retentionProxy || 0), 0) / perf.length) : 0;
    return sendJson(res, 200, {
      ...db.stats,
      avgRetention: avg,
      successRate: db.stats.totalJobs
        ? Math.round((db.stats.successJobs / db.stats.totalJobs) * 100)
        : 0,
    });
  }

  // -- GET /api/outputs -----------------------------------------------------
  if (req.method === 'GET' && pathname === '/api/outputs') {
    const files = await fsp.readdir(outputsDir).catch(() => []);
    const items = await Promise.all(files.map(async f => {
      const fp = path.join(outputsDir, f);
      const st = await fsp.stat(fp).catch(() => null);
      return st ? { name: f, size: st.size, mtime: st.mtime } : null;
    }));
    return sendJson(res, 200, { outputs: items.filter(Boolean) });
  }

  // -- GET /api/outputs/:file -----------------------------------------------
  if (req.method === 'GET' && pathname.startsWith('/api/outputs/')) {
    const fname = path.basename(pathname.slice('/api/outputs/'.length));
    const fp = path.join(outputsDir, fname);
    try {
      await fsp.access(fp);
      serveStaticFile(res, fp);
    } catch {
      sendJson(res, 404, { error: 'Dosya bulunamadi' });
    }
    return;
  }

  // -- SSE /api/events ------------------------------------------------------
  if (req.method === 'GET' && pathname === '/api/events') {
    res.writeHead(200, {
      'Content-Type':  'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection':    'keep-alive',
      'Access-Control-Allow-Origin': '*',
    });
    res.write('data: {"type":"connected"}\n\n');
    sseClients.add(res);
    req.on('close', () => sseClients.delete(res));
    return;
  }

  // -- POST /api/keys -------------------------------------------------------
  if (req.method === 'POST' && pathname === '/api/keys') {
    const body = await parseBody(req);
    if (!body.apiKey) return sendJson(res, 400, { error: 'apiKey zorunlu' });
    const key = {
      id:            uid('key'),
      name:          body.name || `Key ${db.keys.length + 1}`,
      apiKey:        body.apiKey.trim(),
      project:       body.project || 'default',
      enabled:       true,
      failCount:     0,
      successCount:  0,
      recentLatency: 0,
      avgLatency:    0,
      cooldownUntil: null,
      lastError:     null,
      createdAt:     nowIso(),
    };
    db.keys.push(key);
    await saveDb();
    await log(`API key eklendi: ${key.name}`);
    return sendJson(res, 200, { ok: true, key: { ...key, apiKey: '••••' + key.apiKey.slice(-4) } });
  }

  // -- DELETE /api/keys/:id -------------------------------------------------
  if (req.method === 'DELETE' && pathname.startsWith('/api/keys/')) {
    const id = pathname.split('/')[3];
    const idx = db.keys.findIndex(k => k.id === id);
    if (idx === -1) return sendJson(res, 404, { error: 'Key bulunamadi' });
    db.keys.splice(idx, 1);
    await saveDb();
    return sendJson(res, 200, { ok: true });
  }

  // -- POST /api/keys/:id/toggle --------------------------------------------
  if (req.method === 'POST' && pathname.startsWith('/api/keys/') && pathname.endsWith('/toggle')) {
    const id = pathname.split('/')[3];
    const key = db.keys.find(k => k.id === id);
    if (!key) return sendJson(res, 404, { error: 'Key bulunamadi' });
    key.enabled = !key.enabled;
    await saveDb();
    return sendJson(res, 200, { ok: true, key: { ...key, apiKey: '••••' + key.apiKey.slice(-4) } });
  }

  // -- POST /api/keys/:id/test ----------------------------------------------
  if (req.method === 'POST' && pathname.startsWith('/api/keys/') && pathname.endsWith('/test')) {
    const id = pathname.split('/')[3];
    const key = db.keys.find(k => k.id === id);
    if (!key) return sendJson(res, 404, { error: 'Key bulunamadi' });
    try {
      const started = Date.now();
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${db.settings.model}:generateContent?key=${encodeURIComponent(key.apiKey)}`;
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ parts: [{ text: 'Merhaba, test.' }] }] }),
        signal: AbortSignal.timeout(10000),
      });
      const latency = Date.now() - started;
      if (r.ok) {
        await markKeySuccess(key, latency);
        return sendJson(res, 200, { ok: true, latency });
      } else {
        const txt = await r.text();
        await markKeyFailure(key, r.status === 429 ? 'quota' : 'generic');
        return sendJson(res, 200, { ok: false, status: r.status, error: txt.slice(0, 200) });
      }
    } catch (e) {
      return sendJson(res, 200, { ok: false, error: e.message });
    }
  }

  // -- POST /api/channels ---------------------------------------------------
  if (req.method === 'POST' && pathname === '/api/channels') {
    const body = await parseBody(req);
    if (!body.name) return sendJson(res, 400, { error: 'name zorunlu' });
    const channel = {
      id:                   uid('ch'),
      name:                 body.name.trim(),
      category:             body.category || 'psychology',
      enabled:              true,
      uploadEnabled:        !!body.uploadEnabled,
      privacyStatus:        body.privacyStatus || 'public',
      clientId:             body.clientId || '',
      clientSecret:         body.clientSecret || '',
      refreshToken:         body.refreshToken || '',
      accessToken:          '',
      accessTokenFetchedAt: 0,
      createdAt:            nowIso(),
      totalJobs:            0,
      totalUploads:         0,
    };
    db.channels.push(channel);
    await saveDb();
    await log(`Kanal eklendi: ${channel.name}`);
    return sendJson(res, 200, { ok: true, channel });
  }

  // -- PUT /api/channels/:id ------------------------------------------------
  if (req.method === 'PUT' && pathname.startsWith('/api/channels/')) {
    const id = pathname.split('/')[3];
    const ch = db.channels.find(c => c.id === id);
    if (!ch) return sendJson(res, 404, { error: 'Kanal bulunamadi' });
    const body = await parseBody(req);
    Object.assign(ch, {
      name:          body.name          ?? ch.name,
      category:      body.category      ?? ch.category,
      uploadEnabled: body.uploadEnabled !== undefined ? !!body.uploadEnabled : ch.uploadEnabled,
      privacyStatus: body.privacyStatus ?? ch.privacyStatus,
      clientId:      body.clientId      ?? ch.clientId,
      clientSecret:  body.clientSecret  ?? ch.clientSecret,
      refreshToken:  body.refreshToken  ?? ch.refreshToken,
    });
    await saveDb();
    return sendJson(res, 200, { ok: true, channel: ch });
  }

  // -- DELETE /api/channels/:id ---------------------------------------------
  if (req.method === 'DELETE' && pathname.startsWith('/api/channels/')) {
    const id = pathname.split('/')[3];
    const idx = db.channels.findIndex(c => c.id === id);
    if (idx === -1) return sendJson(res, 404, { error: 'Kanal bulunamadi' });
    db.channels.splice(idx, 1);
    await saveDb();
    return sendJson(res, 200, { ok: true });
  }

  // -- POST /api/channels/:id/toggle ----------------------------------------
  if (req.method === 'POST' && pathname.startsWith('/api/channels/') && pathname.endsWith('/toggle')) {
    const id = pathname.split('/')[3];
    const ch = db.channels.find(c => c.id === id);
    if (!ch) return sendJson(res, 404, { error: 'Kanal bulunamadi' });
    ch.enabled = !ch.enabled;
    await saveDb();
    return sendJson(res, 200, { ok: true, channel: ch });
  }

  // -- POST /api/settings ---------------------------------------------------
  if (req.method === 'POST' && pathname === '/api/settings') {
    const body = await parseBody(req);
    const allowed = [
      'autoMode', 'autoIntervalMinutes', 'uploadEnabled', 'model',
      'targetVideoSeconds', 'publishThreshold', 'maxCandidates',
      'maxRepairRounds', 'maxDailyPerChannel', 'minUploadIntervalMinutes',
      'ttsEnabled', 'ttsVoice', 'watermark', 'defaultPrivacy',
      'notifyWebhook', 'maxJobHistory', 'concurrentJobs',
    ];
    for (const k of allowed) {
      if (body[k] !== undefined) db.settings[k] = body[k];
    }
    await saveDb();
    ensureScheduler();
    return sendJson(res, 200, { ok: true, settings: db.settings });
  }

  // -- POST /api/run --------------------------------------------------------
  if (req.method === 'POST' && pathname === '/api/run') {
    const body = await parseBody(req);
    if (!body.channelId) return sendJson(res, 400, { error: 'channelId zorunlu' });
    const result = await runJob(body.channelId, body.topic || null);
    return sendJson(res, 200, result);
  }

  // -- DELETE /api/jobs/:id -------------------------------------------------
  if (req.method === 'DELETE' && pathname.startsWith('/api/jobs/')) {
    const id = pathname.split('/')[3];
    const idx = db.jobs.findIndex(j => j.id === id);
    if (idx === -1) return sendJson(res, 404, { error: 'Is bulunamadi' });
    db.jobs.splice(idx, 1);
    await saveDb();
    return sendJson(res, 200, { ok: true });
  }

  // -- POST /api/jobs/clear -------------------------------------------------
  if (req.method === 'POST' && pathname === '/api/jobs/clear') {
    db.jobs = db.jobs.filter(j => j.status === 'generating' || j.status === 'rendering' || j.status === 'uploading');
    await saveDb();
    return sendJson(res, 200, { ok: true, remaining: db.jobs.length });
  }

  // -- POST /api/learning/reset ---------------------------------------------
  if (req.method === 'POST' && pathname === '/api/learning/reset') {
    db.learning = { ...defaultDb.learning };
    await saveDb();
    return sendJson(res, 200, { ok: true });
  }

  return sendJson(res, 404, { error: 'API endpoint bulunamadi' });
}

// --- HTTP Sunucu -------------------------------------------------------------
const server = http.createServer(async (req, res) => {
  try {
    const url      = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = url.pathname;

    // CORS preflight
    if (req.method === 'OPTIONS') {
      res.writeHead(204, {
        'Access-Control-Allow-Origin':  '*',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      });
      return res.end();
    }

    if (pathname.startsWith('/api/')) return handleApi(req, res, pathname, url);
    if (pathname === '/' || pathname === '/index.html') return serveFile(res, path.join(publicDir, 'index.html'));
    return sendJson(res, 404, { error: 'Sayfa bulunamadi' });

  } catch (e) {
    await log(`Sunucu hatasi: ${e.message}`, 'error');
    return sendJson(res, 500, { error: e.message });
  }
});

const PORT = db.settings.port || 3001;
server.listen(PORT, async () => {
  await log(`🚀 Gemini Executive Shorts OS v2.0 — http://127.0.0.1:${PORT}`);
  await log(`Model: ${db.settings.model} | Keys: ${db.keys.length} | Channels: ${db.channels.length}`);
});
