/**
 * Channel Architect — Kanal Mimari
 * ================================
 * Kategori bazli kanal yapilandirmasi, SEO optimizasyonu ve gorsel kimlik rehberi
 */

// --- Kategori Bazli Kanal Ayarlari -----------------------------------------
const CHANNEL_TEMPLATES = {
  psychology: {
    name: 'Psikoloji',
    youtubeCategory: 'Education',
    description: `Insan davranisinin derinliklerine inin. Psikoloji, manipulasyon, davranis analizi ve zihinsel saglik hakkinda ilginc bilgiler. Her videoda yeni bir perspektif, her perspektifde yeni bir kesif.`,
    keywords: ['psikoloji', 'davranis', 'zihin', 'insan', 'dusunce', 'manipulasyon', 'analiz', 'bilim', 'davranis bilimi', 'kognitif', 'emosyon', 'sosyal', 'kisilik', 'gelisim', 'saglik'],
    tags: ['#psikoloji', '#davranis', '#zihin', '#insan', '#bilim', '#manipulasyon', '#analiz', '#gelisim'],
    brandingPrompt: 'Minimalist, koyu renkli, gizemli ve entelektuel bir psikoloji kanali logosunu tasarla. Beyin, soru isareti ve soyut geometrik sekilleri icer. Renkler: koyu mavi, siyah ve gumus.',
    communityGuidelines: ['siddet', 'nefret', 'uyusturuc', 'cinsel icerik', 'spam', 'yaniltici bilgi'],
  },
  motivation: {
    name: 'Motivasyon',
    youtubeCategory: 'People & Blogs',
    description: `Basari yolunda seni ilham ver. Motivasyon, kisisel gelisim, liderlik ve hayat dersleri. Her gun yeni bir hikaye, her hikayede yeni bir ders. Seni en iyi versiyonun olmaya davet ediyorum.`,
    keywords: ['motivasyon', 'basari', 'hedef', 'ilham', 'gelisim', 'liderlik', 'kisisel', 'hayat', 'dersi', 'hikaye', 'donusum', 'kapasite', 'potansiyel', 'disiplin', 'hayal'],
    tags: ['#motivasyon', '#basari', '#hedef', '#ilham', '#gelisim', '#liderlik', '#hayat', '#donusum'],
    brandingPrompt: 'Dinamik, enerjik ve ilham verici bir motivasyon kanali logosunu tasarla. Yukselen grafik, isik, ok ve insan figuru icer. Renkler: altin, turuncu, siyah ve beyaz.',
    communityGuidelines: ['nefret', 'ayrimcilik', 'yaniltici bilgi', 'spam', 'siddet'],
  },
  health: {
    name: 'Saglik',
    youtubeCategory: 'Howto & Style',
    description: `Saglikli yasamin sirlari burada. Beslenme, fitness, mental saglik ve wellness. Bilimsel temelli, pratik ve uygulanabilir tuyolar. Sagligin en buyuk yatirim oldugunu biliyoruz.`,
    keywords: ['saglik', 'beslenme', 'fitness', 'wellness', 'yasam', 'spor', 'egzersiz', 'diyet', 'mental', 'meditasyon', 'yoga', 'uyku', 'stres', 'bagisiklik', 'doktor'],
    tags: ['#saglik', '#beslenme', '#fitness', '#wellness', '#yasam', '#spor', '#egzersiz', '#mental'],
    brandingPrompt: 'Temiz, modern ve saglikli bir saglik kanali logosunu tasarla. Kalp, yaprak, dumbbells ve tibbi semboller icer. Renkler: yesil, beyaz, acik mavi ve gumus.',
    communityGuidelines: ['yanlis tibbi bilgi', 'spam', 'reklam', 'uyusturuc', 'yaniltici urun'],
  },
  knowledge: {
    name: 'Bilgi',
    youtubeCategory: 'Education',
    description: `Merak edenlerin cenneti. Ilginc gercekler, bilimsel kesifler, tarih ve teknoloji. Her videoda yeni bir bilgi, her bilgide yeni bir dunya. Ogrenmeyi asla birakma.`,
    keywords: ['bilgi', 'egitim', 'ogrenme', 'merak', 'kesif', 'bilim', 'tarih', 'teknoloji', 'gercek', 'arastirma', 'belgesel', 'deney', 'teori', 'kanit', 'analiz'],
    tags: ['#bilgi', '#egitim', '#ogrenme', '#merak', '#kesif', '#bilim', '#tarih', '#teknoloji'],
    brandingPrompt: 'Akademik, merakli ve kesif odakli bir bilgi kanali logosunu tasarla. Kitap, ampul, teleskop ve soru isareti icer. Renkler: lacivert, altin, beyaz ve gri.',
    communityGuidelines: ['yaniltici bilgi', 'hoax', 'komplo teorileri', 'spam', 'nefret'],
  },
  finance: {
    name: 'Finans',
    youtubeCategory: 'Howto & Style',
    description: `Finansal ozgurluge giden yol. Para yonetimi, yatirim, kripto, borsa ve is. Bilimsel ve pratik rehberlik. Zenginlik sadece sans degil, bilgi ve disiplinin sonucu.`,
    keywords: ['finans', 'para', 'yatirim', 'borsa', 'kripto', 'is', 'girisim', 'butce', 'tasarruf', 'gelir', 'pasif', 'portfoy', 'risk', 'strateji', 'ekonomi'],
    tags: ['#finans', '#para', '#yatirim', '#borsa', '#kripto', '#is', '#girisim', '#butce'],
    brandingPrompt: 'Profesyonel, guvenilir ve basarili bir finans kanali logosunu tasarla. Para, grafik, ok ve guvenlik sembolu icer. Renkler: koyu yesil, altin, beyaz ve gri.',
    communityGuidelines: ['yanlis finansal tavsiye', 'dolandiricilik', 'spam', 'reklam', 'pump & dump'],
  },
};

// --- Kanal Aciklamasi Olustur ----------------------------------------------
export function generateChannelDescription(category, channelName) {
  const template = CHANNEL_TEMPLATES[category];
  if (!template) return null;

  return {
    channelName,
    category: template.name,
    description: template.description,
    youtubeCategory: template.youtubeCategory,
    recommendation: ` Bu aciklama ${template.name} kategorisi icin SEO uyumlu ve izleyici cekici olarak tasarlandi.`,
  };
}

// --- Kanal Anahtar Kelimeleri Olustur --------------------------------------
export function generateChannelKeywords(category) {
  const template = CHANNEL_TEMPLATES[category];
  if (!template) return null;

  return {
    category: template.name,
    keywords: template.keywords,
    tags: template.tags,
    recommendation: ` Bu ${template.keywords.length} anahtar kelime ve ${template.tags.length} etiket, YouTube algoritmasinin kanalinizi dogru sinifa yerlestirmesine yardimci olacak.`,
  };
}

// --- Gorsel Kimlik Rehberi (Branding Guide) --------------------------------
export function generateBrandingGuide(category, channelName) {
  const template = CHANNEL_TEMPLATES[category];
  if (!template) return null;

  return {
    channelName,
    category: template.name,
    profilePicturePrompt: template.brandingPrompt,
    bannerPrompt: `${channelName} kanali icin genis bir YouTube banner tasarla. ${template.brandingPrompt} Banner 2560x1440 piksel olmali.`,
    watermarkPrompt: `${channelName} kanali icin sag alt koseye yerlestirilecek "Abone Ol" butonu tasarla. Seffaf arka plan, beyaz ve renkli (${template.name} kategorisine uygun) tasarim.`,
    colorScheme: {
      primary: template.name === 'Psikoloji' ? '#1a1a2e' : 
               template.name === 'Motivasyon' ? '#ff6b35' : 
               template.name === 'Saglik' ? '#2ecc71' : 
               template.name === 'Bilgi' ? '#3498db' : '#27ae60',
      secondary: template.name === 'Psikoloji' ? '#16213e' : 
                 template.name === 'Motivasyon' ? '#ffa500' : 
                 template.name === 'Saglik' ? '#27ae60' : 
                 template.name === 'Bilgi' ? '#2980b9' : '#229954',
    },
    recommendation: ` Bu gorseller ${template.name} kategorisinin profesyonel ve cekici gorunumunu yansitacak.`,
  };
}

// --- Yukleme Varsayilanlari (Upload Defaults) ------------------------------
export function generateUploadDefaults(category, channelName) {
  const template = CHANNEL_TEMPLATES[category];
  if (!template) return null;

  const defaultDescription = `${channelName} - ${template.name} Kanali

Videodaki konular hakkinda daha fazla bilgi icin:
📌 Kanalimiza abone olun: https://youtube.com/@${channelName.replace(/\s+/g, '')}
📌 Diger videolarimiz: [Playlist Linki]
📌 Sosyal Medya: [Instagram/Twitter]

${template.keywords.slice(0, 5).join(', ')}

Tesekkurler!`;

  return {
    category: template.name,
    defaultDescription,
    defaultLanguage: 'tr',
    defaultComments: 'ALLOW',
    defaultLicense: 'STANDARD_YOUTUBE_LICENSE',
    defaultCategory: template.youtubeCategory,
    tags: template.tags,
    recommendation: ` Bu varsayilanlar her video yuklediginizde otomatik olarak uygulanacak.`,
  };
}

// --- Topluluk Ayarlari (Community Guidelines) ------------------------------
export function generateCommunitySettings(category) {
  const template = CHANNEL_TEMPLATES[category];
  if (!template) return null;

  return {
    category: template.name,
    blockedWords: template.communityGuidelines,
    autoModeration: true,
    commentApprovalRequired: false,
    recommendation: ` Bu ${template.communityGuidelines.length} kelime otomatik olarak engellenenler listesine eklenecek.`,
  };
}

// --- Tam Kanal Kurulum Paketi (Complete Channel Setup Kit) ------------------
export function generateCompleteChannelSetupKit(category, channelName) {
  const description = generateChannelDescription(category, channelName);
  const keywords = generateChannelKeywords(category);
  const branding = generateBrandingGuide(category, channelName);
  const uploadDefaults = generateUploadDefaults(category, channelName);
  const community = generateCommunitySettings(category);

  return {
    timestamp: new Date().toISOString(),
    channelName,
    category: CHANNEL_TEMPLATES[category]?.name || 'Bilinmiyor',
    setupKit: {
      description,
      keywords,
      branding,
      uploadDefaults,
      community,
    },
    instructions: [
      '1. YouTube Studio\'ya gidin -> Ayarlar -> Kanal Bilgileri',
      '2. "Kanal Aciklamasi" alanina yukaridaki metni yapistirin',
      '3. "Kanal Anahtar Kelimeleri" alanina keywords listesini yapistirin',
      '4. Profil Resmi ve Banner icin branding promptlarini kullanarak gorseller olusturun',
      '5. Varsayilan yukleme ayarlarini ayarlayin',
      '6. Topluluk ayarlarinda engellenen kelimeleri ekleyin',
    ],
    estimatedSetupTime: '15-20 dakika',
    recommendation: ' Bu paket tamamlandiginda kanaliniz profesyonel ve SEO uyumlu olacaktir.',
  };
}

// --- Kanal Saglik Kontrolu (Channel Health Check) ----------------------------
export function performChannelHealthCheck(channelData) {
  const checks = {
    descriptionComplete: channelData.description && channelData.description.length > 100,
    keywordsAdded: channelData.keywords && channelData.keywords.length > 5,
    profilePictureSet: !!channelData.profilePictureUrl,
    bannerSet: !!channelData.bannerUrl,
    categorySelected: !!channelData.youtubeCategory,
    customUrlSet: !!channelData.customUrl,
  };

  const completedChecks = Object.values(checks).filter(Boolean).length;
  const totalChecks = Object.keys(checks).length;
  const healthScore = Math.round((completedChecks / totalChecks) * 100);

  return {
    channelName: channelData.channelName,
    healthScore,
    checks,
    completedChecks,
    totalChecks,
    status: healthScore < 50 ? 'POOR' : healthScore < 75 ? 'FAIR' : 'EXCELLENT',
    recommendation: healthScore < 75
      ? `️ Kanal kurulumu tamamlanmadi. Eksik ayarlar: ${Object.entries(checks).filter(([, v]) => !v).map(([k]) => k).join(', ')}`
      : ` Kanal kurulumu tamamlandi ve profesyonel gorunuyor!`,
  };
}

// --- Kategori Degisim Rehberi (Category Migration Guide) ------------------
export function generateCategoryMigrationGuide(oldCategory, newCategory) {
  const oldTemplate = CHANNEL_TEMPLATES[oldCategory];
  const newTemplate = CHANNEL_TEMPLATES[newCategory];

  if (!oldTemplate || !newTemplate) return null;

  return {
    oldCategory: oldTemplate.name,
    newCategory: newTemplate.name,
    warning: `️ Kategori degisimi kanalin performansini etkileyebilir. Lutfen dikkatli olun.`,
    changes: {
      description: `"${oldTemplate.description.substring(0, 50)}..." -> "${newTemplate.description.substring(0, 50)}..."`,
      keywords: `${oldTemplate.keywords.length} anahtar kelime -> ${newTemplate.keywords.length} anahtar kelime`,
      branding: `${oldTemplate.name} stili -> ${newTemplate.name} stili`,
    },
    recommendation: `Kategoriyi degistirmek istiyorsaniz, yeni kurulum paketini olusturun ve YouTube Studio'dan manuel olarak guncelleyin.`,
  };
}
