/**
 * Multi-Account Manager — Coklu Hesap Yoneticisi
 * ================================================
 * Her kanal icin izole tarayici profilleri ve guvenli gecis yonetimi
 */

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// --- Profil Yonetimi --------------------------------------------------------
export class MultiAccountManager {
  constructor(baseDataPath = './data/profiles') {
    this.baseDataPath = baseDataPath;
    this.ensureProfilesDirectory();
  }

  // Profiller klasorunu olustur
  ensureProfilesDirectory() {
    if (!fs.existsSync(this.baseDataPath)) {
      fs.mkdirSync(this.baseDataPath, { recursive: true });
    }
  }

  // Kanal icin izole profil olustur
  createChannelProfile(channelId, channelName, gmailAccount) {
    const profilePath = path.join(this.baseDataPath, channelId);
    
    if (!fs.existsSync(profilePath)) {
      fs.mkdirSync(profilePath, { recursive: true });
    }

    const profileConfig = {
      channelId,
      channelName,
      gmailAccount,
      createdAt: new Date().toISOString(),
      lastUsed: null,
      browserFingerprint: this.generateBrowserFingerprint(),
      sessionFiles: {
        cookies: path.join(profilePath, 'cookies.json'),
        localStorage: path.join(profilePath, 'localStorage.json'),
        sessionStorage: path.join(profilePath, 'sessionStorage.json'),
      },
      status: 'CREATED',
    };

    // Profil yapilandirmasini kaydet
    fs.writeFileSync(
      path.join(profilePath, 'profile.json'),
      JSON.stringify(profileConfig, null, 2)
    );

    return profileConfig;
  }

  // Tarayici Parmak Izi (Fingerprint) Olustur
  generateBrowserFingerprint() {
    const fingerprints = [
      {
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        screenResolution: '1920x1080',
        timezone: 'Europe/Istanbul',
        language: 'tr-TR',
      },
      {
        userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        screenResolution: '1440x900',
        timezone: 'Europe/Istanbul',
        language: 'tr-TR',
      },
      {
        userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        screenResolution: '1680x1050',
        timezone: 'Europe/Istanbul',
        language: 'tr-TR',
      },
    ];

    return fingerprints[Math.floor(Math.random() * fingerprints.length)];
  }

  // Profil Bilgilerini Getir
  getChannelProfile(channelId) {
    const profilePath = path.join(this.baseDataPath, channelId, 'profile.json');
    
    if (!fs.existsSync(profilePath)) {
      return null;
    }

    return JSON.parse(fs.readFileSync(profilePath, 'utf-8'));
  }

  // Tum Profilleri Listele
  getAllProfiles() {
    if (!fs.existsSync(this.baseDataPath)) {
      return [];
    }

    const profiles = [];
    const channels = fs.readdirSync(this.baseDataPath);

    for (const channel of channels) {
      const profilePath = path.join(this.baseDataPath, channel, 'profile.json');
      if (fs.existsSync(profilePath)) {
        profiles.push(JSON.parse(fs.readFileSync(profilePath, 'utf-8')));
      }
    }

    return profiles;
  }

  // Profil Durumunu Guncelle
  updateProfileStatus(channelId, status, lastUsed = true) {
    const profile = this.getChannelProfile(channelId);
    if (!profile) return null;

    profile.status = status;
    if (lastUsed) {
      profile.lastUsed = new Date().toISOString();
    }

    const profilePath = path.join(this.baseDataPath, channelId, 'profile.json');
    fs.writeFileSync(profilePath, JSON.stringify(profile, null, 2));

    return profile;
  }

  // Oturum Dosyasini Kaydet
  saveSessionData(channelId, sessionType, data) {
    const profile = this.getChannelProfile(channelId);
    if (!profile) return null;

    const sessionPath = profile.sessionFiles[sessionType];
    fs.writeFileSync(sessionPath, JSON.stringify(data, null, 2));

    return { channelId, sessionType, saved: true };
  }

  // Oturum Dosyasini Yukle
  loadSessionData(channelId, sessionType) {
    const profile = this.getChannelProfile(channelId);
    if (!profile) return null;

    const sessionPath = profile.sessionFiles[sessionType];
    if (!fs.existsSync(sessionPath)) {
      return null;
    }

    return JSON.parse(fs.readFileSync(sessionPath, 'utf-8'));
  }
}

// --- Akilli Gecis Yonetimi (Smart Switching) --------------------------------
export class SmartSwitcher {
  constructor(accountManager) {
    this.accountManager = accountManager;
    this.currentChannel = null;
    this.switchHistory = [];
  }

  // Kanal Degistir
  async switchToChannel(channelId, waitTime = 30000) {
    // Mevcut kanaldan cik
    if (this.currentChannel) {
      await this.exitChannel(this.currentChannel);
    }

    // Yeni kanala gir
    this.currentChannel = channelId;
    this.accountManager.updateProfileStatus(channelId, 'ACTIVE');

    // Gecis gecmisine ekle
    this.switchHistory.push({
      timestamp: new Date().toISOString(),
      from: this.switchHistory.length > 0 ? this.switchHistory[this.switchHistory.length - 1].to : null,
      to: channelId,
      waitTime,
    });

    // Bekleme suresi (YouTube'un ayni IP'den cok hizli gecisleri supheli gormemesi icin)
    await new Promise(resolve => setTimeout(resolve, waitTime));

    return {
      status: 'SWITCHED',
      channelId,
      profile: this.accountManager.getChannelProfile(channelId),
    };
  }

  // Kanaldan Cik
  async exitChannel(channelId) {
    this.accountManager.updateProfileStatus(channelId, 'INACTIVE');
    return { status: 'EXITED', channelId };
  }

  // Gecis Gecmisini Getir
  getSwitchHistory() {
    return {
      totalSwitches: this.switchHistory.length,
      history: this.switchHistory,
      currentChannel: this.currentChannel,
    };
  }
}

// --- Profil Denetim Raporu -------------------------------------------------
export function generateProfileAuditReport(accountManager) {
  const profiles = accountManager.getAllProfiles();
  
  const report = {
    timestamp: new Date().toISOString(),
    totalProfiles: profiles.length,
    profiles: profiles.map(p => ({
      channelId: p.channelId,
      channelName: p.channelName,
      gmailAccount: p.gmailAccount,
      status: p.status,
      createdAt: p.createdAt,
      lastUsed: p.lastUsed,
      fingerprint: {
        userAgent: p.browserFingerprint.userAgent.substring(0, 50) + '...',
        screenResolution: p.browserFingerprint.screenResolution,
      },
    })),
    recommendation: profiles.length > 0
      ? ` ${profiles.length} profil aktif ve izole durumda`
      : '️ Henuz profil olusturulmadi',
  };

  return report;
}

// --- Profil Guvenlik Kontrol -----------------------------------------------
export function validateProfileSecurity(profile) {
  const issues = [];
  const warnings = [];

  // Oturum dosyalari kontrol et
  if (!fs.existsSync(profile.sessionFiles.cookies)) {
    warnings.push('️ Cookies dosyasi henuz olusturulmadi');
  }

  // Parmak izi kontrol et
  if (!profile.browserFingerprint) {
    issues.push('❌ Tarayici parmak izi eksik');
  }

  // Durum kontrol et
  if (profile.status === 'INACTIVE') {
    warnings.push('️ Profil su anda inaktif');
  }

  return {
    profileId: profile.channelId,
    isSecure: issues.length === 0,
    issues,
    warnings,
    recommendation: issues.length === 0
      ? ' Profil guvenli'
      : '❌ Guvenlik sorunlari var',
  };
}

// --- Profil Temizleme (Cleanup) ---------------------------------------------
export function cleanupOldProfiles(accountManager, daysOld = 30) {
  const profiles = accountManager.getAllProfiles();
  const now = new Date();
  const cleanupReport = {
    timestamp: new Date().toISOString(),
    daysOld,
    cleanedProfiles: [],
    skippedProfiles: [],
  };

  for (const profile of profiles) {
    const lastUsed = new Date(profile.lastUsed || profile.createdAt);
    const daysSinceUsed = Math.floor((now - lastUsed) / (1000 * 60 * 60 * 24));

    if (daysSinceUsed > daysOld && profile.status === 'INACTIVE') {
      cleanupReport.cleanedProfiles.push({
        channelId: profile.channelId,
        daysSinceUsed,
        reason: 'Eski ve inaktif profil',
      });
      // Profil klasorunu sil
      const profilePath = path.join(accountManager.baseDataPath, profile.channelId);
      if (fs.existsSync(profilePath)) {
        fs.rmSync(profilePath, { recursive: true });
      }
    } else {
      cleanupReport.skippedProfiles.push({
        channelId: profile.channelId,
        daysSinceUsed,
        reason: daysSinceUsed <= daysOld ? 'Yakin zamanda kullanildi' : 'Aktif profil',
      });
    }
  }

  return cleanupReport;
}

// --- Profil Ihracat/Ithalati -----------------------------------------------
export function exportProfile(accountManager, channelId) {
  const profile = accountManager.getChannelProfile(channelId);
  if (!profile) return null;

  const exportData = {
    profile,
    sessions: {
      cookies: accountManager.loadSessionData(channelId, 'cookies'),
      localStorage: accountManager.loadSessionData(channelId, 'localStorage'),
      sessionStorage: accountManager.loadSessionData(channelId, 'sessionStorage'),
    },
    exportedAt: new Date().toISOString(),
  };

  return exportData;
}

export function importProfile(accountManager, channelId, exportedData) {
  // Profili olustur
  accountManager.createChannelProfile(
    channelId,
    exportedData.profile.channelName,
    exportedData.profile.gmailAccount
  );

  // Oturum verilerini yukle
  if (exportedData.sessions.cookies) {
    accountManager.saveSessionData(channelId, 'cookies', exportedData.sessions.cookies);
  }
  if (exportedData.sessions.localStorage) {
    accountManager.saveSessionData(channelId, 'localStorage', exportedData.sessions.localStorage);
  }
  if (exportedData.sessions.sessionStorage) {
    accountManager.saveSessionData(channelId, 'sessionStorage', exportedData.sessions.sessionStorage);
  }

  return { status: 'IMPORTED', channelId };
}
