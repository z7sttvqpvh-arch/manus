# Gemini Executive Shorts OS v8.0 — Kurulum Kilavuzu

## Sistem Gereksinimleri

- **Node.js:** v20+ (https://nodejs.org/)
- **FFmpeg:** Video işleme için (https://ffmpeg.org/)
- **Puppeteer:** Tarayıcı otomasyonu (otomatik kurulacak)
- **Port:** 3001 (değiştirilebilir)

## Kurulum Adımları

### 1. Bağımlılıkları Yükle

```bash
npm install
# veya
pnpm install
```

### 2. Dizinleri Oluştur

```bash
mkdir -p data storage/outputs storage/analysis logs
```

### 3. Sunucuyu Başlat

```bash
node server.js
```

Sunucu şu adreste çalışacak: `http://127.0.0.1:3001`

## Özellikler

- **Gemini Web Otomasyonu:** Tarayıcı aracılığıyla Gemini'ye bağlanma
- **Video Review & Repair:** Otomatik video analizi ve onarımı
- **Trend Tracking:** YouTube trendlerini izleme
- **Music Engine:** Duygusal müzik seçimi
- **Multi-Channel Support:** Birden fazla YouTube kanalı yönetimi

## API Endpoint'leri

### Durum Kontrol
- `GET /api/status` - Sistem durumu
- `GET /api/state` - Tüm veriler
- `GET /api/logs` - Son loglar

### Kanal Yönetimi
- `POST /api/channels` - Yeni kanal ekle
- `DELETE /api/channels/{id}` - Kanal sil
- `POST /api/channels/{id}/toggle` - Kanal aç/kapat

### Video İşleme
- `POST /api/run` - Video oluştur ve yayınla

### Tarayıcı Kontrolü
- `POST /api/browser/login` - Gemini/ChatGPT'ye giriş
- `GET /api/browser/status` - Tarayıcı durumu

### Ayarlar
- `POST /api/settings` - Ayarları güncelle

## Konfigürasyon

`server.js` içindeki `defaultDb` objesinde ayarlar bulunur:

```javascript
settings: {
  autoMode: false,              // Otomatik mod
  aiService: 'gemini',          // AI servisi
  publishThreshold: 80,         // Yayın eşiği
  repairThreshold: 65,          // Onarım eşiği
  maxRepairRounds: 3,           // Max onarım turu
  videoReviewEnabled: true,     // Video inceleme
  autoRepairEnabled: true,      // Otomatik onarım
}
```

## Sorun Giderme

### Sunucu başlamıyor
- Node.js sürümünü kontrol edin: `node --version`
- Port 3001'in açık olduğundan emin olun

### Gemini bağlantısı başarısız
- Tarayıcı otomasyonu başlatıldığında manuel giriş yapın
- Google hesabınızda 2FA varsa devre dışı bırakın

### Video işleme başarısız
- FFmpeg'in yüklü olduğundan emin olun: `ffmpeg -version`
- Pexels API key'ini kontrol edin

## Dosya Yapısı

```
gemini-shorts-os-v8/
├── server.js                    # Ana sunucu
├── browser-automation.js        # Tarayıcı otomasyonu
├── video-review.js              # Video analizi
├── video-repair.js              # Video onarımı
├── music-engine.js              # Müzik seçimi
├── trend-tracker.js             # Trend takibi
├── public/
│   └── index.html               # Dashboard
├── data/
│   └── db.json                  # Veritabanı
├── storage/
│   ├── outputs/                 # Oluşturulan videolar
│   └── analysis/                # Analiz sonuçları
└── logs/
    └── server.log               # Sunucu logları
```

## Lisans

MIT License - Ücretsiz kullanım

## Destek

Sorunlar için GitHub Issues'i kullanın veya geliştiriciyle iletişime geçin.
