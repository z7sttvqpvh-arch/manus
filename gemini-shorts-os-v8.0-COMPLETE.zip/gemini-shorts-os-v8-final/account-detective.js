/**
 * Account Detective — Hesap Analiz Modulu
 * ========================================
 * Hesap yasini, durumunu ve nis uyumlulugunu otomatik analiz eder
 */

// --- Hesap Durumu Kategorileri ---------------------------------------------
const ACCOUNT_STATUS = {
  NEW: {
    name: 'Yeni Hesap',
    daysOld: { min: 0, max: 14 },
    videoCount: { min: 0, max: 10 },
    strategy: 'WARM_UP',
    riskLevel: 'CRITICAL',
    uploadLimit: 1,
  },
  GROWING: {
    name: 'Gelisen Hesap',
    daysOld: { min: 15, max: 90 },
    videoCount: { min: 11, max: 50 },
    strategy: 'BALANCED',
    riskLevel: 'MEDIUM',
    uploadLimit: 3,
  },
  MATURE: {
    name: 'Olgun Hesap',
    daysOld: { min: 91, max: Infinity },
    videoCount: { min: 51, max: Infinity },
    strategy: 'AGGRESSIVE',
    riskLevel: 'LOW',
    uploadLimit: 5,
  },
};

// --- Hesap Analizi Fonksiyonu ----------------------------------------------
export function analyzeAccount(accountData) {
  const daysOld = calculateDaysOld(accountData.createdDate);
  const videoCount = accountData.videoCount || 0;
  const averageEngagement = accountData.averageEngagementRate || 0;

  let status = ACCOUNT_STATUS.NEW;

  // Hesap durumunu belirle
  if (daysOld > 90 && videoCount > 50) {
    status = ACCOUNT_STATUS.MATURE;
  } else if (daysOld > 14 && videoCount > 10) {
    status = ACCOUNT_STATUS.GROWING;
  }

  return {
    accountId: accountData.channelId,
    channelName: accountData.channelName,
    daysOld,
    videoCount,
    status: status.name,
    strategy: status.strategy,
    riskLevel: status.riskLevel,
    uploadLimit: status.uploadLimit,
    averageEngagement: Math.round(averageEngagement * 100) / 100,
    recommendation: generateRecommendation(status, daysOld, videoCount, averageEngagement),
  };
}

// --- Hesap Yasini Hesapla --------------------------------------------------
function calculateDaysOld(createdDate) {
  const now = new Date();
  const created = new Date(createdDate);
  return Math.floor((now - created) / (1000 * 60 * 60 * 24));
}

// --- Tavsiye Olustur -------------------------------------------------------
function generateRecommendation(status, daysOld, videoCount, avgEngagement) {
  let recommendation = '';

  if (status.name === 'Yeni Hesap') {
    recommendation = `️ Yeni hesap (${daysOld} gun). Warm-Up modunu aktif edin. Gunde 1 video yukleyin.`;
  } else if (status.name === 'Gelisen Hesap') {
    recommendation = ` Gelisen hesap (${daysOld} gun, ${videoCount} video). Kademeli hizi artirabilirsiniz.`;
  } else {
    recommendation = ` Olgun hesap (${daysOld} gun, ${videoCount} video). Agresif buyume yapabilirsiniz.`;
  }

  if (avgEngagement < 0.05) {
    recommendation += ` ️ Etkilesim orani dusuk (${(avgEngagement * 100).toFixed(2)}%), icerik kalitesini artirin.`;
  } else if (avgEngagement > 0.15) {
    recommendation += ` 🚀 Etkilesim orani yuksek (${(avgEngagement * 100).toFixed(2)}%), viral potansiyeli var!`;
  }

  return recommendation;
}

// --- Nis Uyumluluk Analizi -------------------------------------------------
export function analyzeNicheAlignment(accountData, newContentData) {
  const pastVideos = accountData.pastVideos || [];
  const pastKeywords = extractKeywordsFromVideos(pastVideos);
  const newKeywords = extractKeywordsFromContent(newContentData);

  // Anahtar kelime cakismasini hesapla
  const alignment = calculateKeywordAlignment(pastKeywords, newKeywords);

  return {
    accountId: accountData.channelId,
    pastNiche: pastKeywords.slice(0, 5),
    proposedNiche: newKeywords.slice(0, 5),
    alignmentScore: Math.round(alignment * 100),
    isAligned: alignment > 0.7,
    recommendation: alignment > 0.7
      ? ` Yeni icerik kanalin mevcut nis ile uyumlu (${Math.round(alignment * 100)}%)`
      : `️ Yeni icerik kanalin nis ile az uyumlu (${Math.round(alignment * 100)}%). Anahtar kelimeleri ayarlayin.`,
  };
}

// --- Videolardan Anahtar Kelimeler Cikart ----------------------------------
function extractKeywordsFromVideos(videos) {
  const keywords = {};

  for (const video of videos) {
    const title = (video.title || '').toLowerCase();
    const tags = (video.tags || []).map(t => t.toLowerCase());
    const description = (video.description || '').toLowerCase();

    // Baslik ve etiketlerden anahtar kelimeleri cikart
    const allText = `${title} ${tags.join(' ')} ${description}`;
    const words = allText.match(/\b\w{4,}\b/g) || [];

    for (const word of words) {
      keywords[word] = (keywords[word] || 0) + 1;
    }
  }

  // En sik kullanilan kelimeleri dondur
  return Object.entries(keywords)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 20)
    .map(([word]) => word);
}

// --- Icerikten Anahtar Kelimeler Cikart ------------------------------------
function extractKeywordsFromContent(contentData) {
  const title = (contentData.title || '').toLowerCase();
  const tags = (contentData.tags || []).map(t => t.toLowerCase());
  const description = (contentData.description || '').toLowerCase();

  const allText = `${title} ${tags.join(' ')} ${description}`;
  const words = allText.match(/\b\w{4,}\b/g) || [];

  // Tekrar eden kelimeleri say
  const keywords = {};
  for (const word of words) {
    keywords[word] = (keywords[word] || 0) + 1;
  }

  return Object.entries(keywords)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 20)
    .map(([word]) => word);
}

// --- Anahtar Kelime Uyumlulugu Hesapla --------------------------------------
function calculateKeywordAlignment(pastKeywords, newKeywords) {
  if (pastKeywords.length === 0 || newKeywords.length === 0) {
    return 0;
  }

  const pastSet = new Set(pastKeywords);
  const newSet = new Set(newKeywords);

  const intersection = [...pastSet].filter(k => newSet.has(k)).length;
  const union = new Set([...pastSet, ...newSet]).size;

  return intersection / union;
}

// --- Dinamik Strateji Belirleme --------------------------------------------
export function determineDynamicStrategy(accountAnalysis) {
  const status = accountAnalysis.status;
  const riskLevel = accountAnalysis.riskLevel;
  const uploadLimit = accountAnalysis.uploadLimit;

  const strategies = {
    WARM_UP: {
      name: 'Isinma Stratejisi',
      enabled: true,
      humanInteraction: true,
      nicheValidation: 'STRICT',
      engagementStarter: true,
      uploadCadence: 'GRADUAL',
      description: 'Yeni hesap icin guvenli ve kademeli buyume',
    },
    BALANCED: {
      name: 'Dengeli Strateji',
      enabled: true,
      humanInteraction: false,
      nicheValidation: 'FLEXIBLE',
      engagementStarter: false,
      uploadCadence: 'MODERATE',
      description: 'Gelisen hesap icin dengeli buyume',
    },
    AGGRESSIVE: {
      name: 'Agresif Strateji',
      enabled: false,
      humanInteraction: false,
      nicheValidation: 'MINIMAL',
      engagementStarter: false,
      uploadCadence: 'FAST',
      description: 'Olgun hesap icin maksimum buyume',
    },
  };

  const selectedStrategy = strategies[accountAnalysis.strategy] || strategies.BALANCED;

  return {
    accountId: accountAnalysis.accountId,
    strategy: selectedStrategy.name,
    config: selectedStrategy,
    uploadLimit,
    riskLevel,
    recommendation: `${selectedStrategy.description} - Gunde ${uploadLimit} video yukleyebilirsiniz.`,
  };
}

// --- Hesap Saglik Raporu ---------------------------------------------------
export function generateAccountHealthReport(accountData) {
  const analysis = analyzeAccount(accountData);
  const strategy = determineDynamicStrategy(analysis);

  let healthScore = 50;

  // Hesap yasi
  if (analysis.daysOld > 90) healthScore += 20;
  else if (analysis.daysOld > 30) healthScore += 10;

  // Video sayisi
  if (analysis.videoCount > 50) healthScore += 20;
  else if (analysis.videoCount > 20) healthScore += 10;

  // Etkilesim
  if (analysis.averageEngagement > 0.15) healthScore += 20;
  else if (analysis.averageEngagement > 0.05) healthScore += 10;

  // Spam belirtileri
  if (accountData.hasSpamWarnings) healthScore -= 30;
  if (accountData.hasStrikes) healthScore -= 50;

  return {
    timestamp: new Date().toISOString(),
    accountId: accountData.channelId,
    channelName: accountData.channelName,
    analysis,
    strategy,
    healthScore: Math.max(0, Math.min(100, healthScore)),
    healthStatus: healthScore < 30 ? 'POOR' : healthScore < 60 ? 'FAIR' : healthScore < 80 ? 'GOOD' : 'EXCELLENT',
    recommendation: `${analysis.recommendation} Strateji: ${strategy.recommendation}`,
  };
}

// --- Toplu Hesap Analiz Raporu ---------------------------------------------
export function generateBulkAccountReport(accountsData) {
  const reports = accountsData.map(account => generateAccountHealthReport(account));

  const summary = {
    timestamp: new Date().toISOString(),
    totalAccounts: reports.length,
    newAccounts: reports.filter(r => r.analysis.status === 'Yeni Hesap').length,
    growingAccounts: reports.filter(r => r.analysis.status === 'Gelisen Hesap').length,
    matureAccounts: reports.filter(r => r.analysis.status === 'Olgun Hesap').length,
    averageHealthScore: Math.round(reports.reduce((sum, r) => sum + r.healthScore, 0) / reports.length),
    reports,
  };

  return summary;
}

// --- Hesap Gecis Tavsiyesi (Account Upgrade) -------------------------------
export function suggestAccountUpgrade(accountAnalysis) {
  const daysUntilUpgrade = calculateDaysUntilUpgrade(accountAnalysis);

  return {
    accountId: accountAnalysis.accountId,
    currentStatus: accountAnalysis.status,
    nextStatus: getNextStatus(accountAnalysis.status),
    daysUntilUpgrade,
    recommendation: daysUntilUpgrade > 0
      ? `⏳ ${daysUntilUpgrade} gun sonra hesap otomatik olarak "${getNextStatus(accountAnalysis.status)}" durumuna gececek`
      : ` Hesap su anda en yuksek seviyede`,
  };
}

function calculateDaysUntilUpgrade(analysis) {
  if (analysis.status === 'Yeni Hesap') {
    return Math.max(0, 14 - analysis.daysOld);
  } else if (analysis.status === 'Gelisen Hesap') {
    return Math.max(0, 90 - analysis.daysOld);
  }
  return 0;
}

function getNextStatus(currentStatus) {
  if (currentStatus === 'Yeni Hesap') return 'Gelisen Hesap';
  if (currentStatus === 'Gelisen Hesap') return 'Olgun Hesap';
  return 'Olgun Hesap';
}
