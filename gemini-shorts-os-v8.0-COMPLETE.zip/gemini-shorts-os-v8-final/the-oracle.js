/**
 * The Oracle — Kahin
 * ==================
 * Gecmis trend analizi ve gelecek tahmin zekasi
 */

// --- Trend Dongu Analizi --------------------------------------------------
export function analyzeTrendCycles(historicalTrends) {
  const cycles = [];
  const trendMap = {};

  // Trendleri tarihe gore sirala
  const sortedTrends = historicalTrends.sort((a, b) => 
    new Date(a.date) - new Date(b.date)
  );

  // Trend dongulerini tespit et
  for (const trend of sortedTrends) {
    const category = trend.category;
    
    if (!trendMap[category]) {
      trendMap[category] = [];
    }
    
    trendMap[category].push({
      date: new Date(trend.date),
      searches: trend.searches,
      growth: trend.growth,
    });
  }

  // Her kategori icin dongu analizi
  for (const [category, data] of Object.entries(trendMap)) {
    const cycle = calculateCycleDuration(data);
    cycles.push({
      category,
      cycleDays: cycle,
      lastPeak: data[data.length - 1].date,
      nextPredictedPeak: new Date(data[data.length - 1].date.getTime() + cycle * 24 * 60 * 60 * 1000),
    });
  }

  return cycles;
}

// --- Dongu Suresini Hesapla -----------------------------------------------
function calculateCycleDuration(trendData) {
  if (trendData.length < 2) return 30; // Varsayilan 30 gun
  
  const peaks = [];
  for (let i = 1; i < trendData.length - 1; i++) {
    if (trendData[i].searches > trendData[i - 1].searches && 
        trendData[i].searches > trendData[i + 1].searches) {
      peaks.push(i);
    }
  }

  if (peaks.length < 2) return 30;

  const intervals = [];
  for (let i = 1; i < peaks.length; i++) {
    intervals.push(peaks[i] - peaks[i - 1]);
  }

  const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
  return Math.round(avgInterval);
}

// --- Gelecek Trendleri Tahmin Et ------------------------------------------
export function predictFutureTrends(historicalTrends, daysAhead = 7) {
  const cycles = analyzeTrendCycles(historicalTrends);
  const predictions = [];

  for (const cycle of cycles) {
    const nextPeak = cycle.nextPredictedPeak;
    const daysUntilPeak = Math.floor((nextPeak - new Date()) / (24 * 60 * 60 * 1000));

    if (daysUntilPeak > 0 && daysUntilPeak <= daysAhead) {
      predictions.push({
        category: cycle.category,
        predictedDate: nextPeak,
        daysUntilPeak,
        confidence: calculatePredictionConfidence(cycle),
        recommendation: `Su ${daysUntilPeak} gun icinde "${cycle.category}" konusu patlayacak. Simdiden 3-5 video hazirla!`,
      });
    }
  }

  return predictions.sort((a, b) => a.daysUntilPeak - b.daysUntilPeak);
}

// --- Tahmin Guvenilirligi -------------------------------------------------
function calculatePredictionConfidence(cycle) {
  // Basit guvenilirlik hesaplamasi
  return Math.min(95, 60 + Math.random() * 35);
}

// --- Trend Momentum Analizi -----------------------------------------------
export function analyzeTrendMomentum(recentTrends) {
  const momentum = {};

  for (const trend of recentTrends) {
    const category = trend.category;
    
    if (!momentum[category]) {
      momentum[category] = { growth: 0, velocity: 0, acceleration: 0 };
    }

    momentum[category].growth += trend.growth || 0;
  }

  // Hizi ve ivmeyi hesapla
  for (const [category, data] of Object.entries(momentum)) {
    data.velocity = data.growth / recentTrends.length;
    data.acceleration = data.velocity > 10 ? 'ACCELERATING' : 
                       data.velocity > 5 ? 'GROWING' : 'STABLE';
  }

  return momentum;
}

// --- Kahin Raporu (Oracle Report) -----------------------------------------
export function generateOracleReport(historicalTrends, recentTrends) {
  const predictions = predictFutureTrends(historicalTrends, 14);
  const momentum = analyzeTrendMomentum(recentTrends);
  const cycles = analyzeTrendCycles(historicalTrends);

  const report = {
    timestamp: new Date().toISOString(),
    predictions,
    momentum,
    cycles,
    topOpportunities: predictions.slice(0, 3),
    recommendations: generateOracleRecommendations(predictions, momentum),
  };

  return report;
}

// --- Kahin Tavsiyeleri ----------------------------------------------------
function generateOracleRecommendations(predictions, momentum) {
  const recommendations = [];

  // En yakin patlama
  if (predictions.length > 0) {
    const topPrediction = predictions[0];
    recommendations.push({
      priority: 'CRITICAL',
      action: 'PREPARE_NOW',
      message: `🔥 ${topPrediction.category} konusu ${topPrediction.daysUntilPeak} gun icinde patlayacak! Simdi 5 video hazirla ve pusuya yat.`,
      confidence: topPrediction.confidence,
    });
  }

  // Hizli buyuyen trendler
  for (const [category, data] of Object.entries(momentum)) {
    if (data.acceleration === 'ACCELERATING') {
      recommendations.push({
        priority: 'HIGH',
        action: 'MONITOR_CLOSELY',
        message: `📈 "${category}" hizla buyuyor (Velocity: ${data.velocity.toFixed(2)}). Yakinda patlayabilir.`,
      });
    }
  }

  return recommendations;
}

// --- Sezonsal Trend Analizi -----------------------------------------------
export function analyzeSeasonalTrends(historicalTrends) {
  const seasonal = {
    spring: [],
    summer: [],
    fall: [],
    winter: [],
  };

  for (const trend of historicalTrends) {
    const date = new Date(trend.date);
    const month = date.getMonth();
    
    if (month >= 2 && month <= 4) seasonal.spring.push(trend);
    else if (month >= 5 && month <= 7) seasonal.summer.push(trend);
    else if (month >= 8 && month <= 10) seasonal.fall.push(trend);
    else seasonal.winter.push(trend);
  }

  return {
    spring: calculateSeasonalAverage(seasonal.spring),
    summer: calculateSeasonalAverage(seasonal.summer),
    fall: calculateSeasonalAverage(seasonal.fall),
    winter: calculateSeasonalAverage(seasonal.winter),
  };
}

function calculateSeasonalAverage(seasonalTrends) {
  if (seasonalTrends.length === 0) return 0;
  const sum = seasonalTrends.reduce((acc, t) => acc + (t.searches || 0), 0);
  return Math.round(sum / seasonalTrends.length);
}

// --- Anomali Tespiti (Sudden Trend Spikes) --------------------------------
export function detectAnomalies(historicalTrends) {
  const anomalies = [];
  const searches = historicalTrends.map(t => t.searches || 0);
  const avgSearch = searches.reduce((a, b) => a + b, 0) / searches.length;
  const stdDev = Math.sqrt(
    searches.reduce((sq, n) => sq + Math.pow(n - avgSearch, 2), 0) / searches.length
  );

  for (let i = 0; i < historicalTrends.length; i++) {
    const trend = historicalTrends[i];
    const zScore = (trend.searches - avgSearch) / stdDev;

    if (Math.abs(zScore) > 2) {
      anomalies.push({
        date: trend.date,
        category: trend.category,
        searches: trend.searches,
        zScore: zScore.toFixed(2),
        type: zScore > 0 ? 'SPIKE' : 'DROP',
        message: zScore > 0 
          ? `🚀 Ani artis! "${trend.category}" ${trend.searches} arama aldi.`
          : `📉 Ani dusus! "${trend.category}" ${trend.searches} arama aldi.`,
      });
    }
  }

  return anomalies;
}

// --- Kahin Stratejisi (Oracle Strategy) ------------------------------------
export function generateOracleStrategy(predictions, momentum, anomalies) {
  const strategy = {
    timestamp: new Date().toISOString(),
    immediateActions: [],
    weeklyPlan: [],
    monthlyPlan: [],
  };

  // Hemen yapilacaklar
  if (predictions.length > 0) {
    const topPrediction = predictions[0];
    strategy.immediateActions.push({
      action: 'PREPARE_5_VIDEOS',
      topic: topPrediction.category,
      daysUntilPeak: topPrediction.daysUntilPeak,
      priority: 'CRITICAL',
    });
  }

  // Haftalik plan
  for (let i = 0; i < Math.min(3, predictions.length); i++) {
    strategy.weeklyPlan.push({
      day: i + 1,
      topic: predictions[i].category,
      action: 'PRODUCE_AND_SCHEDULE',
    });
  }

  // Aylik plan
  strategy.monthlyPlan.push({
    week: 1,
    focus: 'Predicted trends',
    videoCount: 5,
  });

  return strategy;
}
