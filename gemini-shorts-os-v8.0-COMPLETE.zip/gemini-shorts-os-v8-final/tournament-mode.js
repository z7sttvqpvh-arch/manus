/**
 * Tournament Mode — Video Turnuvasi Modu
 * =======================================
 * Sistem tek bir konu icin 3 farkli video varyasyonu uretir ve
 * Gemini'ye "Yaristirir". Sadece sampiyon video yayinlanir.
 */

import * as browser from './browser-automation.js';

// --- Turnuva Varyasyonlari --------------------------------------------------
const TOURNAMENT_VARIANTS = [
  {
    id: 'variant_a',
    name: 'Variant A: Aggressive Hook',
    description: 'Cok guclu, merak uyandirici bir hook ile baslayan versiyon',
    hookStyle: 'shock',
    pacing: 'fast',
    musicIntensity: 'high',
    colorFilter: 'vibrant',
  },
  {
    id: 'variant_b',
    name: 'Variant B: Mysterious Hook',
    description: 'Gizemli ve yavas acilisli, derin bir versiyon',
    hookStyle: 'mystery',
    pacing: 'slow-to-fast',
    musicIntensity: 'medium',
    colorFilter: 'vintage',
  },
  {
    id: 'variant_c',
    name: 'Variant C: Direct Hook',
    description: 'Dogrudan ve net acilisli, pratik bir versiyon',
    hookStyle: 'direct',
    pacing: 'moderate',
    musicIntensity: 'medium',
    colorFilter: 'neutral',
  },
];

// --- Turnuva Varyasyonlarini Olustur ----------------------------------------
export function generateTournamentVariants(topic, category, baseContent) {
  const variants = TOURNAMENT_VARIANTS.map((variant, index) => ({
    ...variant,
    topic,
    category,
    content: baseContent, // Ayni icerik, farkli sunum
    variantNumber: index + 1,
    createdAt: new Date().toISOString(),
    scores: {
      scrollStop: null,
      engagement: null,
      retention: null,
      overall: null,
    },
  }));

  return variants;
}

// --- Turnuva Varyasyonlarini Gemini'ye Yaristir ----------------------------
export async function runTournament(variants) {
  console.log(`🏆 Turnuva basliyor! ${variants.length} video yarisacak...`);

  const variantDescriptions = variants
    .map((v, i) => `${i + 1}. ${v.name}: ${v.description}`)
    .join('\n');

  const prompt = `Asagidaki 3 video varyasyonunu degerlendir. Hangi versiyon YouTube Shorts'ta daha cok izlenir ve izleyiciyi daha uzun sure tutar?

${variantDescriptions}

Hepsi ayni icerigi iceriyor, sadece sunus sekli (hook stili, muzik, renk, hiz) farkli.

Cevap JSON formatinda (baska hicbir sey yazma):
{
  "scores": [
    {"variant": 1, "scrollStopScore": 92, "engagementScore": 88, "retentionScore": 85, "reason": "Cok guclu hook, izleyiciyi hemen yakalar"},
    {"variant": 2, "scrollStopScore": 78, "engagementScore": 72, "retentionScore": 70, "reason": "Gizemli ama biraz yavas"},
    {"variant": 3, "scrollStopScore": 65, "engagementScore": 68, "retentionScore": 62, "reason": "Dogrudan ama sikici"}
  ],
  "champion": 1,
  "reasoning": "Variant A en yuksek scroll-stop gucune ve tutulma oranina sahip"
}`;

  try {
    const response = await browser.sendMessageToGemini(prompt);
    const jsonMatch = response.match(/\{[\s\S]*\}/);

    if (!jsonMatch) {
      console.warn(' Turnuva sonucu JSON bulunamadi, varsayilan skor veriliyor');
      return assignDefaultTournamentScores(variants);
    }

    const tournamentResult = JSON.parse(jsonMatch[0]);

    // Skorlari varyantlara ata
    for (const score of tournamentResult.scores) {
      const variant = variants[score.variant - 1];
      if (variant) {
        variant.scores.scrollStop = score.scrollStopScore;
        variant.scores.engagement = score.engagementScore;
        variant.scores.retention = score.retentionScore;
        variant.scores.overall = Math.round(
          (score.scrollStopScore * 0.5 + score.engagementScore * 0.3 + score.retentionScore * 0.2)
        );
        variant.scores.reason = score.reason;
      }
    }

    const champion = variants[tournamentResult.champion - 1];
    console.log(`🏆 Sampiyon: ${champion.name} (${champion.scores.overall} puan)`);

    return {
      variants,
      champion,
      championIndex: tournamentResult.champion - 1,
      reasoning: tournamentResult.reasoning,
    };
  } catch (e) {
    console.error('Turnuva hatasi:', e.message);
    return assignDefaultTournamentScores(variants);
  }
}

// --- Varsayilan Turnuva Skorlari --------------------------------------------
function assignDefaultTournamentScores(variants) {
  const scores = [
    { scrollStop: 92, engagement: 88, retention: 85 },
    { scrollStop: 78, engagement: 72, retention: 70 },
    { scrollStop: 65, engagement: 68, retention: 62 },
  ];

  variants.forEach((v, i) => {
    v.scores.scrollStop = scores[i]?.scrollStop || 70;
    v.scores.engagement = scores[i]?.engagement || 70;
    v.scores.retention = scores[i]?.retention || 70;
    v.scores.overall = Math.round(
      (v.scores.scrollStop * 0.5 + v.scores.engagement * 0.3 + v.scores.retention * 0.2)
    );
  });

  const champion = variants.reduce((prev, current) =>
    (prev.scores.overall || 0) > (current.scores.overall || 0) ? prev : current
  );

  return {
    variants,
    champion,
    championIndex: variants.indexOf(champion),
    reasoning: 'Varsayilan skor (Turnuva calismadi)',
  };
}

// --- Turnuva Raporu ---------------------------------------------------------
export function generateTournamentReport(tournamentResult) {
  const sortedVariants = [...tournamentResult.variants].sort(
    (a, b) => (b.scores.overall || 0) - (a.scores.overall || 0)
  );

  return {
    timestamp: new Date().toISOString(),
    totalVariants: tournamentResult.variants.length,
    champion: {
      name: tournamentResult.champion.name,
      variantNumber: tournamentResult.champion.variantNumber,
      scores: tournamentResult.champion.scores,
    },
    allScores: sortedVariants.map((v, i) => ({
      rank: i + 1,
      name: v.name,
      scrollStop: v.scores.scrollStop,
      engagement: v.scores.engagement,
      retention: v.scores.retention,
      overall: v.scores.overall,
      reason: v.scores.reason,
    })),
    reasoning: tournamentResult.reasoning,
    recommendation: ` ${tournamentResult.champion.name} secildi ve yayinlanacak.`,
    eliminatedVariants: sortedVariants.slice(1).map(v => ({
      name: v.name,
      reason: `${v.scores.overall} puan ile elenmistir`,
    })),
  };
}

// --- Turnuva Gecmisi Kaydet -------------------------------------------------
export function recordTournamentHistory(jobId, tournamentReport) {
  return {
    jobId,
    timestamp: new Date().toISOString(),
    championVariant: tournamentReport.champion.name,
    championScore: tournamentReport.champion.scores.overall,
    totalVariants: tournamentReport.totalVariants,
    eliminatedCount: tournamentReport.eliminatedVariants.length,
    report: tournamentReport,
  };
}

// --- Turnuva Performans Analizi ---------------------------------------------
export function analyzeTournamentPerformance(tournamentHistories = []) {
  if (tournamentHistories.length === 0) {
    return { message: 'Henuz turnuva gecmisi yok' };
  }

  const variantWins = {};
  const variantScores = {};

  for (const history of tournamentHistories) {
    const champion = history.championVariant;
    variantWins[champion] = (variantWins[champion] || 0) + 1;

    if (!variantScores[champion]) {
      variantScores[champion] = { scores: [], avgScore: 0 };
    }
    variantScores[champion].scores.push(history.championScore);
  }

  // Ortalama hesapla
  for (const [variant, data] of Object.entries(variantScores)) {
    const sum = data.scores.reduce((a, b) => a + b, 0);
    data.avgScore = Math.round(sum / data.scores.length);
  }

  const sorted = Object.entries(variantWins)
    .map(([variant, wins]) => ({
      variant,
      wins,
      avgScore: variantScores[variant].avgScore,
      winRate: Math.round((wins / tournamentHistories.length) * 100),
    }))
    .sort((a, b) => b.wins - a.wins);

  return {
    totalTournaments: tournamentHistories.length,
    bestPerformingVariant: sorted[0],
    allVariantPerformance: sorted,
    recommendation: `"${sorted[0].variant}" varyasyonu %${sorted[0].winRate} oraninda sampiyon olmustur. Bu stili tercih et.`,
  };
}

// --- Turnuva Stratejisi Onerileri --------------------------------------------
export function generateTournamentStrategy(tournamentPerformance) {
  const best = tournamentPerformance.bestPerformingVariant;

  return {
    recommendation: `Gelecekte "${best.variant}" tarzinda videolar uret`,
    reason: `Bu varyasyon ${best.wins} turnuvada sampiyon oldu (${best.winRate}% basari orani)`,
    avgScore: best.avgScore,
    strategy: `Gelecek videolarda "${best.variant}" ozelliklerini (hook stili, muzik yogunlugu, renk filtresi) kullan`,
  };
}
