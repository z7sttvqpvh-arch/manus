/**
 * Trend Tracker — Kategori Odakli Trend Takibi
 * =============================================
 * Kanalin kategorisine uygun populer konulari bulup sunuyor
 * - Google Trends benzeri veri kaynaklari
 * - Kategori filtrelemesi
 * - Gemini'ye sordurarak dogrulama
 */

import * as browser from './browser-automation.js';

// --- Kategori Trend Anahtar Kelimeleri ---------------------------------------
const CATEGORY_KEYWORDS = {
  psychology: {
    keywords: ['psikoloji', 'davranis', 'insan', 'zihin', 'bilinc', 'ego', 'manipulasyon', 'iliski', 'anksiyete', 'depresyon'],
    sources: ['psikoloji', 'davranis bilimi', 'sosyal psikoloji', 'klinik psikoloji'],
    trendTopics: [
      'Neden insanlar ayni hatalari tekrar eder',
      'Kendi kendini sabote etme davranisi',
      'Ilk izlenim neden bu kadar guclu',
      'Sosyal medya bagimliligi',
      'Kisilik bozukluklari',
      'Empati ve sempati farki',
      'Kaygi bozuklugu belirtileri',
      'Kendine guven nasil artar',
    ],
  },
  shock: {
    keywords: ['ilginc', 'sasirtici', 'inanilmaz', 'gercek', 'bilim', 'kesif', 'gizem', 'sir', 'siradisi'],
    sources: ['bilim', 'kesif', 'teknoloji', 'tarih'],
    trendTopics: [
      'Cogu kisinin bilmedigi zihinsel hata',
      'Bir kararin hayati nasil saptirdigi',
      'Kimsenin fark etmedigi gunluk tuzak',
      'Beyin hakkinda bilinmeyen gercekler',
      'Teknoloji ve insan beyni',
      'Tarihte gizli kalmis olaylar',
      'Bilim insanlarini sasirtan kesifler',
    ],
  },
  motivation: {
    keywords: ['motivasyon', 'basari', 'hedef', 'disiplin', 'aliskanlik', 'kisisel gelisim', 'basarisizlik', 'enerji', 'azim'],
    sources: ['kisisel gelisim', 'girisimcilik', 'basari', 'motivasyon'],
    trendTopics: [
      'Disiplini olduren gorunmez aliskanlik',
      'Ertelemenin arkasindaki gercek neden',
      'Ilerlemeyi durduran kucuk hata',
      'Basarili insanlarin sabah rutini',
      'Basarisizliktan ogrenme',
      'Hedef belirleme stratejileri',
      'Motivasyon nasil surdurulur',
      'Basari icin gerekli 1 sey',
    ],
  },
  knowledge: {
    keywords: ['bilgi', 'ogrenme', 'egitim', 'tarih', 'cografya', 'kultur', 'sanat', 'felsefe'],
    sources: ['egitim', 'tarih', 'cografya', 'kultur'],
    trendTopics: [
      'Tarihte en ilginc olaylar',
      'Ulkeler hakkinda bilinmeyen gercekler',
      'Sanat ve kultur hakkinda',
      'Felsefe ve dusunce',
      'Dil ve iletisim',
      'Insan medeniyeti',
      'Antik cag gizemleri',
    ],
  },
  finance: {
    keywords: ['para', 'yatirim', 'finans', 'borsa', 'kripto', 'tasarruf', 'gelir', 'zenginlik', 'ekonomi'],
    sources: ['finans', 'yatirim', 'ekonomi', 'is'],
    trendTopics: [
      'Para kazanmanin gizli yollari',
      'Zengin insanlarin aliskanliklari',
      'Kripto para hakkinda gercekler',
      'Borsa nasil calisir',
      'Pasif gelir kaynaklari',
      'Tasarruf stratejileri',
      'Finansal ozgurluk',
    ],
  },
  health: {
    keywords: ['saglik', 'beslenme', 'spor', 'fitness', 'yasam tarzi', 'uyku', 'stres', 'bagisiklik', 'wellness'],
    sources: ['saglik', 'tip', 'beslenme', 'spor'],
    trendTopics: [
      'Saglikli yasamin sirlari',
      'Beslenme hatalari',
      'Uyku kalitesi nasil artar',
      'Stres yonetimi teknikleri',
      'Egzersiz faydalari',
      'Bagisiklik sistemi guclendirme',
      'Yaslanmayi yavaslatma',
      'Mental saglik ipuclari',
    ],
  },
};

// --- Trend Onerisi Olustur (Kategori Bazli) ---------------------------------
export function generateCategoryTrends(category, count = 5) {
  const categoryData = CATEGORY_KEYWORDS[category] || CATEGORY_KEYWORDS.psychology;
  const trends = categoryData.trendTopics || [];
  
  // Rastgele sec
  const selected = [];
  for (let i = 0; i < Math.min(count, trends.length); i++) {
    const idx = Math.floor(Math.random() * trends.length);
    if (!selected.includes(trends[idx])) {
      selected.push(trends[idx]);
    }
  }

  return selected.map(trend => ({
    id: `trend_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
    topic: trend,
    category,
    source: 'category_pool',
    confidence: 0.85,
    timestamp: new Date().toISOString(),
  }));
}

// --- Trend Dogrulama (Gemini'ye Sor) ------------------------------------------
export async function validateTrendWithGemini(trend, category) {
  const prompt = `Asagidaki konu, "${category}" kategorisine uygun mu? Cevap sadece "evet" veya "hayir" olsun.

Konu: "${trend}"
Kategori: "${category}"

Cevap (sadece "evet" veya "hayir"):`;

  try {
    const response = await browser.sendMessageToGemini(prompt);
    const isValid = response.toLowerCase().includes('evet');
    return { valid: isValid, response };
  } catch (e) {
    console.error('Trend dogrulama hatasi:', e.message);
    return { valid: true, response: 'Hata nedeniyle varsayilan olarak gecerli kabul edildi' };
  }
}

// --- Trend Cesitlendirme (Ayni Konuyu Tekrar Onlemek) ------------------------
export function diversifyTrends(trends, recentTopics = []) {
  // Son 50 konuyu filtrele
  const recentSet = new Set(recentTopics.slice(0, 50));
  const filtered = trends.filter(t => !recentSet.has(t.topic));

  if (filtered.length === 0) {
    console.warn('Tum trendler son konularla eslesti, tum trendleri donduruyorum');
    return trends;
  }

  return filtered;
}

// --- Trend Puanlamasi (Popularite ve Relevans) --------------------------------
export function scoreTrend(trend, category) {
  const categoryData = CATEGORY_KEYWORDS[category] || CATEGORY_KEYWORDS.psychology;
  
  // Anahtar kelime eslestirmesi
  const keywordMatch = categoryData.keywords.filter(kw => 
    trend.topic.toLowerCase().includes(kw)
  ).length;

  const keywordScore = Math.min(100, keywordMatch * 15);
  const relevanceScore = trend.confidence ? trend.confidence * 100 : 80;
  const recencyScore = 90; // Varsayilan olarak yeni trendler yuksek skor alir

  const finalScore = Math.round((keywordScore * 0.3 + relevanceScore * 0.4 + recencyScore * 0.3));

  return {
    topic: trend.topic,
    keywordScore,
    relevanceScore,
    recencyScore,
    finalScore,
  };
}

// --- En Iyi Trend'i Sec ------------------------------------------------------
export function selectBestTrend(trends, category, recentTopics = []) {
  // Cesitlendirme
  const diversified = diversifyTrends(trends, recentTopics);

  // Puanlama
  const scored = diversified.map(t => ({
    ...t,
    score: scoreTrend(t, category),
  }));

  // En yuksek puan alan trend'i sec
  const best = scored.reduce((prev, current) => 
    (prev.score.finalScore > current.score.finalScore) ? prev : current
  );

  return best;
}

// --- Trend Onerisi Raporu ----------------------------------------------------
export function createTrendReport(trends, selectedTrend, category) {
  return {
    timestamp: new Date().toISOString(),
    category,
    totalTrends: trends.length,
    selectedTrend: selectedTrend.topic,
    selectedScore: selectedTrend.score.finalScore,
    allTrends: trends.map(t => ({
      topic: t.topic,
      score: scoreTrend(t, category).finalScore,
    })),
    recommendation: `"${selectedTrend.topic}" konusu ${category} kategorisi icin en uygun trend.`,
  };
}

// --- Trend Takibi Prompt'u (Gemini'ye Sordurma) ------------------------------
export function generateTrendPrompt(category, count = 5) {
  const categoryData = CATEGORY_KEYWORDS[category] || CATEGORY_KEYWORDS.psychology;
  
  return `${category.toUpperCase()} kategorisinde su anda populer olan ${count} adet konu/trend oner.

Kategori aciklamasi: ${categoryData.sources.join(', ')}

Oneriler su JSON formatinda olsun:
{
  "trends": [
    {"topic": "Konu 1", "reason": "Neden populer", "relevance": 0-100},
    {"topic": "Konu 2", "reason": "Neden populer", "relevance": 0-100}
  ]
}

JSON disinda HICBIR SEY yazma.`;
}

// --- Gemini'den Trend Onerisi Al ---------------------------------------------
export async function getTrendsFromGemini(category, count = 5) {
  try {
    const prompt = generateTrendPrompt(category, count);
    const response = await browser.sendMessageToGemini(prompt);

    // JSON'i cikart
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Trend JSON bulunamadi');

    const data = JSON.parse(jsonMatch[0]);
    const trends = (data.trends || []).map(t => ({
      id: `trend_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
      topic: t.topic,
      reason: t.reason,
      relevance: t.relevance || 80,
      category,
      source: 'gemini',
      timestamp: new Date().toISOString(),
    }));

    console.log(` Gemini'den ${trends.length} trend alindi`);
    return trends;

  } catch (e) {
    console.error('Gemini trend hatasi:', e.message);
    // Fallback: kategori havuzundan sec
    return generateCategoryTrends(category, count);
  }
}

// --- Haftalik Trend Raporu --------------------------------------------------
export function generateWeeklyTrendReport(trends, category) {
  const grouped = {};
  
  for (const trend of trends) {
    const week = Math.floor((Date.now() - new Date(trend.timestamp).getTime()) / (7 * 24 * 60 * 60 * 1000));
    if (!grouped[week]) grouped[week] = [];
    grouped[week].push(trend);
  }

  return {
    category,
    reportDate: new Date().toISOString(),
    weeklyBreakdown: Object.entries(grouped).map(([week, weekTrends]) => ({
      week: parseInt(week),
      count: weekTrends.length,
      topTrend: weekTrends[0]?.topic,
    })),
    totalTrends: trends.length,
  };
}
