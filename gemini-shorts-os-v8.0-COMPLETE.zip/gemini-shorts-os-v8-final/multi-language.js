/**
 * Multi-Language System — Coklu Dil Sistemi
 * ==========================================
 * Kuresel dil destegi, yerellestirilmis seslendirme ve kulturel adaptasyon
 */

// --- Desteklenen Diller ve Bolgesel Ayarlar --------------------------------
export const SUPPORTED_LANGUAGES = {
  tr: {
    name: 'Turkce',
    nativeName: 'Turkce',
    region: 'TR',
    locale: 'tr-TR',
    ttsVoice: 'tr-TR-Emel',
    ttsVoiceAlt: 'tr-TR-Ahmet',
    googleTrendsRegion: 'TR',
    newsRegion: 'tr_TR',
    youtubeLanguage: 'tr',
    youtubeRegion: 'TR',
    culturalNuance: 'Turk kulturu, aile degerleri, geleneksel bilgelik',
    viralPatterns: ['Saskinlik', 'Merak', 'Gurur', 'Guven'],
    timeZone: 'Europe/Istanbul',
  },
  en: {
    name: 'English',
    nativeName: 'English',
    region: 'US',
    locale: 'en-US',
    ttsVoice: 'en-US-Guy',
    ttsVoiceAlt: 'en-US-Jenny',
    googleTrendsRegion: 'US',
    newsRegion: 'en_US',
    youtubeLanguage: 'en',
    youtubeRegion: 'US',
    culturalNuance: 'Amerikan kulturu, bireysellik, basari, hizlilik',
    viralPatterns: ['Sok', 'Merak', 'Basari', 'Motivasyon'],
    timeZone: 'America/New_York',
  },
  es: {
    name: 'Spanish',
    nativeName: 'Español',
    region: 'ES',
    locale: 'es-ES',
    ttsVoice: 'es-ES-Alvaro',
    ttsVoiceAlt: 'es-ES-Conchita',
    googleTrendsRegion: 'ES',
    newsRegion: 'es_ES',
    youtubeLanguage: 'es',
    youtubeRegion: 'ES',
    culturalNuance: 'Ispanyol kulturu, tutkulu, sosyal, aile odakli',
    viralPatterns: ['Tutku', 'Merak', 'Sosyal', 'Huzun'],
    timeZone: 'Europe/Madrid',
  },
  de: {
    name: 'German',
    nativeName: 'Deutsch',
    region: 'DE',
    locale: 'de-DE',
    ttsVoice: 'de-DE-Stefan',
    ttsVoiceAlt: 'de-DE-Marlene',
    googleTrendsRegion: 'DE',
    newsRegion: 'de_DE',
    youtubeLanguage: 'de',
    youtubeRegion: 'DE',
    culturalNuance: 'Alman kulturu, kesinlik, teknoloji, verimlilik',
    viralPatterns: ['Teknik', 'Verimlilik', 'Guvenilirlik', 'Merak'],
    timeZone: 'Europe/Berlin',
  },
  fr: {
    name: 'French',
    nativeName: 'Francais',
    region: 'FR',
    locale: 'fr-FR',
    ttsVoice: 'fr-FR-Claude',
    ttsVoiceAlt: 'fr-FR-Celine',
    googleTrendsRegion: 'FR',
    newsRegion: 'fr_FR',
    youtubeLanguage: 'fr',
    youtubeRegion: 'FR',
    culturalNuance: 'Fransiz kulturu, sanat, kultur, sofistike',
    viralPatterns: ['Sanat', 'Kultur', 'Merak', 'Estetik'],
    timeZone: 'Europe/Paris',
  },
  it: {
    name: 'Italian',
    nativeName: 'Italiano',
    region: 'IT',
    locale: 'it-IT',
    ttsVoice: 'it-IT-Cosimo',
    ttsVoiceAlt: 'it-IT-Bianca',
    googleTrendsRegion: 'IT',
    newsRegion: 'it_IT',
    youtubeLanguage: 'it',
    youtubeRegion: 'IT',
    culturalNuance: 'Italyan kulturu, tutkulu, aile, yemek, sanat',
    viralPatterns: ['Tutku', 'Aile', 'Sanat', 'Merak'],
    timeZone: 'Europe/Rome',
  },
  pt: {
    name: 'Portuguese',
    nativeName: 'Português',
    region: 'BR',
    locale: 'pt-BR',
    ttsVoice: 'pt-BR-Ricardo',
    ttsVoiceAlt: 'pt-BR-Vitoria',
    googleTrendsRegion: 'BR',
    newsRegion: 'pt_BR',
    youtubeLanguage: 'pt',
    youtubeRegion: 'BR',
    culturalNuance: 'Brezilyali kulturu, sosyal, neseli, muzik, dans',
    viralPatterns: ['Nese', 'Sosyal', 'Muzik', 'Merak'],
    timeZone: 'America/Sao_Paulo',
  },
  ru: {
    name: 'Russian',
    nativeName: 'Русский',
    region: 'RU',
    locale: 'ru-RU',
    ttsVoice: 'ru-RU-Irina',
    ttsVoiceAlt: 'ru-RU-Pavel',
    googleTrendsRegion: 'RU',
    newsRegion: 'ru_RU',
    youtubeLanguage: 'ru',
    youtubeRegion: 'RU',
    culturalNuance: 'Rus kulturu, entelektuel, tarih, felsefe',
    viralPatterns: ['Entelektuellik', 'Tarih', 'Merak', 'Derinlik'],
    timeZone: 'Europe/Moscow',
  },
};

// --- Dil Secimi ve Dogrulama -----------------------------------------------
export function validateLanguage(languageCode) {
  if (!SUPPORTED_LANGUAGES[languageCode]) {
    return {
      valid: false,
      error: `Dil "${languageCode}" desteklenmiyor.`,
      supportedLanguages: Object.keys(SUPPORTED_LANGUAGES),
    };
  }

  return {
    valid: true,
    language: SUPPORTED_LANGUAGES[languageCode],
  };
}

// --- Dil Bilgilerini Getir ------------------------------------------------
export function getLanguageConfig(languageCode) {
  return SUPPORTED_LANGUAGES[languageCode] || SUPPORTED_LANGUAGES.en;
}

// --- TTS Ses Secimi -------------------------------------------------------
export function selectTTSVoice(languageCode, preference = 'primary') {
  const config = getLanguageConfig(languageCode);
  
  return {
    language: config.name,
    primaryVoice: config.ttsVoice,
    alternativeVoice: config.ttsVoiceAlt,
    selectedVoice: preference === 'primary' ? config.ttsVoice : config.ttsVoiceAlt,
    locale: config.locale,
  };
}

// --- Kulturel Adaptasyon Parametreleri ------------------------------------
export function getCulturalAdaptationParams(languageCode) {
  const config = getLanguageConfig(languageCode);

  return {
    language: config.name,
    culturalContext: config.culturalNuance,
    viralPatterns: config.viralPatterns,
    adaptationPrompt: `Bu icerigi ${config.name} kulturune ve ${config.culturalNuance} degerlerine uyarla. Viral kaliplari: ${config.viralPatterns.join(', ')}. Icerigi bu kulturun izleyicisine en etkili sekilde sunacak deyimler ve referanslar kullan.`,
  };
}

// --- Bolgesel Trend Takibi Parametreleri ----------------------------------
export function getRegionalTrendParams(languageCode) {
  const config = getLanguageConfig(languageCode);

  return {
    language: config.name,
    googleTrendsRegion: config.googleTrendsRegion,
    newsRegion: config.newsRegion,
    youtubeLanguage: config.youtubeLanguage,
    youtubeRegion: config.youtubeRegion,
    timeZone: config.timeZone,
    trendSearchQuery: `Trends in ${config.region}`,
  };
}

// --- Dil Bazli Kanal Mimari Parametreleri --------------------------------
export function getLanguageSpecificChannelArchitect(languageCode, category) {
  const config = getLanguageConfig(languageCode);

  const templates = {
    en: {
      psychology: {
        description: `Dive into the depths of human behavior. Psychology, manipulation, behavioral analysis, and mental health insights. Every video brings a new perspective, every perspective reveals a new discovery.`,
        keywords: ['psychology', 'behavior', 'mind', 'human', 'thought', 'manipulation', 'analysis', 'science', 'behavioral', 'cognitive', 'emotion', 'social', 'personality', 'development', 'health'],
      },
      motivation: {
        description: `Inspire yourself on the path to success. Motivation, personal development, leadership, and life lessons. Every day a new story, every story a new lesson. I invite you to become your best version.`,
        keywords: ['motivation', 'success', 'goals', 'inspiration', 'development', 'leadership', 'personal', 'life', 'lessons', 'story', 'transformation', 'capacity', 'potential', 'discipline', 'dreams'],
      },
    },
    tr: {
      psychology: {
        description: `Insan davranisinin derinliklerine inin. Psikoloji, manipulasyon, davranis analizi ve zihinsel saglik hakkinda ilginc bilgiler. Her videoda yeni bir perspektif, her perspektifde yeni bir kesif.`,
        keywords: ['psikoloji', 'davranis', 'zihin', 'insan', 'dusunce', 'manipulasyon', 'analiz', 'bilim', 'davranis bilimi', 'kognitif', 'emosyon', 'sosyal', 'kisilik', 'gelisim', 'saglik'],
      },
      motivation: {
        description: `Basari yolunda seni ilham ver. Motivasyon, kisisel gelisim, liderlik ve hayat dersleri. Her gun yeni bir hikaye, her hikayede yeni bir ders. Seni en iyi versiyonun olmaya davet ediyorum.`,
        keywords: ['motivasyon', 'basari', 'hedef', 'ilham', 'gelisim', 'liderlik', 'kisisel', 'hayat', 'dersi', 'hikaye', 'donusum', 'kapasite', 'potansiyel', 'disiplin', 'hayal'],
      },
    },
    es: {
      psychology: {
        description: `Sumérgete en las profundidades del comportamiento humano. Psicología, manipulación, análisis del comportamiento y salud mental. Cada video trae una nueva perspectiva, cada perspectiva revela un nuevo descubrimiento.`,
        keywords: ['psicología', 'comportamiento', 'mente', 'humano', 'pensamiento', 'manipulación', 'análisis', 'ciencia', 'cognitivo', 'emoción', 'social', 'personalidad', 'desarrollo', 'salud'],
      },
      motivation: {
        description: `Inspírate en el camino hacia el éxito. Motivación, desarrollo personal, liderazgo y lecciones de vida. Cada día una nueva historia, cada historia una nueva lección. Te invito a ser tu mejor versión.`,
        keywords: ['motivación', 'éxito', 'objetivos', 'inspiración', 'desarrollo', 'liderazgo', 'personal', 'vida', 'lecciones', 'historia', 'transformación', 'potencial', 'disciplina', 'sueños'],
      },
    },
  };

  const langTemplates = templates[languageCode] || templates.en;
  return langTemplates[category] || { description: '', keywords: [] };
}

// --- Dil Bazli Seslendirme Komutlari --------------------------------------
export function generateTTSInstructions(languageCode, text, voicePreference = 'primary') {
  const config = getLanguageConfig(languageCode);
  const voice = selectTTSVoice(languageCode, voicePreference);

  return {
    language: config.name,
    text,
    voice: voice.selectedVoice,
    locale: config.locale,
    rate: config.name === 'English' ? 1.0 : 0.95, // Dile gore hiz ayari
    pitch: 1.0,
    instructions: `${config.name} dilinde, "${voice.selectedVoice}" sesiyle seslendirme yap. Dogal ve profesyonel bir ton kullan.`,
  };
}

// --- Coklu Dil Kanal Ozeti ------------------------------------------------
export function generateMultiLanguageChannelSummary(channels) {
  const summary = {
    timestamp: new Date().toISOString(),
    totalChannels: channels.length,
    byLanguage: {},
    channels: [],
  };

  for (const channel of channels) {
    const config = getLanguageConfig(channel.language);
    
    if (!summary.byLanguage[config.name]) {
      summary.byLanguage[config.name] = 0;
    }
    summary.byLanguage[config.name]++;

    summary.channels.push({
      channelName: channel.name,
      language: config.name,
      region: config.region,
      category: channel.category,
      ttsVoice: config.ttsVoice,
      timeZone: config.timeZone,
    });
  }

  return summary;
}

// --- Dil Destegi Kontrol Listesi ------------------------------------------
export function getLanguageSupportChecklist() {
  return {
    supportedLanguages: Object.keys(SUPPORTED_LANGUAGES).length,
    languages: Object.entries(SUPPORTED_LANGUAGES).map(([code, config]) => ({
      code,
      name: config.name,
      nativeName: config.nativeName,
      region: config.region,
      ttsVoice: config.ttsVoice,
    })),
    features: [
      ' Coklu dil destegi',
      ' Bolgesel trend takibi',
      ' Yerellestirilmis seslendirme (TTS)',
      ' Kulturel adaptasyon',
      ' Dil bazli kanal mimari',
      ' Zaman dilimi yonetimi',
    ],
  };
}
