/**
 * Video Repair Engine — Video Onarim Motoru
 * ==========================================
 * Gemini'nin onerilerine gore videoyu otomatik olarak onarir
 * - Sikici bolumleri kirpar
 * - Tempo ve pacing'i ayarlar
 * - Hook'u guclendirir
 * - Altyazi hizini sikilastirir
 * - FFmpeg ile yeniden render eder
 */

import { spawn } from 'child_process';
import fsp from 'fs/promises';
import path from 'path';

// --- FFmpeg Komut Yardimcisi ------------------------------------------------
async function execFFmpeg(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn('ffmpeg', args, { stdio: ['ignore', 'ignore', 'pipe'] });
    let stderr = '';
    
    proc.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    proc.on('error', reject);
    proc.on('close', (code) => {
      if (code === 0) resolve();
      else reject(new Error(`FFmpeg exit ${code}: ${stderr}`));
    });
  });
}

// --- Sikici Bolumleri Kirp --------------------------------------------------
/**
 * Boring segments'i kirpar. Basit yaklasim: ilk high-severity segment'i kirp.
 * Daha karmasik: multiple segments icin concat filter.
 */
export async function trimBoringSegments(inputVideo, boringSegments, outputVideo) {
  if (!boringSegments || boringSegments.length === 0) {
    return { success: false, reason: 'Kirpilacak segment yok' };
  }

  // High severity segments'i bul
  const highSeverity = boringSegments.filter(s => s.severity === 'high');
  if (highSeverity.length === 0) {
    return { success: false, reason: 'High severity segment yok' };
  }

  // Ilk segment'i kirp
  const seg = highSeverity[0];
  const trimAmount = seg.end_sec - seg.start_sec;

  console.log(`✂️ Kirpiliyor: ${seg.start_sec}s-${seg.end_sec}s (${trimAmount}s) — ${seg.reason}`);

  try {
    // FFmpeg concat filter ile kirp
    const filterComplex = `[0:v]select='not(between(t,${seg.start_sec},${seg.end_sec}))',setpts=N/FRAME_RATE/TB[v];[0:a]aselect='not(between(t,${seg.start_sec},${seg.end_sec}))',asetpts=N/SR/TB[a]`;

    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-filter_complex', filterComplex,
      '-map', '[v]',
      '-map', '[a]',
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(` Segment kirpildi: ${trimAmount}s cikarildi`);
    return {
      success: true,
      trimmedSegment: seg,
      trimAmount,
      newDuration: null, // Hesaplanacak
    };

  } catch (e) {
    console.error('Kirpma hatasi:', e.message);
    return { success: false, error: e.message };
  }
}

// --- Hiz Ayarla (Tempo) ------------------------------------------------------
/**
 * Videoyu belirli bir faktorle hizlandirir veya yavaslatir.
 * factor > 1: hizlandir, factor < 1: yavaslat
 */
export async function adjustSpeed(inputVideo, factor, outputVideo) {
  if (factor <= 0 || factor > 2) {
    return { success: false, reason: 'Factor 0-2 arasinda olmali' };
  }

  if (Math.abs(factor - 1) < 0.05) {
    return { success: false, reason: 'Hiz degisimi cok az' };
  }

  console.log(`️ Hiz ayarlaniyor: ${factor.toFixed(2)}x`);

  try {
    const vf = `setpts=${1/factor}*PTS`;
    const af = `atempo=${factor}`;

    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-vf', vf,
      '-af', af,
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(` Hiz ayarlandi: ${factor.toFixed(2)}x`);
    return { success: true, factor };

  } catch (e) {
    console.error('Hiz ayarlama hatasi:', e.message);
    return { success: false, error: e.message };
  }
}

// --- Belirli Bolumun Hizini Ayarla ------------------------------------------
/**
 * Videoyu parcalara ayirip sadece belirli bolumun hizini degistirir.
 */
export async function adjustSegmentSpeed(inputVideo, startSec, endSec, factor, outputVideo) {
  console.log(`️ ${startSec}s-${endSec}s arasi hiz: ${factor.toFixed(2)}x`);

  try {
    // Parca 1: 0 - startSec (normal)
    // Parca 2: startSec - endSec (degistirilmis)
    // Parca 3: endSec - son (normal)

    const filterComplex = 
      `[0:v]split[v1][v2];` +
      `[v1]select='lte(t,${startSec})',setpts=N/FRAME_RATE/TB[part1v];` +
      `[v2]select='gt(t,${startSec})*lt(t,${endSec})',setpts=N/FRAME_RATE/TB,setpts=${1/factor}*PTS[part2v];` +
      `[part1v][part2v]concat[vout];` +
      `[0:a]split[a1][a2];` +
      `[a1]aselect='lte(t,${startSec})',asetpts=N/SR/TB[part1a];` +
      `[a2]aselect='gt(t,${startSec})*lt(t,${endSec})',asetpts=N/SR/TB,atempo=${factor}[part2a];` +
      `[part1a][part2a]concat=v=0:a=1[aout]`;

    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-filter_complex', filterComplex,
      '-map', '[vout]',
      '-map', '[aout]',
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(` Segment hizi ayarlandi`);
    return { success: true, segment: { startSec, endSec }, factor };

  } catch (e) {
    console.error('Segment hiz ayarlama hatasi:', e.message);
    return { success: false, error: e.message };
  }
}

// --- Altyazi Hizini Sikilastir (Caption Pacing) ------------------------------
/**
 * Altyazilarin ekranda kalma suresini ayarlar.
 * factor > 1: daha hizli (kisa sure), factor < 1: daha yavas (uzun sure)
 */
export async function adjustCaptionPacing(inputVideo, factor, outputVideo) {
  console.log(`📝 Altyazi hizi ayarlaniyor: ${factor.toFixed(2)}x`);

  try {
    // Basit yaklasim: video hizini ayarla (altyazi da otomatik hizlanir)
    // Daha gelismis: SRT dosyasini parse edip timing'i degistir

    const vf = `setpts=${1/factor}*PTS`;
    const af = `atempo=${factor}`;

    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-vf', vf,
      '-af', af,
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(` Altyazi hizi ayarlandi: ${factor.toFixed(2)}x`);
    return { success: true, factor };

  } catch (e) {
    console.error('Altyazi hiz ayarlama hatasi:', e.message);
    return { success: false, error: e.message };
  }
}

// --- Hook Guclendirme (Gorsel Efekt Ekle) ----------------------------------
/**
 * Videonun ilk 2 saniyesine gorsel efekt ekler.
 * - Zoom in
 * - Renk yogunlugu artir
 * - Muzik volumu artir
 */
export async function reinforceHook(inputVideo, outputVideo, audioVolume = 1.5) {
  console.log(` Hook guclendiriliyor...`);

  try {
    // Ilk 2 saniye: zoom in + brightness artir
    const filterComplex = 
      `[0:v]split[v1][v2];` +
      `[v1]select='lt(t,2)',setpts=N/FRAME_RATE/TB,scale=iw*1.1:ih*1.1,crop=1080:1920[part1];` +
      `[v2]select='gte(t,2)',setpts=N/FRAME_RATE/TB[part2];` +
      `[part1][part2]concat[vout];` +
      `[0:a]volume=${audioVolume}[aout]`;

    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-filter_complex', filterComplex,
      '-map', '[vout]',
      '-map', '[aout]',
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(` Hook guclendirildi`);
    return { success: true, audioVolume };

  } catch (e) {
    console.error('Hook guclendirme hatasi:', e.message);
    return { success: false, error: e.message };
  }
}

// --- Muzik Volumu Artir -----------------------------------------------------
export async function increaseAudioVolume(inputVideo, factor, outputVideo) {
  console.log(`🔊 Ses volumu artiriliyor: ${factor.toFixed(2)}x`);

  try {
    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-af', `volume=${factor}`,
      '-c:v', 'copy',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(` Ses volumu ayarlandi: ${factor.toFixed(2)}x`);
    return { success: true, factor };

  } catch (e) {
    console.error('Ses ayarlama hatasi:', e.message);
    return { success: false, error: e.message };
  }
}

// --- Yeniden Render (Tum Onarimlari Uygula) --------------------------------
/**
 * Onarim planini uygulayip videoyu yeniden render eder.
 */
export async function executeRepairPlan(inputVideo, repairPlan, outputVideo) {
  console.log(`🔧 Onarim plani uygulaniyor (${repairPlan.steps.length} adim)...`);

  let currentVideo = inputVideo;
  let stepResults = [];

  for (const step of repairPlan.steps) {
    if (step.type === 'rewrite_hook') {
      console.log(`  [${step.order}] Hook yeniden yaziliyor...`);
      const tempOutput = `${outputVideo}.hook.mp4`;
      const result = await reinforceHook(currentVideo, tempOutput);
      stepResults.push({ step: step.order, type: step.type, result });
      if (result.success) currentVideo = tempOutput;
    }

    else if (step.type === 'trim_boring_segments') {
      console.log(`  [${step.order}] Sikici bolumler kirpiliyor...`);
      const tempOutput = `${outputVideo}.trim.mp4`;
      const result = await trimBoringSegments(currentVideo, step.segments, tempOutput);
      stepResults.push({ step: step.order, type: step.type, result });
      if (result.success) currentVideo = tempOutput;
    }

    else if (step.type === 'fix_pacing') {
      console.log(`  [${step.order}] Pacing duzeltiliyor...`);
      // Ilk pacing issue'yi al
      const issue = step.issues[0];
      const tempOutput = `${outputVideo}.pacing.mp4`;
      
      // Segment araligini parse et (orn: "10-15s" -> 10, 15)
      const match = issue.segment.match(/(\d+)-(\d+)/);
      if (match) {
        const [, start, end] = match;
        const factor = issue.issue === 'cok yavas' ? 1.15 : 0.9;
        const result = await adjustSegmentSpeed(currentVideo, parseInt(start), parseInt(end), factor, tempOutput);
        stepResults.push({ step: step.order, type: step.type, result });
        if (result.success) currentVideo = tempOutput;
      }
    }

    else if (step.type === 'adjust_caption_pacing') {
      console.log(`  [${step.order}] Altyazi hizi sikilastiriliyor...`);
      const tempOutput = `${outputVideo}.caption.mp4`;
      const result = await adjustCaptionPacing(currentVideo, 1.1, tempOutput);
      stepResults.push({ step: step.order, type: step.type, result });
      if (result.success) currentVideo = tempOutput;
    }

    else if (step.type === 'rerender_video') {
      console.log(`  [${step.order}] Video yeniden render ediliyor...`);
      // Zaten render ediliyor, sadece final output'a kopyala
      if (currentVideo !== outputVideo) {
        await fsp.copyFile(currentVideo, outputVideo);
      }
      stepResults.push({ step: step.order, type: step.type, result: { success: true } });
    }

    else if (step.type === 'review_again') {
      console.log(`  [${step.order}] Yeniden inceleme icin hazirlaniyor...`);
      stepResults.push({ step: step.order, type: step.type, result: { success: true } });
    }
  }

  // Temp dosyalari temizle
  for (const result of stepResults) {
    if (result.result.tempFile) {
      try {
        await fsp.unlink(result.result.tempFile);
      } catch {}
    }
  }

  console.log(` Onarim plani tamamlandi`);
  return {
    success: true,
    stepsExecuted: stepResults.length,
    results: stepResults,
    outputVideo,
  };
}

// --- Hizli Onarim (Basit Hiz Artirma) ---------------------------------------
/**
 * Hizli bir onarim: videoyu %10 hizlandir ve bitir.
 * Zaman kisitli durumlarda kullanilir.
 */
export async function quickRepair(inputVideo, outputVideo) {
  console.log(`⚡ Hizli onarim: Video %10 hizlandiriliyor...`);
  return adjustSpeed(inputVideo, 1.1, outputVideo);
}
