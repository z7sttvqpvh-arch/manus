/**
 * Warm-Up & Growth — Isinma ve Buyume
 * ====================================
 * Sifir (yeni acilmis) hesaplar icin guvenli ve hizli buyume stratejisi
 */

// --- Hesap Yasi Kategorileri ------------------------------------------------
const ACCOUNT_AGE_STAGES = {
  stage1: {
    name: 'Yeni Hesap (0-3 gun)',
    daysOld: 3,
    dailyUploadLimit: 1,
    riskLevel: 'CRITICAL',
    strategy: 'Minimum Activity - Algoritma Tanima',
  },
  stage2: {
    name: 'Gelisen Hesap (4-7 gun)',
    daysOld: 7,
    dailyUploadLimit: 2,
    riskLevel: 'HIGH',
    strategy: 'Kademeli Artis - Nis Dogrulama',
  },
  stage3: {
    name: 'Guvenli Hesap (8-14 gun)',
    daysOld: 14,
    dailyUploadLimit: 3,
    riskLevel: 'MEDIUM',
    strategy: 'Hizli Buyume - Algoritma Guveni',
  },
  stage4: {
    name: 'Olgun Hesap (15+ gun)',
    daysOld: Infinity,
    dailyUploadLimit: 5,
    riskLevel: 'LOW',
    strategy: 'Agresif Buyume - Viral Potansiyeli',
  },
};

// --- Hesap Yasini Belirle ve Asamasini Dondur ------------------------------
export function determineAccountStage(accountCreatedDate) {
  const now = new Date();
  const createdDate = new Date(accountCreatedDate);
  const daysOld = Math.floor((now - createdDate) / (1000 * 60 * 60 * 24));

  let stage = ACCOUNT_AGE_STAGES.stage1;
  
  if (daysOld > 14) stage = ACCOUNT_AGE_STAGES.stage4;
  else if (daysOld > 7) stage = ACCOUNT_AGE_STAGES.stage3;
  else if (daysOld > 3) stage = ACCOUNT_AGE_STAGES.stage2;

  return {
    daysOld,
    stage,
    dailyUploadLimit: stage.dailyUploadLimit,
    riskLevel: stage.riskLevel,
    recommendation: `${stage.name}: ${stage.strategy}`,
  };
}

// --- Gunluk Yukleme Siniri Kontrolu ----------------------------------------
export function checkDailyUploadLimit(accountStage, uploadedToday) {
  const limit = accountStage.dailyUploadLimit;
  const remaining = limit - uploadedToday;

  return {
    limit,
    uploadedToday,
    remaining,
    canUpload: remaining > 0,
    recommendation: remaining > 0
      ? ` Bugun ${remaining} video daha yukleyebilirsiniz`
      : `❌ Gunluk limit (${limit}) asildi. Yarin tekrar deneyin.`,
  };
}

// --- Insan Gibi Etkilesim Simulasyonu ---------------------------------------
export function generateHumanLikeInteraction(accountStage) {
  const interactions = {
    browsing: {
      duration: Math.random() * 120 + 60, // 60-180 saniye
      actions: [
        'YouTube ana sayfasina git',
        'Rastgele 3-5 Shorts videosu kaydir',
        'Rastgele 1-2 videoya tikla (izleme)',
        'Arama yaparak kanalin kategorisine uygun videolar ara',
      ],
      frequency: accountStage.riskLevel === 'CRITICAL' ? 'Her video yuklemeden once' : 'Her 2 video yuklemeden sonra',
    },
    watching: {
      duration: Math.random() * 30 + 15, // 15-45 saniye
      videoCount: Math.floor(Math.random() * 3) + 1, // 1-3 video
      completionRate: Math.random() * 0.5 + 0.3, // %30-80 izlenme
    },
    liking: {
      probability: 0.3, // %30 ihtimalle begeni yap
      frequency: 'Rastgele',
    },
    commenting: {
      probability: 0.1, // %10 ihtimalle yorum yap
      frequency: 'Cok nadir',
    },
  };

  return {
    accountStage: accountStage.name,
    interactions,
    recommendation: `Gunde ${interactions.browsing.frequency} insan gibi gezinme yapin`,
  };
}

// --- Nis Dogrulama Stratejisi (Ilk 5 Video) --------------------------------
export function generateNicheValidationStrategy(category, videoCount) {
  const strategies = {
    psychology: {
      keywords: ['psikoloji', 'davranis', 'zihin', 'insan', 'dusunce'],
      tags: ['#psikoloji', '#davranis', '#zihin', '#insan', '#bilim'],
      themes: ['Karanlik Psikoloji', 'Manipulasyon', 'Davranis Analizi', 'Zihinsel Saglik'],
    },
    motivation: {
      keywords: ['motivasyon', 'basari', 'hedef', 'ilham', 'gelisim'],
      tags: ['#motivasyon', '#basari', '#hedef', '#ilham', '#gelisim'],
      themes: ['Basari Hikayeleri', 'Kisisel Gelisim', 'Liderlik', 'Hayat Dersleri'],
    },
    health: {
      keywords: ['saglik', 'beslenme', 'fitness', 'wellness', 'yasam'],
      tags: ['#saglik', '#beslenme', '#fitness', '#wellness', '#yasam'],
      themes: ['Beslenme Tuyolari', 'Egzersiz', 'Mental Saglik', 'Yasam Kalitesi'],
    },
    knowledge: {
      keywords: ['bilgi', 'egitim', 'ogrenme', 'merak', 'kesif'],
      tags: ['#bilgi', '#egitim', '#ogrenme', '#merak', '#kesif'],
      themes: ['Ilginc Gercekler', 'Bilimsel Kesifler', 'Tarih', 'Teknoloji'],
    },
  };

  const strategy = strategies[category] || strategies.knowledge;
  const isFirstFiveVideos = videoCount <= 5;

  return {
    category,
    videoCount,
    isFirstFiveVideos,
    strategy: {
      keywords: strategy.keywords,
      tags: strategy.tags,
      themes: strategy.themes,
      consistency: isFirstFiveVideos ? 'STRICT' : 'FLEXIBLE',
    },
    recommendation: isFirstFiveVideos
      ? ` Ilk 5 video icin kati nis dogrulama: ${strategy.keywords.join(', ')} anahtar kelimelerini kullanin`
      : ` 5. videodan sonra biraz daha esneklik kazandiniz`,
  };
}

// --- Otomatik Yorum Sabitleme (Engagement Starter) ---------------------------
export function generateEngagementStarterComment(videoTitle, category) {
  const commentTemplates = {
    psychology: [
      'Bu davranisi gozlemlediniz mi? Yorumlarda deneyiminizi paylasin 👇',
      'Bu psikolojik numarayi daha once fark ettiniz mi? 🤔',
      'Sizce bu dogru mu? Dusuncelerinizi yazin 👇',
    ],
    motivation: [
      'Bu basari hikayesi sizi ilham verdi mi? Kendi hikayenizi paylasin 👇',
      'Hangi adim sizin icin en zor oldu? Yorumda belirtin 👇',
      'Bu yolculugun hangi asamasinda oldugunuzu biliyor musunuz? 👇',
    ],
    health: [
      'Bu tuyoyu deneyecek misiniz? Sonuclarinizi paylasin 👇',
      'Sizin saglik rutininiz nedir? Yorumda yazin 👇',
      'Bu bilgiyi daha once biliyor muydunuz? 👇',
    ],
    knowledge: [
      'Bu gercegi biliyor muydunuz? Yorumda tepkinizi yazin 👇',
      'Hangi bilgi sizi en cok sasirtti? 👇',
      'Bunun hakkinda ne dusunuyorsunuz? Paylasin 👇',
    ],
  };

  const templates = commentTemplates[category] || commentTemplates.knowledge;
  const randomComment = templates[Math.floor(Math.random() * templates.length)];

  return {
    comment: randomComment,
    shouldPin: true,
    timing: 'Video yuklendikten 5 dakika sonra',
    recommendation: ' Bu yorum izleyicileri etkilesime tesvik edecektir',
  };
}

// --- Algoritma Guveni Skoru (Trust Score) ----------------------------------
export function calculateTrustScore(accountData) {
  let score = 0;

  // Hesap yasi
  const stage = determineAccountStage(accountData.createdDate);
  if (stage.daysOld > 14) score += 30;
  else if (stage.daysOld > 7) score += 20;
  else if (stage.daysOld > 3) score += 10;

  // Video sayisi ve tutarlilik
  if (accountData.videoCount >= 5) score += 20;
  if (accountData.videoCount >= 10) score += 10;

  // Etkilesim orani
  if (accountData.averageEngagementRate > 0.1) score += 20;
  if (accountData.averageEngagementRate > 0.15) score += 10;

  // Nis tutarliligi
  if (accountData.nichConsistency > 0.8) score += 20;

  // Spam belirtileri
  if (accountData.hasSpamWarnings) score -= 30;
  if (accountData.hasContentIdStrikes) score -= 50;

  return {
    trustScore: Math.max(0, Math.min(100, score)),
    riskLevel: score < 30 ? 'CRITICAL' : score < 60 ? 'HIGH' : score < 80 ? 'MEDIUM' : 'LOW',
    recommendation: score < 30
      ? '❌ Hesap riskli, cok dikkatli olun'
      : score < 60
      ? '️ Hesap gelisiyor, kademeli buyume devam edin'
      : score < 80
      ? ' Hesap guvenli, hizli buyume baslayabilir'
      : ' Hesap guvenilir, agresif buyume yapabilirsiniz',
  };
}

// --- Isinma Durumu Raporu --------------------------------------------------
export function generateWarmupStatusReport(accountData) {
  const stage = determineAccountStage(accountData.createdDate);
  const trustScore = calculateTrustScore(accountData);
  const interaction = generateHumanLikeInteraction(stage.stage);
  const niche = generateNicheValidationStrategy(accountData.category, accountData.videoCount);

  return {
    timestamp: new Date().toISOString(),
    accountAge: stage,
    trustScore,
    humanInteraction: interaction,
    nicheValidation: niche,
    dailyUploadStatus: checkDailyUploadLimit(stage.stage, accountData.uploadedToday || 0),
    overallRecommendation: `${trustScore.recommendation}. ${stage.recommendation}`,
  };
}

// --- Guvenli Yukleme Zamani Hesapla ----------------------------------------
export function calculateSafeUploadTiming(accountStage, lastUploadTime) {
  const minimumGapMinutes = accountStage.riskLevel === 'CRITICAL' ? 120 : 
                            accountStage.riskLevel === 'HIGH' ? 60 : 30;

  const now = new Date();
  const lastUpload = new Date(lastUploadTime);
  const minutesSinceLastUpload = Math.floor((now - lastUpload) / (1000 * 60));
  const minutesUntilNextUpload = Math.max(0, minimumGapMinutes - minutesSinceLastUpload);

  return {
    minimumGapMinutes,
    minutesSinceLastUpload,
    canUploadNow: minutesUntilNextUpload === 0,
    minutesUntilNextUpload,
    recommendation: minutesUntilNextUpload === 0
      ? ' Simdi yukleyebilirsiniz'
      : `⏳ ${minutesUntilNextUpload} dakika sonra yukleyebilirsiniz`,
  };
}

// --- Sifir Hesap Baslangic Kontrol Listesi ----------------------------------
export function getZeroAccountStartupChecklist() {
  return {
    checklist: [
      {
        step: 1,
        task: 'Hesap Olustur',
        description: 'Yeni Gmail hesabi olustur ve YouTube kanalini ac',
        status: 'TODO',
      },
      {
        step: 2,
        task: 'Kanal Bilgilerini Doldur',
        description: 'Kanal adi, aciklamasi ve profil resmini ekle',
        status: 'TODO',
      },
      {
        step: 3,
        task: 'Nis Belirle',
        description: 'Kanalin kategorisini (Psikoloji, Motivasyon vb.) sec',
        status: 'TODO',
      },
      {
        step: 4,
        task: 'Isinma Modunu Aktif Et',
        description: 'Panelden "Warm-Up Mode" secenegini ac',
        status: 'TODO',
      },
      {
        step: 5,
        task: 'Ilk Videoyu Yukle',
        description: 'Sistem tarafindan uretilen ilk videoyu yukle',
        status: 'TODO',
      },
      {
        step: 6,
        task: 'Insan Gibi Gezin',
        description: 'YouTube\'da 2-3 dakika rastgele videolar kaydir',
        status: 'TODO',
      },
      {
        step: 7,
        task: '3 Gun Bekle',
        description: 'Algoritmanin kanali tanimasi icin 3 gun bekle',
        status: 'TODO',
      },
      {
        step: 8,
        task: 'Hizi Artir',
        description: 'Sistem otomatik olarak gunluk video sayisini artiracak',
        status: 'TODO',
      },
    ],
    estimatedTimeToViralReady: '14-21 gun',
    recommendation: ' Bu adimlari takip ederseniz hesabiniz guvenli ve hizli buyuyecektir',
  };
}
