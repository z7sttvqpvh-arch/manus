/**
 * A/B Hook Testing — 5 Adayli Hook Testi
 * ========================================
 * Sistem 5 farkli "Hook" (acilis) uretir, Gemini'ye izletir ve en yuksek
 * "Scroll-stop" (kaydirma durdurma) gucune sahip olani secer.
 * Eger hicbiri esik puani gecemezse, yeni 5'li set uretir.
 */

import * as browser from './browser-automation.js';

// --- Hook Tipleri -----------------------------------------------------------
const HOOK_TYPES = {
  question: {
    name: 'Soru (Question)',
    template: 'Neden {topic}? Cevabi biliyorsun?',
    description: 'Merak uyandirici bir soru ile basla',
  },
  shock: {
    name: 'Sasirtma (Shock)',
    template: 'Cogu kisi {topic} hakkinda yaniliyor.',
    description: 'Sasirtici bir iddia ile basla',
  },
  mystery: {
    name: 'Gizem (Mystery)',
    template: 'Kimse {topic} hakkinda bunu soylemiyor.',
    description: 'Gizli bilgi vaat ederek basla',
  },
  direct: {
    name: 'Dogrudan (Direct)',
    template: '{topic} hakkinda bilmen gereken 1 sey: ...',
    description: 'Dogrudan ve net bir ifade ile basla',
  },
  visual: {
    name: 'Gorsel (Visual)',
    template: 'Bu gorsele bak... {topic} hakkinda ne dusunuyorsun?',
    description: 'Gorsel bir merak ile basla',
  },
};

// --- 5 Adayli Hook Seti Olustur ---------------------------------------------
export function generateFiveHookCandidates(topic, category) {
  const candidates = [];
  const hookTypeKeys = Object.keys(HOOK_TYPES);

  for (let i = 0; i < 5; i++) {
    const hookType = hookTypeKeys[i % hookTypeKeys.length];
    const hookDef = HOOK_TYPES[hookType];
    const hookText = hookDef.template.replace('{topic}', topic);

    candidates.push({
      id: `hook_${Date.now()}_${i}`,
      type: hookType,
      typeName: hookDef.name,
      template: hookDef.template,
      text: hookText,
      description: hookDef.description,
      category,
      topic,
      scrollStopScore: null,
      safetyScore: null,
      selected: false,
    });
  }

  return candidates;
}

// --- Hook'lari Gemini'ye Degerlendir ----------------------------------------
export async function evaluateHooksWithGemini(hooks) {
  try {
    console.log(`🎣 ${hooks.length} Hook Gemini'ye degerlendiriliyor...`);

    const hooksList = hooks
      .map((h, i) => `${i + 1}. [${h.typeName}] "${h.text}"`)
      .join('\n');

    const prompt = `Asagidaki 5 video acilisini (Hook) degerlendir. 
Her birinin "Scroll-stop" (kaydirmayi durdurma) gucunu 0-100 arasinda puan ver.

${hooksList}

Cevap JSON formatinda (baska hicbir sey yazma):
{
  "evaluations": [
    {"index": 1, "scrollStopScore": 88, "reason": "Merak uyandirici"},
    {"index": 2, "scrollStopScore": 75, "reason": "Biraz siradan"},
    {"index": 3, "scrollStopScore": 92, "reason": "Cok etkili gizem"},
    {"index": 4, "scrollStopScore": 70, "reason": "Dogrudan ama sikici"},
    {"index": 5, "scrollStopScore": 85, "reason": "Iyi gorsel merak"}
  ],
  "bestHook": 3,
  "recommendation": "3. Hook en yuksek scroll-stop gucune sahip"
}`;

    const response = await browser.sendMessageToGemini(prompt);
    const jsonMatch = response.match(/\{[\s\S]*\}/);

    if (!jsonMatch) {
      console.warn(' Hook degerlendirmesi JSON bulunamadi, varsayilan puanlar veriliyor');
      return assignDefaultScores(hooks);
    }

    const evaluation = JSON.parse(jsonMatch[0]);

    // Puanlari hook'lara ata
    for (const item of evaluation.evaluations) {
      if (hooks[item.index - 1]) {
        hooks[item.index - 1].scrollStopScore = item.scrollStopScore;
        hooks[item.index - 1].evaluationReason = item.reason;
      }
    }

    console.log(` Hook degerlendirmesi tamamlandi`);
    return hooks;
  } catch (e) {
    console.error('Hook degerlendirme hatasi:', e.message);
    return assignDefaultScores(hooks);
  }
}

// --- Varsayilan Puanlar (Hata Durumunda) ------------------------------------
function assignDefaultScores(hooks) {
  const scores = [88, 75, 92, 70, 85];
  hooks.forEach((h, i) => {
    h.scrollStopScore = scores[i] || 75;
    h.evaluationReason = 'Varsayilan puan';
  });
  return hooks;
}

// --- En Iyi Hook'u Sec ------------------------------------------------------
export function selectBestHook(hooks, threshold = 85) {
  // Puanlari sirala
  const sorted = [...hooks].sort((a, b) => (b.scrollStopScore || 0) - (a.scrollStopScore || 0));
  const best = sorted[0];

  return {
    hook: best,
    passedThreshold: (best.scrollStopScore || 0) >= threshold,
    score: best.scrollStopScore || 0,
    threshold,
    allScores: hooks.map(h => ({
      type: h.typeName,
      score: h.scrollStopScore || 0,
      reason: h.evaluationReason || 'Degerlendirilmedi',
    })),
  };
}

// --- Hook Test Raporu Olustur ----------------------------------------------
export function createHookTestReport(hooks, selectedHook, threshold, roundNumber = 1) {
  return {
    timestamp: new Date().toISOString(),
    roundNumber,
    threshold,
    totalCandidates: hooks.length,
    selectedHook: {
      type: selectedHook.typeName,
      text: selectedHook.text,
      score: selectedHook.scrollStopScore,
      reason: selectedHook.evaluationReason,
    },
    allScores: hooks.map(h => ({
      type: h.typeName,
      score: h.scrollStopScore || 0,
      text: h.text,
    })),
    passedThreshold: (selectedHook.scrollStopScore || 0) >= threshold,
    recommendation: (selectedHook.scrollStopScore || 0) >= threshold
      ? ` "${selectedHook.typeName}" hook ${selectedHook.scrollStopScore} puanla esik degeri (${threshold}) gecti. Yayinlamaya hazir.`
      : ` "${selectedHook.typeName}" hook ${selectedHook.scrollStopScore} puanla esik degeri (${threshold}) gecemedi. Yeni hook seti uretiliyor...`,
  };
}

// --- Iteratif Hook Uretim (Esik Gecene Kadar) ------------------------------
export async function generateHooksUntilThreshold(topic, category, threshold = 85, maxRounds = 3) {
  console.log(`🎣 Hook uretimi basliyor (Esik: ${threshold}, Max Round: ${maxRounds})`);

  const reports = [];
  let round = 0;

  while (round < maxRounds) {
    round++;
    console.log(`\n📍 Round ${round}/${maxRounds}`);

    // 5 adayli hook seti uret
    const hooks = generateFiveHookCandidates(topic, category);

    // Gemini'ye degerlendir
    const evaluatedHooks = await evaluateHooksWithGemini(hooks);

    // En iyisini sec
    const best = evaluatedHooks.reduce((prev, current) =>
      (prev.scrollStopScore || 0) > (current.scrollStopScore || 0) ? prev : current
    );

    const report = createHookTestReport(evaluatedHooks, best, threshold, round);
    reports.push(report);

    console.log(`  Skor: ${best.scrollStopScore}/${threshold}`);

    if ((best.scrollStopScore || 0) >= threshold) {
      console.log(` Esik deger gecildi! Secilen hook: "${best.typeName}"`);
      return {
        success: true,
        selectedHook: best,
        roundsUsed: round,
        reports,
      };
    }

    console.log(` Esik gecilmedi, yeni round basliyor...`);
  }

  // Max round'a ulasildi, en iyi hook'u dondur
  const allHooks = reports.flatMap(r => r.allScores);
  const bestOverall = allHooks.reduce((prev, current) =>
    (prev.score || 0) > (current.score || 0) ? prev : current
  );

  console.log(` Max round'a ulasildi. En iyi hook: "${bestOverall.type}" (${bestOverall.score})`);

  return {
    success: false,
    selectedHook: bestOverall,
    roundsUsed: round,
    reports,
    note: 'Esik deger gecilmedi ancak en iyi hook secildi',
  };
}

// --- Hook Performans Analizi ------------------------------------------------
export function analyzeHookPerformance(reports) {
  const typeScores = {};

  for (const report of reports) {
    for (const score of report.allScores) {
      if (!typeScores[score.type]) {
        typeScores[score.type] = { scores: [], avgScore: 0 };
      }
      typeScores[score.type].scores.push(score.score);
    }
  }

  // Ortalama hesapla
  for (const [type, data] of Object.entries(typeScores)) {
    const sum = data.scores.reduce((a, b) => a + b, 0);
    data.avgScore = sum / data.scores.length;
  }

  // Sirala
  const sorted = Object.entries(typeScores)
    .map(([type, data]) => ({
      type,
      avgScore: Math.round(data.avgScore),
      attempts: data.scores.length,
    }))
    .sort((a, b) => b.avgScore - a.avgScore);

  return {
    bestPerformingHook: sorted[0],
    allHookPerformance: sorted,
    recommendation: `"${sorted[0].type}" hook turu ortalama ${sorted[0].avgScore} puan aliyor. Bunu kullanmaya devam et.`,
  };
}
