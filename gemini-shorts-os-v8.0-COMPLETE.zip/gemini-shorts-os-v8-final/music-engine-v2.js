/**
 * Music Engine v2 — Sonic Mastery (Ses Ustaligi)
 * ================================================
 * Muzik artik sadece "arka plan" degil, bir "Ses Tasarimci" gibi calisiyor
 * - Dinamik Frekans Ducking (Seslendirme sirasinda muzik otomatik kisilir)
 * - Vurgu Senkronizasyonu (Onemli anlar muzikle vurgulanir)
 * - Duygusal Muzik Eslestirme (Metin duygusu muzik secimini belirler)
 */

import fs from 'fs';
import path from 'path';

// --- Muzik Kategorileri ve Duygusal Eslestirme ----------------------------
const MUSIC_CATEGORIES = {
  motivation: {
    name: 'Motivasyon',
    emotions: ['aspiration', 'relief', 'shock'],
    musicStyles: ['epic', 'inspirational', 'crescendo'],
    frequency: {
      voiceoverDuck: 0.4, // Seslendirme sirasinda %40 kisilir
      emphasisBump: 1.3, // Vurgu anlarinda %30 artirilir
    },
  },
  psychology: {
    name: 'Psikoloji',
    emotions: ['curiosity', 'fear', 'shock'],
    musicStyles: ['dark', 'mysterious', 'ambient'],
    frequency: {
      voiceoverDuck: 0.35,
      emphasisBump: 1.25,
    },
  },
  health: {
    name: 'Saglik',
    emotions: ['relief', 'aspiration'],
    musicStyles: ['zen', 'minimalist', 'nature'],
    frequency: {
      voiceoverDuck: 0.5,
      emphasisBump: 1.15,
    },
  },
  shock: {
    name: 'Sok',
    emotions: ['shock', 'fear', 'curiosity'],
    musicStyles: ['suspense', 'fast', 'reverse'],
    frequency: {
      voiceoverDuck: 0.3,
      emphasisBump: 1.4,
    },
  },
  knowledge: {
    name: 'Bilgi',
    emotions: ['curiosity', 'relief'],
    musicStyles: ['educational', 'fast', 'uplifting'],
    frequency: {
      voiceoverDuck: 0.4,
      emphasisBump: 1.2,
    },
  },
  finance: {
    name: 'Finans',
    emotions: ['aspiration', 'relief'],
    musicStyles: ['professional', 'dynamic', 'uplifting'],
    frequency: {
      voiceoverDuck: 0.45,
      emphasisBump: 1.25,
    },
  },
};

// --- Muzik Secimi (Duygusal Eslestirme ile) --------------------------------
export function selectMusicByEmotion(category, dominantEmotion) {
  const categoryData = MUSIC_CATEGORIES[category];
  if (!categoryData) return null;

  const musicDir = path.join(process.cwd(), 'storage', 'music', category);
  
  if (!fs.existsSync(musicDir)) {
    console.warn(`️ Muzik klasoru bulunamadi: ${musicDir}`);
    return null;
  }

  const musicFiles = fs.readdirSync(musicDir).filter(f => f.endsWith('.mp3'));
  
  if (musicFiles.length === 0) {
    console.warn(`️ ${category} kategorisinde muzik bulunamadi`);
    return null;
  }

  // Duyguya uygun muzik sec
  let selectedMusic = musicFiles[0];
  for (const file of musicFiles) {
    if (file.toLowerCase().includes(dominantEmotion?.toLowerCase() || '')) {
      selectedMusic = file;
      break;
    }
  }

  return {
    category,
    emotion: dominantEmotion,
    musicFile: path.join(musicDir, selectedMusic),
    musicName: selectedMusic,
    duckingLevel: categoryData.frequency.voiceoverDuck,
    emphasisBump: categoryData.frequency.emphasisBump,
  };
}

// --- Dinamik Frekans Ducking (Seslendirme Sirasinda Muzik Kisilmasi) --------
export function generateFrequencyDuckingFilter(duckingLevel = 0.4) {
  // FFmpeg kompleks filtreleri icin ducking parametreleri
  return {
    filterType: 'volume',
    duckingLevel, // 0.4 = %40 kisilir (0.6 seviyesinde kalir)
    ffmpegFilter: `volume=${duckingLevel}:eval=frame`,
    description: `Seslendirme sirasinda muzik ${Math.round((1 - duckingLevel) * 100)}% kisilacak`,
  };
}

// --- Vurgu Senkronizasyonu (Onemli Anlar Muzikle Vurgulanir) ---------------
export function generateEmphasisSync(emphasisBump = 1.2, startSecond, endSecond) {
  // Belirtilen saniyeler arasinda muzik sesini artir
  return {
    filterType: 'volume',
    emphasisBump,
    startSecond,
    endSecond,
    ffmpegFilter: `volume=${emphasisBump}:eval=frame`,
    description: `${startSecond}-${endSecond}. saniyeler arasinda muzik ${Math.round((emphasisBump - 1) * 100)}% artirilacak`,
  };
}

// --- Muzik Layering (Katmanlama) --------------------------------------------
export function createMusicLayers(primaryMusic, secondaryMusic = null) {
  return {
    primary: {
      file: primaryMusic,
      volume: 1.0,
      description: 'Ana muzik katmani',
    },
    secondary: secondaryMusic ? {
      file: secondaryMusic,
      volume: 0.3,
      description: 'Arka plan katmani (hafif)',
    } : null,
    combined: {
      description: 'Her iki katman birlestirildi',
      ffmpegCommand: secondaryMusic
        ? `[0:a]volume=1.0[a1];[1:a]volume=0.3[a2];[a1][a2]amix=inputs=2:duration=longest[out]`
        : null,
    },
  };
}

// --- Muzik Fade-In/Out (Yumusak Gecis) --------------------------------------
export function generateMusicFade(duration = 15, fadeInDuration = 1, fadeOutDuration = 1) {
  return {
    fadeIn: {
      duration: fadeInDuration,
      ffmpegFilter: `afade=t=in:st=0:d=${fadeInDuration}`,
      description: `${fadeInDuration} saniyede muzik yavasca baslayacak`,
    },
    fadeOut: {
      duration: fadeOutDuration,
      startSecond: duration - fadeOutDuration,
      ffmpegFilter: `afade=t=out:st=${duration - fadeOutDuration}:d=${fadeOutDuration}`,
      description: `Son ${fadeOutDuration} saniyede muzik yavasca bitecek`,
    },
    combined: {
      ffmpegFilter: `afade=t=in:st=0:d=${fadeInDuration},afade=t=out:st=${duration - fadeOutDuration}:d=${fadeOutDuration}`,
    },
  };
}

// --- Muzik Kalitesi Analizi -------------------------------------------------
export function analyzeMusicQuality(musicFile) {
  // Muzik dosyasinin teknik ozelliklerini kontrol et
  if (!fs.existsSync(musicFile)) {
    return { error: 'Muzik dosyasi bulunamadi' };
  }

  const stats = fs.statSync(musicFile);
  const fileSizeKB = stats.size / 1024;

  return {
    file: musicFile,
    fileSizeKB: Math.round(fileSizeKB),
    quality: fileSizeKB > 5000 ? 'High (320kbps+)' : fileSizeKB > 2000 ? 'Medium (192kbps)' : 'Low (128kbps)',
    recommendation: fileSizeKB > 5000
      ? ' Muzik kalitesi mukemmel'
      : fileSizeKB > 2000
      ? '️ Muzik kalitesi iyi ama daha yuksek olabilir'
      : '❌ Muzik kalitesi dusuk, daha iyi bir versiyon kullan',
  };
}

// --- Sonic Mastery Raporu ---------------------------------------------------
export function generateSonicMasteryReport(category, dominantEmotion, videoScript) {
  const musicSelection = selectMusicByEmotion(category, dominantEmotion);
  const duckingFilter = generateFrequencyDuckingFilter(musicSelection?.duckingLevel || 0.4);
  const fadeSettings = generateMusicFade(15, 1, 1);
  const musicQuality = analyzeMusicQuality(musicSelection?.musicFile);

  return {
    timestamp: new Date().toISOString(),
    category,
    emotion: dominantEmotion,
    musicSelection,
    audioProcessing: {
      ducking: duckingFilter,
      fade: fadeSettings,
      quality: musicQuality,
    },
    recommendation: ` ${musicSelection?.musicName} secildi. Seslendirme sirasinda ${Math.round((1 - (musicSelection?.duckingLevel || 0.4)) * 100)}% kisilacak.`,
  };
}

// --- FFmpeg Kompleks Ses Filtresi Olustur -----------------------------------
export function buildComplexAudioFilter(duckingLevel = 0.4, emphasisPoints = []) {
  let filterChain = [];

  // Temel ducking
  filterChain.push(`volume=${duckingLevel}:eval=frame`);

  // Vurgu noktalari
  for (const point of emphasisPoints) {
    filterChain.push(`volume=${point.emphasisBump}:eval=frame`);
  }

  // Fade-in ve fade-out
  filterChain.push(`afade=t=in:st=0:d=1,afade=t=out:st=14:d=1`);

  return filterChain.join(',');
}

// --- Muzik Kutuphanesi Durumu -----------------------------------------------
export function getMusicLibraryStatus() {
  const musicBasePath = path.join(process.cwd(), 'storage', 'music');
  const status = {};

  for (const category of Object.keys(MUSIC_CATEGORIES)) {
    const categoryPath = path.join(musicBasePath, category);
    const musicFiles = fs.existsSync(categoryPath) 
      ? fs.readdirSync(categoryPath).filter(f => f.endsWith('.mp3'))
      : [];

    status[category] = {
      category: MUSIC_CATEGORIES[category].name,
      musicCount: musicFiles.length,
      musicFiles,
      status: musicFiles.length > 0 ? ' Hazir' : '️ Muzik yok',
    };
  }

  return {
    timestamp: new Date().toISOString(),
    totalCategories: Object.keys(MUSIC_CATEGORIES).length,
    categories: status,
    recommendation: Object.values(status).every(s => s.musicCount > 0)
      ? ' Muzik kutuphanesi tam donanimli'
      : '️ Bazi kategorilerde muzik eksik',
  };
}
