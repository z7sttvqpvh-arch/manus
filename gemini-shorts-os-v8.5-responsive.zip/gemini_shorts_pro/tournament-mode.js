/**
 * Tournament Mode — Video Turnuvası Modu
 * =======================================
 * Sistem tek bir konu için 3 farklı video varyasyonu üretir ve
 * Gemini'ye "Yarıştırır". Sadece şampiyon video yayınlanır.
 */

import * as browser from './browser-automation.js';

// ─── Turnuva Varyasyonları ──────────────────────────────────────────────────
const TOURNAMENT_VARIANTS = [
  {
    id: 'variant_a',
    name: 'Variant A: Aggressive Hook',
    description: 'Çok güçlü, merak uyandırıcı bir hook ile başlayan versiyon',
    hookStyle: 'shock',
    pacing: 'fast',
    musicIntensity: 'high',
    colorFilter: 'vibrant',
  },
  {
    id: 'variant_b',
    name: 'Variant B: Mysterious Hook',
    description: 'Gizemli ve yavaş açılışlı, derin bir versiyon',
    hookStyle: 'mystery',
    pacing: 'slow-to-fast',
    musicIntensity: 'medium',
    colorFilter: 'vintage',
  },
  {
    id: 'variant_c',
    name: 'Variant C: Direct Hook',
    description: 'Doğrudan ve net açılışlı, pratik bir versiyon',
    hookStyle: 'direct',
    pacing: 'moderate',
    musicIntensity: 'medium',
    colorFilter: 'neutral',
  },
];

// ─── Turnuva Varyasyonlarını Oluştur ────────────────────────────────────────
export function generateTournamentVariants(topic, category, baseContent) {
  const variants = TOURNAMENT_VARIANTS.map((variant, index) => ({
    ...variant,
    topic,
    category,
    content: baseContent, // Aynı içerik, farklı sunum
    variantNumber: index + 1,
    createdAt: new Date().toISOString(),
    scores: {
      scrollStop: null,
      engagement: null,
      retention: null,
      overall: null,
    },
  }));

  return variants;
}

// ─── Turnuva Varyasyonlarını Gemini'ye Yarıştır ────────────────────────────
export async function runTournament(variants) {
  console.log(`🏆 Turnuva başlıyor! ${variants.length} video yarışacak...`);

  const variantDescriptions = variants
    .map((v, i) => `${i + 1}. ${v.name}: ${v.description}`)
    .join('\n');

  const prompt = `Aşağıdaki 3 video varyasyonunu değerlendir. Hangi versiyon YouTube Shorts'ta daha çok izlenir ve izleyiciyi daha uzun süre tutar?

${variantDescriptions}

Hepsi aynı içeriği içeriyor, sadece sunuş şekli (hook stili, müzik, renk, hız) farklı.

Cevap JSON formatında (başka hiçbir şey yazma):
{
  "scores": [
    {"variant": 1, "scrollStopScore": 92, "engagementScore": 88, "retentionScore": 85, "reason": "Çok güçlü hook, izleyiciyi hemen yakalar"},
    {"variant": 2, "scrollStopScore": 78, "engagementScore": 72, "retentionScore": 70, "reason": "Gizemli ama biraz yavaş"},
    {"variant": 3, "scrollStopScore": 65, "engagementScore": 68, "retentionScore": 62, "reason": "Doğrudan ama sıkıcı"}
  ],
  "champion": 1,
  "reasoning": "Variant A en yüksek scroll-stop gücüne ve tutulma oranına sahip"
}`;

  try {
    const response = await browser.sendMessageToGemini(prompt);
    const jsonMatch = response.match(/\{[\s\S]*\}/);

    if (!jsonMatch) {
      console.warn('⚠ Turnuva sonucu JSON bulunamadı, varsayılan skor veriliyor');
      return assignDefaultTournamentScores(variants);
    }

    const tournamentResult = JSON.parse(jsonMatch[0]);

    // Skorları varyantlara ata
    for (const score of tournamentResult.scores) {
      const variant = variants[score.variant - 1];
      if (variant) {
        variant.scores.scrollStop = score.scrollStopScore;
        variant.scores.engagement = score.engagementScore;
        variant.scores.retention = score.retentionScore;
        variant.scores.overall = Math.round(
          (score.scrollStopScore * 0.5 + score.engagementScore * 0.3 + score.retentionScore * 0.2)
        );
        variant.scores.reason = score.reason;
      }
    }

    const champion = variants[tournamentResult.champion - 1];
    console.log(`🏆 Şampiyon: ${champion.name} (${champion.scores.overall} puan)`);

    return {
      variants,
      champion,
      championIndex: tournamentResult.champion - 1,
      reasoning: tournamentResult.reasoning,
    };
  } catch (e) {
    console.error('Turnuva hatası:', e.message);
    return assignDefaultTournamentScores(variants);
  }
}

// ─── Varsayılan Turnuva Skorları ────────────────────────────────────────────
function assignDefaultTournamentScores(variants) {
  const scores = [
    { scrollStop: 92, engagement: 88, retention: 85 },
    { scrollStop: 78, engagement: 72, retention: 70 },
    { scrollStop: 65, engagement: 68, retention: 62 },
  ];

  variants.forEach((v, i) => {
    v.scores.scrollStop = scores[i]?.scrollStop || 70;
    v.scores.engagement = scores[i]?.engagement || 70;
    v.scores.retention = scores[i]?.retention || 70;
    v.scores.overall = Math.round(
      (v.scores.scrollStop * 0.5 + v.scores.engagement * 0.3 + v.scores.retention * 0.2)
    );
  });

  const champion = variants.reduce((prev, current) =>
    (prev.scores.overall || 0) > (current.scores.overall || 0) ? prev : current
  );

  return {
    variants,
    champion,
    championIndex: variants.indexOf(champion),
    reasoning: 'Varsayılan skor (Turnuva çalışmadı)',
  };
}

// ─── Turnuva Raporu ─────────────────────────────────────────────────────────
export function generateTournamentReport(tournamentResult) {
  const sortedVariants = [...tournamentResult.variants].sort(
    (a, b) => (b.scores.overall || 0) - (a.scores.overall || 0)
  );

  return {
    timestamp: new Date().toISOString(),
    totalVariants: tournamentResult.variants.length,
    champion: {
      name: tournamentResult.champion.name,
      variantNumber: tournamentResult.champion.variantNumber,
      scores: tournamentResult.champion.scores,
    },
    allScores: sortedVariants.map((v, i) => ({
      rank: i + 1,
      name: v.name,
      scrollStop: v.scores.scrollStop,
      engagement: v.scores.engagement,
      retention: v.scores.retention,
      overall: v.scores.overall,
      reason: v.scores.reason,
    })),
    reasoning: tournamentResult.reasoning,
    recommendation: `✓ ${tournamentResult.champion.name} seçildi ve yayınlanacak.`,
    eliminatedVariants: sortedVariants.slice(1).map(v => ({
      name: v.name,
      reason: `${v.scores.overall} puan ile elenmiştir`,
    })),
  };
}

// ─── Turnuva Geçmişi Kaydet ─────────────────────────────────────────────────
export function recordTournamentHistory(jobId, tournamentReport) {
  return {
    jobId,
    timestamp: new Date().toISOString(),
    championVariant: tournamentReport.champion.name,
    championScore: tournamentReport.champion.scores.overall,
    totalVariants: tournamentReport.totalVariants,
    eliminatedCount: tournamentReport.eliminatedVariants.length,
    report: tournamentReport,
  };
}

// ─── Turnuva Performans Analizi ─────────────────────────────────────────────
export function analyzeTournamentPerformance(tournamentHistories = []) {
  if (tournamentHistories.length === 0) {
    return { message: 'Henüz turnuva geçmişi yok' };
  }

  const variantWins = {};
  const variantScores = {};

  for (const history of tournamentHistories) {
    const champion = history.championVariant;
    variantWins[champion] = (variantWins[champion] || 0) + 1;

    if (!variantScores[champion]) {
      variantScores[champion] = { scores: [], avgScore: 0 };
    }
    variantScores[champion].scores.push(history.championScore);
  }

  // Ortalama hesapla
  for (const [variant, data] of Object.entries(variantScores)) {
    const sum = data.scores.reduce((a, b) => a + b, 0);
    data.avgScore = Math.round(sum / data.scores.length);
  }

  const sorted = Object.entries(variantWins)
    .map(([variant, wins]) => ({
      variant,
      wins,
      avgScore: variantScores[variant].avgScore,
      winRate: Math.round((wins / tournamentHistories.length) * 100),
    }))
    .sort((a, b) => b.wins - a.wins);

  return {
    totalTournaments: tournamentHistories.length,
    bestPerformingVariant: sorted[0],
    allVariantPerformance: sorted,
    recommendation: `"${sorted[0].variant}" varyasyonu %${sorted[0].winRate} oranında şampiyon olmuştur. Bu stili tercih et.`,
  };
}

// ─── Turnuva Stratejisi Önerileri ────────────────────────────────────────────
export function generateTournamentStrategy(tournamentPerformance) {
  const best = tournamentPerformance.bestPerformingVariant;

  return {
    recommendation: `Gelecekte "${best.variant}" tarzında videolar üret`,
    reason: `Bu varyasyon ${best.wins} turnuvada şampiyon oldu (${best.winRate}% başarı oranı)`,
    avgScore: best.avgScore,
    strategy: `Gelecek videolarda "${best.variant}" özelliklerini (hook stili, müzik yoğunluğu, renk filtresi) kullan`,
  };
}
