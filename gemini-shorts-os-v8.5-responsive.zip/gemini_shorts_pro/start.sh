#!/usr/bin/env bash
set -e

# ── Gemini Executive Shorts OS — Pro Edition ──────────────────────────
# Başlatma scripti

echo "======================================"
echo "  Gemini Executive Shorts OS v2.0 Pro"
echo "======================================"

# Node.js versiyon kontrolü
NODE_VERSION=$(node -e "process.exit(parseInt(process.versions.node.split('.')[0]))" 2>/dev/null; echo $?)
if ! node -e "if(parseInt(process.versions.node.split('.')[0]) < 20) process.exit(1)" 2>/dev/null; then
  echo "❌ Node.js 20+ gerekli. Mevcut: $(node --version)"
  exit 1
fi
echo "✓ Node.js: $(node --version)"

# FFmpeg kontrolü
if command -v ffmpeg &> /dev/null; then
  echo "✓ FFmpeg: $(ffmpeg -version 2>&1 | head -1 | cut -d' ' -f3)"
else
  echo "⚠ FFmpeg bulunamadı — video render devre dışı (metin çıktı kullanılacak)"
  echo "  Kurulum: sudo apt install ffmpeg"
fi

# edge-tts kontrolü (opsiyonel)
if command -v edge-tts &> /dev/null; then
  echo "✓ edge-tts: mevcut (TTS aktif edilebilir)"
else
  echo "ℹ edge-tts yok — TTS devre dışı (kurulum: pip install edge-tts)"
fi

echo ""
echo "🚀 Sunucu başlatılıyor..."
echo "   Panel: http://localhost:3001"
echo ""

node server.js
