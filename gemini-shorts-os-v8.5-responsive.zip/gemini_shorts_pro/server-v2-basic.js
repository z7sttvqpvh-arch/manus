/**
 * Gemini Executive Shorts OS — Free Edition v2.5
 * ================================================
 * Tamamen API bağımsız, tarayıcı otomasyonu ile çalışan
 * - ChatGPT / Gemini Web arayüzü kullanımı
 * - Video Viral Analizi
 * - Ücretsiz kullanım (API key gerekmiyor)
 */

import http from 'http';
import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import crypto from 'crypto';
import * as browser from './browser-automation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir   = path.join(__dirname, 'public');
const dataDir     = path.join(__dirname, 'data');
const storageDir  = path.join(__dirname, 'storage');
const outputsDir  = path.join(storageDir, 'outputs');
const analysisDir = path.join(storageDir, 'analysis');
const dbPath      = path.join(dataDir, 'db.json');
const configPath  = path.join(__dirname, 'config.json');
const logPath     = path.join(__dirname, 'logs', 'server.log');

// ─── SSE istemcileri ────────────────────────────────────────────────────────
const sseClients = new Set();

// ─── Varsayılan veritabanı şeması ───────────────────────────────────────────
const defaultDb = {
  channels: [],
  jobs: [],
  settings: {
    autoMode: false,
    autoIntervalMinutes: 180,
    aiService: 'gemini', // 'gemini' veya 'chatgpt'
    model: 'free',
    targetVideoSeconds: 30,
    publishThreshold: 78,
    maxCandidates: 5,
    maxRepairRounds: 3,
    maxDailyPerChannel: 2,
    minUploadIntervalMinutes: 120,
    ttsEnabled: false,
    ttsVoice: 'tr-TR-EmelNeural',
    watermark: '',
    defaultPrivacy: 'public',
    notifyWebhook: '',
    maxJobHistory: 100,
    concurrentJobs: false,
    videoAnalysisEnabled: true,
  },
  learning: {
    badOpenings: [],
    goodPatterns: [],
    badPatterns: [],
    topicHistory: [],
    performanceLog: [],
  },
  stats: {
    totalJobs: 0,
    successJobs: 0,
    failedJobs: 0,
    totalUploads: 0,
    totalAnalysis: 0,
  }
};

// ─── Boot & DB ──────────────────────────────────────────────────────────────
await ensureBoot();
let db = await loadDb();
const fileLocks = new Map();
let schedulerTimer = null;
let activeJobs = new Map();
ensureScheduler();

// ─── Yardımcı fonksiyonlar ──────────────────────────────────────────────────
function uid(prefix = 'id') { return `${prefix}_${crypto.randomBytes(8).toString('hex')}`; }
function nowIso() { return new Date().toISOString(); }
function delay(ms) { return new Promise(r => setTimeout(r, ms)); }
function rand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

async function ensureBoot() {
  const dirs = [
    dataDir, outputsDir, analysisDir,
    path.join(storageDir, 'temp'),
    path.join(storageDir, 'audio'),
    path.join(storageDir, 'backgrounds'),
    path.join(__dirname, 'logs'),
  ];
  for (const d of dirs) await fsp.mkdir(d, { recursive: true });
  try { await fsp.access(dbPath); } catch {
    await fsp.writeFile(dbPath, JSON.stringify(defaultDb, null, 2));
  }
}

async function loadDb() {
  let raw = { ...defaultDb };
  try { raw = JSON.parse(await fsp.readFile(dbPath, 'utf8')); } catch {}
  raw.settings  = { ...defaultDb.settings, ...(raw.settings || {}) };
  raw.channels  = raw.channels || [];
  raw.jobs      = raw.jobs || [];
  raw.learning  = { ...defaultDb.learning, ...(raw.learning || {}) };
  raw.stats     = { ...defaultDb.stats, ...(raw.stats || {}) };
  return raw;
}

async function saveDb() {
  while (fileLocks.get('db')) await delay(10);
  fileLocks.set('db', true);
  try {
    await fsp.writeFile(dbPath, JSON.stringify(db, null, 2));
  } finally {
    fileLocks.delete('db');
  }
}

// ─── Loglama & SSE ──────────────────────────────────────────────────────────
async function log(msg, level = 'info') {
  const line = `[${nowIso()}] [${level.toUpperCase()}] ${msg}\n`;
  await fsp.appendFile(logPath, line).catch(() => {});
  if (level !== 'debug') console.log(`[${level.toUpperCase()}] ${msg}`);
  broadcastSSE({ type: 'log', level, msg, ts: nowIso() });
}

function broadcastSSE(data) {
  const payload = `data: ${JSON.stringify(data)}\n\n`;
  for (const res of sseClients) {
    try { res.write(payload); } catch { sseClients.delete(res); }
  }
}

// ─── HTTP yardımcıları ───────────────────────────────────────────────────────
function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
    'Access-Control-Allow-Origin': '*',
  });
  res.end(body);
}

async function parseBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > 10e6) { req.destroy(); reject(new Error('Body too large')); }
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

function serveFile(res, filePath, contentType = 'text/html; charset=utf-8') {
  fs.readFile(filePath, (err, data) => {
    if (err) return sendJson(res, 404, { error: 'Not found' });
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
}

// ─── İçerik Üretim (Tarayıcı Otomasyonu ile) ────────────────────────────────
async function generateCandidates(channel, topic) {
  try {
    await log(`[${channel.name}] İçerik üretiliyor: "${topic}"`);
    const candidates = await browser.generateContentViaAI(channel, topic, db.settings.aiService);
    await log(`[${channel.name}] ${candidates.length} aday üretildi`);
    return candidates;
  } catch (e) {
    await log(`İçerik üretim hatası: ${e.message}`, 'error');
    throw e;
  }
}

// ─── Video Analizi (Tarayıcı Otomasyonu ile) ────────────────────────────────
async function analyzeVideoViral(videoPath) {
  if (!db.settings.videoAnalysisEnabled) return null;
  
  try {
    await log(`Video analiz ediliyor: ${path.basename(videoPath)}`);
    const analysis = await browser.analyzeVideoViaAI(videoPath, db.settings.aiService);
    
    const analysisFile = path.join(analysisDir, `${path.basename(videoPath, '.mp4')}_analysis.json`);
    await fsp.writeFile(analysisFile, JSON.stringify(analysis, null, 2));
    
    db.stats.totalAnalysis = (db.stats.totalAnalysis || 0) + 1;
    await saveDb();
    await log(`Video analizi tamamlandı (Viral Skoru: ${analysis.viralScore})`);
    
    return analysis;
  } catch (e) {
    await log(`Video analizi hatası: ${e.message}`, 'warn');
    return null;
  }
}

// ─── Basit Puanlama (Fallback) ──────────────────────────────────────────────
function scoreCandidate(c, recentTitles = []) {
  const voice = c.voiceText || '';
  const hook  = c.hook || '';
  const title = c.title || '';

  const hookLen = hook.length;
  const hookImpact = Math.min(100, 60 + Math.floor(hookLen / 4));
  const clarity = voice.split(/[.!?]/).length > 2 ? 85 : 75;
  const titleStrength = /\?|neden|kimse/.test(title.toLowerCase()) ? 84 : 76;
  const humanLikeness = /çünkü|ama|aslında/.test(voice.toLowerCase()) ? 82 : 72;
  const retentionProxy = Math.round((hookImpact + clarity + titleStrength + humanLikeness) / 4);

  return {
    hookImpact, clarity, titleStrength, humanLikeness, retentionProxy,
    repetitionRisk: 15, policyRisk: 8,
  };
}

// ─── Varsayılan Konu ────────────────────────────────────────────────────────
const TOPIC_POOLS = {
  psychology: [
    'İnsanlar neden aynı hataları tekrar eder',
    'Kendi kendini sabote etme davranışı',
    'İlk izlenim neden bu kadar güçlü',
  ],
  shock: [
    'Çoğu kişinin bilmediği zihinsel hata',
    'Bir kararın hayatı nasıl saptırdığı',
    'Kimsenin fark etmediği günlük tuzak',
  ],
  motivation: [
    'Disiplini öldüren görünmez alışkanlık',
    'Ertelemenin arkasındaki gerçek neden',
    'İlerlemeyi durduran küçük hata',
  ],
};

function defaultIdea(channel) {
  const pool = TOPIC_POOLS[channel.category] || TOPIC_POOLS.psychology;
  return rand(pool);
}

// ─── Fallback İçerik ────────────────────────────────────────────────────────
function fallbackCandidates(topic, channel, count = 5) {
  return Array.from({ length: count }).map((_, i) => ({
    id: uid('cand'),
    hook: `Çoğu kişinin fark etmediği şey şu: ${topic}`,
    title: `Neden ${topic}`,
    firstFrameText: topic.slice(0, 48),
    voiceText: `${topic}. Çoğu insan sorunun ne olduğunu anladığını sanıyor ama asıl mesele görünmeyen alışkanlıkta başlıyor.`,
    cta: 'Sence bu sende de var mı?',
    thumbnailText: 'KİMSE BUNU BÖYLE ANLATMIYOR',
    description: `${topic} üzerine kısa bir anlatım.`,
    tags: ['#shorts', '#psikoloji', '#motivasyon'],
  }));
}

// ─── FFmpeg ile Video Render ────────────────────────────────────────────────
async function renderWinner(job) {
  const winner  = job.winner;
  const outMp4  = path.join(outputsDir, `${job.id}.mp4`);
  const dur     = db.settings.targetVideoSeconds || 30;

  try {
    // Sessiz ses oluştur
    const audioPath = path.join(storageDir, 'audio', `${job.id}.wav`);
    await execSpawn('ffmpeg', [
      '-y', '-f', 'lavfi',
      '-i', `anullsrc=r=44100:cl=stereo`,
      '-t', String(dur),
      audioPath,
    ]);

    // Video render et
    const safeTitle = (winner.firstFrameText || winner.title || 'Shorts').replace(/[:'\\]/g, '').slice(0, 80);
    const vf = [
      'drawbox=x=0:y=0:w=1080:h=1920:color=#0f1729:t=fill',
      `drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='${safeTitle}':fontcolor=white:fontsize=52:x=(w-text_w)/2:y=100`,
      `drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='${(winner.cta||'').replace(/[:'\\]/g,'').slice(0,60)}':fontcolor=white:fontsize=36:x=(w-text_w)/2:y=1700`,
    ];

    await execSpawn('ffmpeg', [
      '-y', '-f', 'lavfi', '-i', 'color=c=#0f1729:s=1080x1920:r=30',
      '-i', audioPath,
      '-vf', vf.join(','),
      '-t', String(dur),
      '-c:v', 'libx264', '-preset', 'fast', '-crf', '23',
      '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-b:a', '128k',
      outMp4,
    ]);

    await log(`Video render tamamlandı: ${outMp4}`);
    return { outputPath: outMp4, rendered: true };

  } catch (e) {
    await log(`Video render hatası: ${e.message}`, 'error');
    return { outputPath: null, rendered: false, error: e.message };
  }
}

async function execSpawn(cmd, args) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { stdio: 'ignore' });
    p.on('error', reject);
    p.on('close', code => code === 0 ? resolve() : reject(new Error(`${cmd} exit ${code}`)));
  });
}

// ─── Ana İş Akışı ───────────────────────────────────────────────────────────
async function runJob(channelId, forceTopic = null) {
  if (!db.settings.concurrentJobs && activeJobs.size > 0) {
    return { ok: false, reason: 'job_active' };
  }

  const channel = db.channels.find(c => c.id === channelId && c.enabled !== false);
  if (!channel) return { ok: false, reason: 'channel_not_found' };

  const topic = forceTopic || defaultIdea(channel);
  const job = {
    id:          uid('job'),
    channelId,
    channelName: channel.name,
    status:      'generating',
    createdAt:   nowIso(),
    topic,
    candidates:  [],
    winner:      null,
    render:      null,
    analysis:    null,
    error:       null,
    duration:    null,
  };

  db.jobs.unshift(job);
  if (db.jobs.length > db.settings.maxJobHistory) {
    db.jobs = db.jobs.slice(0, db.settings.maxJobHistory);
  }
  db.stats.totalJobs = (db.stats.totalJobs || 0) + 1;
  await saveDb();

  activeJobs.set(channelId, job.id);
  broadcastSSE({ type: 'job_start', jobId: job.id, channelId, topic });
  await log(`İş başladı [${job.id}] — Kanal: ${channel.name}, Konu: "${topic}"`);

  const jobStart = Date.now();
  try {
    // 1. İçerik üret
    await log(`[${job.id}] İçerik üretiliyor...`);
    let candidates = await generateCandidates(channel, topic);
    if (!candidates || candidates.length === 0) {
      candidates = fallbackCandidates(topic, channel, db.settings.maxCandidates);
      await log(`[${job.id}] Fallback içerik kullanılıyor`);
    }
    job.candidates = candidates.map(c => ({ ...c, scores: scoreCandidate(c) }));

    // 2. Kazananı seç
    const winner = job.candidates.find(c => c.scores.retentionProxy >= db.settings.publishThreshold) || job.candidates[0];
    job.winner = winner;
    job.status = 'rendering';
    await saveDb();
    broadcastSSE({ type: 'job_update', jobId: job.id, status: 'rendering' });

    // 3. Video render et
    await log(`[${job.id}] Video render ediliyor...`);
    const render = await renderWinner(job);
    job.render = render;

    // 4. Video analizi yap
    if (render.rendered && db.settings.videoAnalysisEnabled) {
      job.status = 'analyzing';
      await saveDb();
      broadcastSSE({ type: 'job_update', jobId: job.id, status: 'analyzing' });
      await log(`[${job.id}] Video analiz ediliyor...`);
      const analysis = await analyzeVideoViral(render.outputPath);
      job.analysis = analysis;
    }

    job.status   = 'completed';
    job.duration = Date.now() - jobStart;
    db.stats.successJobs = (db.stats.successJobs || 0) + 1;
    await saveDb();
    broadcastSSE({ type: 'job_complete', jobId: job.id, duration: job.duration });
    await log(`[${job.id}] İş tamamlandı (${Math.round(job.duration / 1000)}s)`);
    return { ok: true, job };

  } catch (e) {
    job.status = 'failed';
    job.error  = e.message;
    job.duration = Date.now() - jobStart;
    db.stats.failedJobs = (db.stats.failedJobs || 0) + 1;
    await saveDb();
    broadcastSSE({ type: 'job_error', jobId: job.id, error: e.message });
    await log(`[${job.id}] İş başarısız: ${e.message}`, 'error');
    return { ok: false, error: e.message };
  } finally {
    activeJobs.delete(channelId);
  }
}

// ─── Zamanlayıcı ────────────────────────────────────────────────────────────
function ensureScheduler() {
  if (schedulerTimer) clearInterval(schedulerTimer);
  schedulerTimer = setInterval(async () => {
    try {
      db = await loadDb();
      if (!db.settings.autoMode) return;
      const channels = db.channels.filter(c => c.enabled !== false);
      for (const channel of channels) {
        if (activeJobs.has(channel.id)) continue;
        const lastJob = db.jobs.find(j => j.channelId === channel.id);
        if (lastJob) {
          const elapsed = Date.now() - new Date(lastJob.createdAt).getTime();
          const interval = db.settings.autoIntervalMinutes * 60_000;
          if (elapsed < interval) continue;
        }
        await log(`Otomatik iş tetiklendi: ${channel.name}`);
        runJob(channel.id).catch(e => log(`Otomatik iş hatası: ${e.message}`, 'error'));
        if (!db.settings.concurrentJobs) break;
      }
    } catch (e) {
      await log(`Zamanlayıcı hatası: ${e.message}`, 'error');
    }
  }, 30_000);
}

// ─── API Endpoint'leri ───────────────────────────────────────────────────────
async function handleApi(req, res, pathname) {
  // GET /api/health
  if (req.method === 'GET' && pathname === '/api/health') {
    const browserStatus = await browser.getBrowserStatus();
    return sendJson(res, 200, {
      ok: true,
      version: '2.5.0-free',
      aiService: db.settings.aiService,
      browserStatus,
      stats: db.stats,
    });
  }

  // GET /api/state
  if (req.method === 'GET' && pathname === '/api/state') {
    return sendJson(res, 200, {
      channels:  db.channels,
      jobs:      db.jobs.slice(0, 30),
      settings:  db.settings,
      stats:     db.stats,
      learning:  db.learning,
      activeJobs: [...activeJobs.entries()].map(([ch, jid]) => ({ channelId: ch, jobId: jid })),
    });
  }

  // GET /api/logs
  if (req.method === 'GET' && pathname === '/api/logs') {
    try {
      const lines = (await fsp.readFile(logPath, 'utf8')).split('\n').filter(Boolean);
      return sendJson(res, 200, { logs: lines.slice(-200) });
    } catch {
      return sendJson(res, 200, { logs: [] });
    }
  }

  // GET /api/events (SSE)
  if (req.method === 'GET' && pathname === '/api/events') {
    res.writeHead(200, {
      'Content-Type':  'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection':    'keep-alive',
      'Access-Control-Allow-Origin': '*',
    });
    res.write('data: {"type":"connected"}\n\n');
    sseClients.add(res);
    req.on('close', () => sseClients.delete(res));
    return;
  }

  // POST /api/channels
  if (req.method === 'POST' && pathname === '/api/channels') {
    const body = await parseBody(req);
    if (!body.name) return sendJson(res, 400, { error: 'name zorunlu' });
    const channel = {
      id:        uid('ch'),
      name:      body.name.trim(),
      category:  body.category || 'psychology',
      enabled:   true,
      createdAt: nowIso(),
    };
    db.channels.push(channel);
    await saveDb();
    await log(`Kanal eklendi: ${channel.name}`);
    return sendJson(res, 200, { ok: true, channel });
  }

  // DELETE /api/channels/:id
  if (req.method === 'DELETE' && pathname.startsWith('/api/channels/')) {
    const id = pathname.split('/')[3];
    const idx = db.channels.findIndex(c => c.id === id);
    if (idx === -1) return sendJson(res, 404, { error: 'Kanal bulunamadı' });
    db.channels.splice(idx, 1);
    await saveDb();
    return sendJson(res, 200, { ok: true });
  }

  // POST /api/channels/:id/toggle
  if (req.method === 'POST' && pathname.startsWith('/api/channels/') && pathname.endsWith('/toggle')) {
    const id = pathname.split('/')[3];
    const ch = db.channels.find(c => c.id === id);
    if (!ch) return sendJson(res, 404, { error: 'Kanal bulunamadı' });
    ch.enabled = !ch.enabled;
    await saveDb();
    return sendJson(res, 200, { ok: true, channel: ch });
  }

  // POST /api/settings
  if (req.method === 'POST' && pathname === '/api/settings') {
    const body = await parseBody(req);
    const allowed = [
      'autoMode', 'autoIntervalMinutes', 'aiService', 'targetVideoSeconds',
      'publishThreshold', 'maxCandidates', 'maxRepairRounds', 'maxDailyPerChannel',
      'minUploadIntervalMinutes', 'ttsEnabled', 'ttsVoice', 'watermark',
      'defaultPrivacy', 'notifyWebhook', 'maxJobHistory', 'concurrentJobs',
      'videoAnalysisEnabled',
    ];
    for (const k of allowed) {
      if (body[k] !== undefined) db.settings[k] = body[k];
    }
    await saveDb();
    ensureScheduler();
    return sendJson(res, 200, { ok: true, settings: db.settings });
  }

  // POST /api/run
  if (req.method === 'POST' && pathname === '/api/run') {
    const body = await parseBody(req);
    if (!body.channelId) return sendJson(res, 400, { error: 'channelId zorunlu' });
    const result = await runJob(body.channelId, body.topic || null);
    return sendJson(res, 200, result);
  }

  // POST /api/browser/login
  if (req.method === 'POST' && pathname === '/api/browser/login') {
    const body = await parseBody(req);
    const service = body.service || 'gemini';
    try {
      await browser.openBrowserForManualLogin(service);
      return sendJson(res, 200, { ok: true, message: `${service} tarayıcısı açıldı. Lütfen manuel olarak giriş yapın.` });
    } catch (e) {
      return sendJson(res, 500, { error: e.message });
    }
  }

  // GET /api/browser/status
  if (req.method === 'GET' && pathname === '/api/browser/status') {
    const status = await browser.getBrowserStatus();
    return sendJson(res, 200, status);
  }

  // GET /api/outputs/:file
  if (req.method === 'GET' && pathname.startsWith('/api/outputs/')) {
    const fname = path.basename(pathname.slice('/api/outputs/'.length));
    const fp = path.join(outputsDir, fname);
    try {
      await fsp.access(fp);
      const ext = path.extname(fp).toLowerCase();
      const types = { '.mp4': 'video/mp4', '.txt': 'text/plain', '.json': 'application/json' };
      fs.readFile(fp, (err, data) => {
        if (err) return sendJson(res, 404, { error: 'Dosya bulunamadı' });
        res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
        res.end(data);
      });
    } catch {
      sendJson(res, 404, { error: 'Dosya bulunamadı' });
    }
    return;
  }

  // GET /api/analysis/:file
  if (req.method === 'GET' && pathname.startsWith('/api/analysis/')) {
    const fname = path.basename(pathname.slice('/api/analysis/'.length));
    const fp = path.join(analysisDir, fname);
    try {
      await fsp.access(fp);
      serveFile(res, fp, 'application/json');
    } catch {
      sendJson(res, 404, { error: 'Analiz bulunamadı' });
    }
    return;
  }

  return sendJson(res, 404, { error: 'API endpoint bulunamadı' });
}

// ─── HTTP Sunucu ────────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  try {
    const url      = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = url.pathname;

    if (req.method === 'OPTIONS') {
      res.writeHead(204, {
        'Access-Control-Allow-Origin':  '*',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      });
      return res.end();
    }

    if (pathname.startsWith('/api/')) return handleApi(req, res, pathname);
    if (pathname === '/' || pathname === '/index.html') return serveFile(res, path.join(publicDir, 'index.html'));
    return sendJson(res, 404, { error: 'Sayfa bulunamadı' });

  } catch (e) {
    await log(`Sunucu hatası: ${e.message}`, 'error');
    return sendJson(res, 500, { error: e.message });
  }
});

const PORT = 3001;
server.listen(PORT, async () => {
  await log(`🚀 Gemini Executive Shorts OS v2.5 Free — http://127.0.0.1:${PORT}`);
  await log(`AI Service: ${db.settings.aiService.toUpperCase()} | Video Analysis: ${db.settings.videoAnalysisEnabled ? 'Aktif' : 'Pasif'}`);
  await log(`Tarayıcı Otomasyonu: Hazır (Puppeteer)`);
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n⏹ Sistem kapatılıyor...');
  await browser.closeBrowser();
  process.exit(0);
});
