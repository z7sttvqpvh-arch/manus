# Gemini Executive Shorts OS — Free Edition v2.5

> **Tamamen Ücretsiz!** Tarayıcı Otomasyonu ile ChatGPT/Gemini Web'i kullanan YouTube Shorts otomasyon sistemi. API key gerekmiyor!

---

## 🎯 Temel Özellikler

### ✨ Tarayıcı Otomasyonu (API Bağımsız)
- **ChatGPT Web** veya **Gemini Web** arayüzünü Puppeteer ile kontrol ediyor
- Sanki bir insan yazıyormuş gibi mesaj gönderiyor
- Yapay zekanın cevabını otomatik okuyor
- **Tamamen ücretsiz** — API ücretleri yok!

### 🎬 İçerik Üretimi
- ChatGPT/Gemini'den otomatik YouTube Shorts içeriği üretimi
- 5 aday içerik üretip en iyisini seçme
- Konu tekrarını önleme
- Fallback sistem (hata durumunda hazır şablonlar)

### 📊 Video Viral Analizi (YENİ!)
- Render edilen videoyu tekrar yapay zekaya yükleyip analiz ettirme
- **Viral Potansiyeli Skoru** (0-100)
- **İzleyici Sıkılma Analizi** — Hangi saniyede sıkılacağını tahmin ediyor
- **Hook Gücü Analizi** — İlk 3 saniye yeterince güçlü mü?
- **Tutma Oranı Analizi** — Hangi bölümler en ilgi çekici?
- **İyileştirme Önerileri** — Ne değiştirilmeli?
- **Psikolojik Tetikleyiciler** — Hangi mekanizmalar kullanılmış?

### 🎨 Video Üretimi
- FFmpeg ile profesyonel 1080x1920 Shorts formatı
- Gradient arka plan tasarımı
- Otomatik başlık ve CTA yerleşimi
- Watermark desteği

### 🎛️ Modern Dashboard
- Sidebar navigasyon
- Canlı log akışı (SSE)
- İstatistik paneli
- İş geçmişi ve filtreleme
- Kanal yönetimi
- Video analiz raporları

---

## 🚀 Kurulum

### Gereksinimler
- **Node.js 20+**
- **FFmpeg** (video render için)
- **ChatGPT Premium** veya **Gemini** hesabı (ücretsiz web erişimi)

### Hızlı Başlangıç

```bash
# 1. Dizine gir
cd gemini-executive-shorts-os-pro

# 2. Bağımlılıkları kur (ilk kez)
pnpm install

# 3. Başlat
./start.sh
# veya
node server.js

# 4. Paneli aç
# http://localhost:3001
```

### FFmpeg Kurulumu

**Ubuntu/Debian:**
```bash
sudo apt update && sudo apt install -y ffmpeg
```

**macOS:**
```bash
brew install ffmpeg
```

---

## 📖 Kullanım

### 1. İlk Kurulum: Tarayıcı Oturumu Aç

Panel → **Ayarlar** → **Tarayıcı Oturumu Aç** → ChatGPT veya Gemini seçin

Tarayıcı açılacak, **manuel olarak giriş yapın**. Giriş yaptıktan sonra sistem otomatik devam edecektir.

### 2. Kanal Ekle

Panel → **Kanallar** → Kanal adı ve kategori girin → **Kanal Ekle**

Kategoriler:
- 🧠 Psikoloji
- ⚡ Şok / İlginç
- 🔥 Motivasyon
- 📚 Bilgi

### 3. İçerik Üret

Panel → **Üretim** → Kanal seçin → **Üretimi Başlat**

Sistem şu adımları otomatik yapacaktır:
1. ChatGPT/Gemini'ye mesaj gönder
2. 5 aday içerik al
3. En iyisini seç
4. Video render et
5. **Videoyu tekrar yapay zekaya yükle**
6. **Viral analizi yap**
7. Analiz raporunu kaydet

### 4. Analiz Raporunu Görüntüle

Panel → **İşler** → İşin satırını tıkla → **Analiz Raporu** bölümü

Raporta şunlar olacak:
- Viral Skoru
- Hangi saniyede sıkılacağı
- En ilgi çekici bölümler
- İyileştirme önerileri

### 5. Otomatik Mod

Panel → **Ayarlar** → **Auto Mode** aç → Aralık dakikasını ayarla → **Kaydet**

Sistem belirlediğiniz aralıkta otomatik içerik üretecektir.

---

## ⚙️ Yapılandırma

### config.json

```json
{
  "port": 3001,
  "aiService": "gemini",              // "gemini" veya "chatgpt"
  "autoMode": false,
  "autoIntervalMinutes": 180,
  "targetVideoSeconds": 30,
  "publishThreshold": 78,
  "maxCandidates": 5,
  "maxRepairRounds": 3,
  "videoAnalysisEnabled": true,       // Video analizi aktif/pasif
  "watermark": "",
  "maxJobHistory": 100,
  "concurrentJobs": false
}
```

---

## 🤖 ChatGPT vs Gemini

| Özellik | ChatGPT | Gemini |
|---------|---------|--------|
| **Türkçe Kalitesi** | Çok İyi | Çok İyi |
| **Hız** | Orta | Hızlı |
| **Ücretsiz Limit** | 3 mesaj/3 saat | Yüksek |
| **Video Yükleme** | Kısıtlı | Daha İyi |
| **Tarayıcı Otomasyonu** | ✓ Çalışıyor | ✓ Çalışıyor |

**Tavsiye:** Gemini daha hızlı ve video analizi için daha iyidir.

---

## 📊 API Endpoint'leri

| Method | Endpoint | Açıklama |
|--------|----------|----------|
| GET | `/api/health` | Sistem durumu |
| GET | `/api/state` | Tam durum |
| GET | `/api/logs` | Son 200 log |
| GET | `/api/events` | SSE canlı log |
| POST | `/api/channels` | Kanal ekle |
| DELETE | `/api/channels/:id` | Kanal sil |
| POST | `/api/settings` | Ayarları kaydet |
| POST | `/api/run` | İş başlat |
| POST | `/api/browser/login` | Tarayıcı oturumu aç |
| GET | `/api/browser/status` | Tarayıcı durumu |
| GET | `/api/outputs/:file` | Video indir |
| GET | `/api/analysis/:file` | Analiz raporu |

---

## 🎯 Viral Analiz Raporu Örneği

```json
{
  "viralScore": 82,
  "hookStrength": "Çok güçlü, ilk 2 saniye dikkat çekiyor",
  "retentionAnalysis": {
    "boringPointSeconds": [15, 22],
    "bestSegments": ["0-5s: Hook", "8-12s: Açıklama"],
    "improvementAreas": ["15-18s: Daha hızlı olmalı"]
  },
  "thumbnailTitleScore": 88,
  "ctaStrength": "Yeterince güçlü, soru soruyor",
  "improvements": [
    "15. saniyede hız artırılmalı",
    "Müzik eklenmeli",
    "Daha fazla görsel efekt"
  ],
  "targetAudience": "18-35 yaş, psikoloji ilgili",
  "psychologicalTriggers": [
    "Merak uyandırma (hook)",
    "Sosyal kanıt (çoğu kişi)",
    "Harekete geçirme (CTA)"
  ],
  "finalRecommendation": "Bu video viral olma potansiyeli yüksek. Küçük düzeltmelerle çok daha iyi olabilir."
}
```

---

## 🔧 Sorun Giderme

### Tarayıcı Açılmıyor
```bash
# Chrome'u manuel olarak kur
npx puppeteer browsers install chrome
```

### ChatGPT/Gemini Cevap Vermiyor
- Tarayıcıda manuel olarak giriş yaptığınızdan emin olun
- Oturum süresi dolmuş olabilir → Yeniden giriş yapın
- Mesaj sınırına ulaşmış olabilirsiniz → Biraz bekleyin

### Video Render Hatası
```bash
# FFmpeg kurulu mu kontrol et
ffmpeg -version
```

---

## 📝 Dosya Yapısı

```
gemini-executive-shorts-os-pro/
├── server.js                    # Ana sunucu (tarayıcı otomasyonu)
├── browser-automation.js        # Tarayıcı kontrol modülü
├── config.json                  # Yapılandırma
├── package.json
├── README-FREE.md               # Bu dosya
├── public/
│   └── index.html               # Dashboard
├── data/
│   └── db.json                  # Veritabanı
├── storage/
│   ├── outputs/                 # Videolar
│   ├── analysis/                # Analiz raporları (JSON)
│   ├── backgrounds/             # Arka plan videoları
│   └── audio/                   # Ses dosyaları
└── logs/
    └── server.log               # Sistem logları
```

---

## 🎓 İpuçları

1. **Daha İyi Sonuçlar İçin:**
   - Konu havuzunu özelleştirin (browser-automation.js)
   - Prompt'u düzenleyin (generateContentPrompt fonksiyonu)
   - Analiz raporlarını inceleyip öğrenin

2. **Performans:**
   - Video render süresi: 10-30 saniye
   - Yapay zeka cevap süresi: 30-120 saniye
   - Analiz süresi: 60-180 saniye

3. **Ücretsiz Kullanım:**
   - ChatGPT: Günde 3 mesaj (premium olmadan)
   - Gemini: Yüksek limit (günlük)
   - Sistem otomatik rate limiting yapıyor

---

## 📞 Destek

Sorunlar için:
1. Logları kontrol edin: `logs/server.log`
2. Panel → Loglar bölümünü inceleyin
3. Tarayıcı konsolunda hata mesajlarını kontrol edin

---

## 📄 Lisans

MIT

---

**Keyifli Shorts üretimi! 🎬**
