/**
 * Multi-Language System — Çoklu Dil Sistemi
 * ==========================================
 * Küresel dil desteği, yerelleştirilmiş seslendirme ve kültürel adaptasyon
 */

// ─── Desteklenen Diller ve Bölgesel Ayarlar ────────────────────────────────
export const SUPPORTED_LANGUAGES = {
  tr: {
    name: 'Türkçe',
    nativeName: 'Türkçe',
    region: 'TR',
    locale: 'tr-TR',
    ttsVoice: 'tr-TR-Emel',
    ttsVoiceAlt: 'tr-TR-Ahmet',
    googleTrendsRegion: 'TR',
    newsRegion: 'tr_TR',
    youtubeLanguage: 'tr',
    youtubeRegion: 'TR',
    culturalNuance: 'Türk kültürü, aile değerleri, geleneksel bilgelik',
    viralPatterns: ['Şaşkınlık', 'Merak', 'Gurur', 'Güven'],
    timeZone: 'Europe/Istanbul',
  },
  en: {
    name: 'English',
    nativeName: 'English',
    region: 'US',
    locale: 'en-US',
    ttsVoice: 'en-US-Guy',
    ttsVoiceAlt: 'en-US-Jenny',
    googleTrendsRegion: 'US',
    newsRegion: 'en_US',
    youtubeLanguage: 'en',
    youtubeRegion: 'US',
    culturalNuance: 'Amerikan kültürü, bireysellik, başarı, hızlılık',
    viralPatterns: ['Şok', 'Merak', 'Başarı', 'Motivasyon'],
    timeZone: 'America/New_York',
  },
  es: {
    name: 'Spanish',
    nativeName: 'Español',
    region: 'ES',
    locale: 'es-ES',
    ttsVoice: 'es-ES-Alvaro',
    ttsVoiceAlt: 'es-ES-Conchita',
    googleTrendsRegion: 'ES',
    newsRegion: 'es_ES',
    youtubeLanguage: 'es',
    youtubeRegion: 'ES',
    culturalNuance: 'İspanyol kültürü, tutkulu, sosyal, aile odaklı',
    viralPatterns: ['Tutku', 'Merak', 'Sosyal', 'Hüzün'],
    timeZone: 'Europe/Madrid',
  },
  de: {
    name: 'German',
    nativeName: 'Deutsch',
    region: 'DE',
    locale: 'de-DE',
    ttsVoice: 'de-DE-Stefan',
    ttsVoiceAlt: 'de-DE-Marlene',
    googleTrendsRegion: 'DE',
    newsRegion: 'de_DE',
    youtubeLanguage: 'de',
    youtubeRegion: 'DE',
    culturalNuance: 'Alman kültürü, kesinlik, teknoloji, verimlilik',
    viralPatterns: ['Teknik', 'Verimlilik', 'Güvenilirlik', 'Merak'],
    timeZone: 'Europe/Berlin',
  },
  fr: {
    name: 'French',
    nativeName: 'Français',
    region: 'FR',
    locale: 'fr-FR',
    ttsVoice: 'fr-FR-Claude',
    ttsVoiceAlt: 'fr-FR-Celine',
    googleTrendsRegion: 'FR',
    newsRegion: 'fr_FR',
    youtubeLanguage: 'fr',
    youtubeRegion: 'FR',
    culturalNuance: 'Fransız kültürü, sanat, kültür, sofistike',
    viralPatterns: ['Sanat', 'Kültür', 'Merak', 'Estetik'],
    timeZone: 'Europe/Paris',
  },
  it: {
    name: 'Italian',
    nativeName: 'Italiano',
    region: 'IT',
    locale: 'it-IT',
    ttsVoice: 'it-IT-Cosimo',
    ttsVoiceAlt: 'it-IT-Bianca',
    googleTrendsRegion: 'IT',
    newsRegion: 'it_IT',
    youtubeLanguage: 'it',
    youtubeRegion: 'IT',
    culturalNuance: 'İtalyan kültürü, tutkulu, aile, yemek, sanat',
    viralPatterns: ['Tutku', 'Aile', 'Sanat', 'Merak'],
    timeZone: 'Europe/Rome',
  },
  pt: {
    name: 'Portuguese',
    nativeName: 'Português',
    region: 'BR',
    locale: 'pt-BR',
    ttsVoice: 'pt-BR-Ricardo',
    ttsVoiceAlt: 'pt-BR-Vitoria',
    googleTrendsRegion: 'BR',
    newsRegion: 'pt_BR',
    youtubeLanguage: 'pt',
    youtubeRegion: 'BR',
    culturalNuance: 'Brezilyalı kültürü, sosyal, neşeli, müzik, dans',
    viralPatterns: ['Neşe', 'Sosyal', 'Müzik', 'Merak'],
    timeZone: 'America/Sao_Paulo',
  },
  ru: {
    name: 'Russian',
    nativeName: 'Русский',
    region: 'RU',
    locale: 'ru-RU',
    ttsVoice: 'ru-RU-Irina',
    ttsVoiceAlt: 'ru-RU-Pavel',
    googleTrendsRegion: 'RU',
    newsRegion: 'ru_RU',
    youtubeLanguage: 'ru',
    youtubeRegion: 'RU',
    culturalNuance: 'Rus kültürü, entelektüel, tarih, felsefe',
    viralPatterns: ['Entelektüellik', 'Tarih', 'Merak', 'Derinlik'],
    timeZone: 'Europe/Moscow',
  },
};

// ─── Dil Seçimi ve Doğrulama ───────────────────────────────────────────────
export function validateLanguage(languageCode) {
  if (!SUPPORTED_LANGUAGES[languageCode]) {
    return {
      valid: false,
      error: `Dil "${languageCode}" desteklenmiyor.`,
      supportedLanguages: Object.keys(SUPPORTED_LANGUAGES),
    };
  }

  return {
    valid: true,
    language: SUPPORTED_LANGUAGES[languageCode],
  };
}

// ─── Dil Bilgilerini Getir ────────────────────────────────────────────────
export function getLanguageConfig(languageCode) {
  return SUPPORTED_LANGUAGES[languageCode] || SUPPORTED_LANGUAGES.en;
}

// ─── TTS Ses Seçimi ───────────────────────────────────────────────────────
export function selectTTSVoice(languageCode, preference = 'primary') {
  const config = getLanguageConfig(languageCode);
  
  return {
    language: config.name,
    primaryVoice: config.ttsVoice,
    alternativeVoice: config.ttsVoiceAlt,
    selectedVoice: preference === 'primary' ? config.ttsVoice : config.ttsVoiceAlt,
    locale: config.locale,
  };
}

// ─── Kültürel Adaptasyon Parametreleri ────────────────────────────────────
export function getCulturalAdaptationParams(languageCode) {
  const config = getLanguageConfig(languageCode);

  return {
    language: config.name,
    culturalContext: config.culturalNuance,
    viralPatterns: config.viralPatterns,
    adaptationPrompt: `Bu içeriği ${config.name} kültürüne ve ${config.culturalNuance} değerlerine uyarla. Viral kalıpları: ${config.viralPatterns.join(', ')}. İçeriği bu kültürün izleyicisine en etkili şekilde sunacak deyimler ve referanslar kullan.`,
  };
}

// ─── Bölgesel Trend Takibi Parametreleri ──────────────────────────────────
export function getRegionalTrendParams(languageCode) {
  const config = getLanguageConfig(languageCode);

  return {
    language: config.name,
    googleTrendsRegion: config.googleTrendsRegion,
    newsRegion: config.newsRegion,
    youtubeLanguage: config.youtubeLanguage,
    youtubeRegion: config.youtubeRegion,
    timeZone: config.timeZone,
    trendSearchQuery: `Trends in ${config.region}`,
  };
}

// ─── Dil Bazlı Kanal Mimarı Parametreleri ────────────────────────────────
export function getLanguageSpecificChannelArchitect(languageCode, category) {
  const config = getLanguageConfig(languageCode);

  const templates = {
    en: {
      psychology: {
        description: `Dive into the depths of human behavior. Psychology, manipulation, behavioral analysis, and mental health insights. Every video brings a new perspective, every perspective reveals a new discovery.`,
        keywords: ['psychology', 'behavior', 'mind', 'human', 'thought', 'manipulation', 'analysis', 'science', 'behavioral', 'cognitive', 'emotion', 'social', 'personality', 'development', 'health'],
      },
      motivation: {
        description: `Inspire yourself on the path to success. Motivation, personal development, leadership, and life lessons. Every day a new story, every story a new lesson. I invite you to become your best version.`,
        keywords: ['motivation', 'success', 'goals', 'inspiration', 'development', 'leadership', 'personal', 'life', 'lessons', 'story', 'transformation', 'capacity', 'potential', 'discipline', 'dreams'],
      },
    },
    tr: {
      psychology: {
        description: `İnsan davranışının derinliklerine inin. Psikoloji, manipülasyon, davranış analizi ve zihinsel sağlık hakkında ilginç bilgiler. Her videoda yeni bir perspektif, her perspektifde yeni bir keşif.`,
        keywords: ['psikoloji', 'davranış', 'zihin', 'insan', 'düşünce', 'manipülasyon', 'analiz', 'bilim', 'davranış bilimi', 'kognitif', 'emosyon', 'sosyal', 'kişilik', 'gelişim', 'sağlık'],
      },
      motivation: {
        description: `Başarı yolunda seni ilham ver. Motivasyon, kişisel gelişim, liderlik ve hayat dersleri. Her gün yeni bir hikaye, her hikayede yeni bir ders. Seni en iyi versiyonun olmaya davet ediyorum.`,
        keywords: ['motivasyon', 'başarı', 'hedef', 'ilham', 'gelişim', 'liderlik', 'kişisel', 'hayat', 'dersi', 'hikaye', 'dönüşüm', 'kapasite', 'potansiyel', 'disiplin', 'hayal'],
      },
    },
    es: {
      psychology: {
        description: `Sumérgete en las profundidades del comportamiento humano. Psicología, manipulación, análisis del comportamiento y salud mental. Cada video trae una nueva perspectiva, cada perspectiva revela un nuevo descubrimiento.`,
        keywords: ['psicología', 'comportamiento', 'mente', 'humano', 'pensamiento', 'manipulación', 'análisis', 'ciencia', 'cognitivo', 'emoción', 'social', 'personalidad', 'desarrollo', 'salud'],
      },
      motivation: {
        description: `Inspírate en el camino hacia el éxito. Motivación, desarrollo personal, liderazgo y lecciones de vida. Cada día una nueva historia, cada historia una nueva lección. Te invito a ser tu mejor versión.`,
        keywords: ['motivación', 'éxito', 'objetivos', 'inspiración', 'desarrollo', 'liderazgo', 'personal', 'vida', 'lecciones', 'historia', 'transformación', 'potencial', 'disciplina', 'sueños'],
      },
    },
  };

  const langTemplates = templates[languageCode] || templates.en;
  return langTemplates[category] || { description: '', keywords: [] };
}

// ─── Dil Bazlı Seslendirme Komutları ──────────────────────────────────────
export function generateTTSInstructions(languageCode, text, voicePreference = 'primary') {
  const config = getLanguageConfig(languageCode);
  const voice = selectTTSVoice(languageCode, voicePreference);

  return {
    language: config.name,
    text,
    voice: voice.selectedVoice,
    locale: config.locale,
    rate: config.name === 'English' ? 1.0 : 0.95, // Dile göre hız ayarı
    pitch: 1.0,
    instructions: `${config.name} dilinde, "${voice.selectedVoice}" sesiyle seslendirme yap. Doğal ve profesyonel bir ton kullan.`,
  };
}

// ─── Çoklu Dil Kanal Özeti ────────────────────────────────────────────────
export function generateMultiLanguageChannelSummary(channels) {
  const summary = {
    timestamp: new Date().toISOString(),
    totalChannels: channels.length,
    byLanguage: {},
    channels: [],
  };

  for (const channel of channels) {
    const config = getLanguageConfig(channel.language);
    
    if (!summary.byLanguage[config.name]) {
      summary.byLanguage[config.name] = 0;
    }
    summary.byLanguage[config.name]++;

    summary.channels.push({
      channelName: channel.name,
      language: config.name,
      region: config.region,
      category: channel.category,
      ttsVoice: config.ttsVoice,
      timeZone: config.timeZone,
    });
  }

  return summary;
}

// ─── Dil Desteği Kontrol Listesi ──────────────────────────────────────────
export function getLanguageSupportChecklist() {
  return {
    supportedLanguages: Object.keys(SUPPORTED_LANGUAGES).length,
    languages: Object.entries(SUPPORTED_LANGUAGES).map(([code, config]) => ({
      code,
      name: config.name,
      nativeName: config.nativeName,
      region: config.region,
      ttsVoice: config.ttsVoice,
    })),
    features: [
      '✓ Çoklu dil desteği',
      '✓ Bölgesel trend takibi',
      '✓ Yerelleştirilmiş seslendirme (TTS)',
      '✓ Kültürel adaptasyon',
      '✓ Dil bazlı kanal mimarı',
      '✓ Zaman dilimi yönetimi',
    ],
  };
}
