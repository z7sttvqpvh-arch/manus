import ffmpeg from 'fluent-ffmpeg';
import path from 'path';
import fs from 'fs';
import { generatePexelsUltraFFmpegFilters } from './neural-director.js';

export default class VideoProcessor {
    constructor() {
        // FFmpeg yolunu ayarla (sistemde kurulu olduğu varsayılıyor)
        // ffmpeg.setFfmpegPath("/usr/bin/ffmpeg"); 
        // ffmpeg.setFfprobePath("/usr/bin/ffprobe");
    }

    async processPexelsVideo(inputVideoPath, outputVideoPath, effectsConfig, videoDuration) {
        return new Promise((resolve, reject) => {
            let command = ffmpeg(inputVideoPath);

            // Neural Director'dan gelen FFmpeg filtrelerini oluştur
            const ffmpegFilters = generatePexelsUltraFFmpegFilters(effectsConfig, videoDuration);

            if (ffmpegFilters) {
                command = command.videoFilters(ffmpegFilters);
            }

            command
                .output(outputVideoPath)
                .on("end", () => {
                    console.log("Video processing finished.");
                    resolve(outputVideoPath);
                })
                .on("error", (err) => {
                    console.error("Error processing video:", err);
                    reject(err);
                })
                .run();
        });
    }
}
