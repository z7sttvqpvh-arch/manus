# Gemini Executive Shorts OS v8.6 — Kurulum Rehberi

> Kendi sunucunuza kurulum yaparak, YouTube Shorts otomasyonunuzu tamamen kontrol altında tutun.

---

## 📋 Gereksinimler

- **Node.js 20+** (zorunlu)
- **FFmpeg** (video render için, önerilen)
- **Gemini API Key** (Google AI Studio'dan ücretsiz alınabilir)
- **edge-tts** (TTS ses üretimi için, opsiyonel)

---

## 🚀 Hızlı Kurulum (Linux/macOS)

### 1. Dosyaları İndir ve Aç

```bash
# ZIP dosyasını aç
unzip gemini-shorts-os-v8.6.zip
cd gemini_shorts_pro
```

### 2. Bağımlılıkları Yükle

```bash
# Node.js bağımlılıkları
npm install
# veya pnpm kullanıyorsanız
pnpm install
```

### 3. FFmpeg Yükle (Önerilen)

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install -y ffmpeg
```

**macOS:**
```bash
brew install ffmpeg
```

**Windows (Chocolatey):**
```bash
choco install ffmpeg
```

### 4. TTS Yükle (Opsiyonel)

```bash
pip install edge-tts
```

### 5. Sunucuyu Başlat

```bash
# Basit başlatma
npm start

# veya geliştirme modu (auto-reload)
npm run dev

# veya doğrudan
node server.js
```

**Başarılı başlatma mesajı:**
```
🚀 Gemini Executive Shorts OS v3.0 — http://127.0.0.1:3001
AI Service: GEMINI | Video Review: ✓ | Auto Repair: ✓
Kapalı Döngü Kalite Kontrol: Aktif
```

### 6. Dashboard'a Erişin

Tarayıcınızda açın: **http://localhost:3001**

---

## ⚙️ Yapılandırma

### config.json

Proje kökündeki `config.json` dosyasını düzenleyerek ayarları yapabilirsiniz:

```json
{
  "port": 3001,
  "model": "gemini-2.0-flash",
  "autoMode": false,
  "autoIntervalMinutes": 180,
  "maxCandidates": 5,
  "maxRepairRounds": 3,
  "publishThreshold": 78,
  "targetVideoSeconds": 30,
  "uploadEnabled": false,
  "maxDailyPerChannel": 2,
  "minUploadIntervalMinutes": 120,
  "ttsEnabled": false,
  "ttsVoice": "tr-TR-EmelNeural",
  "watermark": "",
  "defaultPrivacy": "public",
  "notifyWebhook": "",
  "maxJobHistory": 100,
  "concurrentJobs": false,
  "videoReviewEnabled": true,
  "autoRepairEnabled": true,
  "dynamicZoomPan": true,
  "cinematicColorGrading": true,
  "smartMirroring": true,
  "speedRamping": true,
  "aiTextureOverlay": true
}
```

---

## 🔑 Gemini API Key Alma

1. [Google AI Studio](https://aistudio.google.com/app/apikey) ziyaret edin
2. **Create API Key** butonuna tıklayın
3. Oluşturulan key'i kopyalayın
4. Dashboard → **Ayarlar** → API Key alanına yapıştırın

---

## 📊 Dashboard Kullanımı

### Sekmeler

| Sekme | Açıklama |
|-------|----------|
| **Dashboard** | İstatistikler, sistem durumu ve skor grafiği |
| **İşler** | Üretilen videoların listesi ve detayları |
| **Kanallar** | YouTube kanallarınızı yönetin |
| **Ayarlar** | Video işleme, Pexels Ultra-Customizer ve sistem ayarları |
| **Loglar** | Canlı sistem logları |

### Hızlı İşlemler

- **Yeni İş Başlat** — Seçili kanal için video üretimini başlatır
- **Tümünü Durdur** — Tüm çalışan işleri duraklatır
- **Yenile** — Durumu günceller

---

## 🎬 Pexels Ultra-Customizer Özellikleri

Ayarlar sekmesinde aşağıdaki efektleri açıp kapatabilirsiniz:

- **Dinamik Zoom & Pan** — Videodaki odak noktalarını takip eder
- **Sinematik Renk** — Duyguya göre renk paletleri uygular
- **Akıllı Aynalama** — Videoları rastgele aynalamaktadır
- **Hız Rampası** — Hızı saniye saniye değiştirir
- **AI Doku Katmanı** — Film greni ve ışık efektleri ekler

---

## 🌐 Üretim Ortamında Çalıştırma (PM2)

Sunucunuzda kesintisiz çalıştırma için PM2 kullanın:

```bash
# PM2 yükle
npm install -g pm2

# Başlat
npm run pm2

# Durumu kontrol et
pm2 status

# Logları göster
npm run pm2-log

# Durdur
npm run pm2-stop
```

---

## 🔒 Güvenlik Önerileri

1. **Firewall Ayarı** — 3001 portunu sadece güvenilir IP'lerden erişime açın
2. **HTTPS** — Nginx/Apache ile SSL sertifikası ekleyin
3. **Reverse Proxy** — Nginx/Apache ile ön proxy kurulumu yapın
4. **API Key Yönetimi** — Hassas key'leri `.env` dosyasında saklayın
5. **Düzenli Yedekle** — `data/db.json` ve `storage/` klasörünü yedekleyin

---

## 📁 Dizin Yapısı

```
gemini_shorts_pro/
├── server.js                 # Ana sunucu
├── package.json              # Bağımlılıklar
├── config.json               # Yapılandırma
├── start.sh                  # Başlatma scripti
├── README.md                 # Proje README
├── INSTALLATION.md           # Bu dosya
├── public/
│   └── index.html            # Dashboard (v8.6 Mobile Commander)
├── data/
│   └── db.json               # Veritabanı (JSON)
├── storage/
│   ├── outputs/              # Üretilen videolar
│   ├── backgrounds/          # Arka plan videoları
│   ├── audio/                # TTS ses dosyaları
│   ├── music/                # Müzik dosyaları
│   └── temp/                 # Geçici dosyalar
├── logs/
│   └── server.log            # Uygulama logları
└── [Modüller]
    ├── neural-director.js    # Video kurgu ve efekt yönetimi
    ├── video-processor.js    # FFmpeg video işleme
    ├── music-engine.js       # Müzik seçimi ve ducking
    ├── video-review.js       # Gemini video inceleme
    ├── video-repair.js       # Video onarım motoru
    └── [Diğer modüller...]
```

---

## 🐛 Sorun Giderme

### Hata: "Node.js 20+ gerekli"

```bash
# Node.js sürümünü kontrol edin
node --version

# Yükseltme (Ubuntu/Debian)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### Hata: "FFmpeg bulunamadı"

```bash
# Ubuntu/Debian
sudo apt install -y ffmpeg

# macOS
brew install ffmpeg

# Windows
choco install ffmpeg
```

### Port 3001 zaten kullanılıyor

```bash
# Port numarasını değiştir
# config.json dosyasında "port" değerini değiştir
# veya başka bir port kullan
PORT=3002 npm start
```

### Gemini API hatası

1. API Key'in doğru olduğunu kontrol edin
2. [Google AI Studio](https://aistudio.google.com) ziyaret edin
3. Yeni bir key oluşturun ve deneyin

---

## 📞 Destek

- **Hata Raporu** — `logs/server.log` dosyasını kontrol edin
- **Dashboard Logları** — Dashboard'daki "Loglar" sekmesini açın
- **API Sağlık Kontrolü** — `http://localhost:3001/api/health` ziyaret edin

---

## 📝 Lisans

MIT License — Özgürce kullanın, değiştirin ve dağıtın.

---

**Başarılı kurulumlar! 🚀**
