# Gemini Executive Shorts OS — Pro Edition v2.0

> Gemini AI ile otomatik Türkçe YouTube Shorts içeriği üreten, değerlendiren ve yayınlayan tam kapsamlı otomasyon sistemi.

---

## Özellikler

### Çekirdek Motor
- **Çoklu Gemini API Key** — Round-robin yük dengeleme, otomatik failover, sağlık takibi
- **Gelişmiş İçerik Puanlama** — Hook gücü, netlik, özgünlük, insan benzeri dil, thumbnail merak skoru
- **Onarım Döngüsü** — Düşük puanlı adayları otomatik iyileştirir (yapılandırılabilir tur sayısı)
- **Makine Öğrenmesi** — Başarılı/başarısız kalıpları öğrenir, konu tekrarını önler
- **Fallback Sistemi** — API key yoksa veya hata durumunda hazır içerik şablonları kullanır

### Video Üretimi
- **FFmpeg Entegrasyonu** — Profesyonel 1080x1920 Shorts formatı
- **Arka Plan Video Desteği** — `storage/backgrounds/` klasörüne MP4 ekleyebilirsiniz
- **TTS (Text-to-Speech)** — `edge-tts` ile Türkçe sesli anlatım (opsiyonel)
- **Watermark** — Ayarlardan kanal adı/logo metni eklenebilir
- **Gradient Tasarım** — Arka plan video yoksa profesyonel mavi gradient şablon

### YouTube Entegrasyonu
- **OAuth2 Otomatik Token Yenileme** — Refresh token ile kesintisiz yükleme
- **Günlük Limit Kontrolü** — Kanal başına maksimum yükleme sayısı
- **Minimum Aralık Kontrolü** — Spam önleme
- **Gizlilik Ayarı** — Public / Unlisted / Private

### Dashboard (Web Arayüzü)
- **Modern Karanlık Tema** — Profesyonel UI tasarımı
- **Gerçek Zamanlı SSE Logları** — Canlı log akışı
- **İstatistik Paneli** — Toplam iş, başarı oranı, upload sayısı
- **Performans Grafiği** — Retention skoru trendi
- **Key Sağlık Takibi** — Latency, başarı/hata sayısı, cooldown durumu
- **Öğrenme Paneli** — Başarılı/başarısız kalıplar, konu geçmişi
- **İş Geçmişi** — Filtreleme, silme, video indirme

### Güvenlik & Performans
- **API Key Maskeleme** — Arayüzde key'ler gizlenir (`••••xxxx`)
- **Body Size Limiti** — 10MB istek limiti
- **Timeout Koruması** — 30 saniye API timeout
- **Dosya Kilitleme** — Eşzamanlı DB yazma koruması
- **İş Geçmişi Limiti** — Yapılandırılabilir maksimum kayıt sayısı

---

## Kurulum

### Gereksinimler
- **Node.js 20+** (zorunlu)
- **FFmpeg** (video render için, opsiyonel)
- **edge-tts** (TTS için, opsiyonel)
- **Gemini API Key** (Google AI Studio'dan ücretsiz alınabilir)

### Hızlı Başlangıç

```bash
# 1. Dizine gir
cd gemini-executive-shorts-os-pro

# 2. Başlat
./start.sh
# veya
node server.js

# 3. Paneli aç
# http://localhost:3001
```

### FFmpeg Kurulumu (Ubuntu/Debian)
```bash
sudo apt update && sudo apt install -y ffmpeg
```

### FFmpeg Kurulumu (macOS)
```bash
brew install ffmpeg
```

### TTS Kurulumu (opsiyonel)
```bash
pip install edge-tts
```

### PM2 ile Kalıcı Çalıştırma (Üretim)
```bash
npm install -g pm2
npm run pm2
pm2 save
pm2 startup
```

---

## Yapılandırma

### config.json

| Alan | Varsayılan | Açıklama |
|------|-----------|----------|
| `port` | `3001` | Sunucu portu |
| `model` | `gemini-2.0-flash` | Gemini model adı |
| `autoMode` | `false` | Otomatik üretim modu |
| `autoIntervalMinutes` | `180` | Auto mod aralığı (dakika) |
| `maxCandidates` | `5` | Üretilecek aday sayısı |
| `maxRepairRounds` | `3` | Onarım döngüsü turu |
| `publishThreshold` | `78` | Minimum yayın skoru (0-100) |
| `targetVideoSeconds` | `30` | Hedef video süresi |
| `uploadEnabled` | `false` | YouTube upload aktif/pasif |
| `maxDailyPerChannel` | `2` | Günlük maks. upload/kanal |
| `minUploadIntervalMinutes` | `120` | Minimum upload aralığı |
| `ttsEnabled` | `false` | TTS ses üretimi |
| `ttsVoice` | `tr-TR-EmelNeural` | TTS ses modeli |
| `watermark` | `""` | Video watermark metni |
| `defaultPrivacy` | `public` | Varsayılan gizlilik |
| `notifyWebhook` | `""` | Webhook bildirim URL |
| `maxJobHistory` | `100` | Maksimum iş geçmişi |
| `concurrentJobs` | `false` | Eşzamanlı çoklu iş |

---

## Kullanım

### 1. API Key Ekleme
Panel → **API Keys** → Key adı ve Gemini API key girin → **Key Ekle**

> Birden fazla key ekleyerek yük dengeleme ve otomatik failover sağlayabilirsiniz.

### 2. Kanal Ekleme
Panel → **Kanallar** → Kanal adı, kategori seçin → **Kanal Ekle**

YouTube upload için OAuth bilgilerini de doldurun (opsiyonel).

### 3. Manuel Üretim
Panel → **Üretim** → Kanal seçin → (opsiyonel konu girin) → **Üretimi Başlat**

### 4. Otomatik Mod
Panel → **Ayarlar** → **Auto Mode** açın → Aralık dakikasını ayarlayın → **Kaydet**

### 5. Arka Plan Video Ekleme
`storage/backgrounds/` klasörüne MP4 dosyaları kopyalayın. Sistem otomatik kullanır.

---

## YouTube OAuth Kurulumu

1. [Google Cloud Console](https://console.cloud.google.com) → Yeni proje oluştur
2. **APIs & Services** → **YouTube Data API v3** etkinleştir
3. **Credentials** → **OAuth 2.0 Client ID** oluştur (Desktop app)
4. Client ID ve Client Secret'ı kopyala
5. Refresh Token almak için [OAuth Playground](https://developers.google.com/oauthplayground) kullan:
   - Settings → Use your own OAuth credentials → Client ID/Secret gir
   - `https://www.googleapis.com/auth/youtube.upload` scope seç
   - Authorize → Exchange for tokens → Refresh Token kopyala
6. Panelde kanal eklerken bu bilgileri gir

---

## Desteklenen Gemini Modelleri

| Model | Hız | Kalite | Öneri |
|-------|-----|--------|-------|
| `gemini-2.0-flash` | Hızlı | Yüksek | ✅ Önerilen |
| `gemini-2.0-flash-lite` | Çok Hızlı | Orta | Yüksek hacim |
| `gemini-1.5-flash` | Hızlı | Yüksek | Alternatif |
| `gemini-1.5-pro` | Yavaş | Çok Yüksek | Kalite odaklı |
| `gemini-2.5-flash-preview-04-17` | Hızlı | En Yüksek | En yeni |

---

## Kanal Kategorileri

| Kategori | İçerik Tipi |
|----------|-------------|
| `psychology` | Psikoloji, insan davranışı |
| `shock` | Şaşırtıcı gerçekler, ilginç bilgiler |
| `motivation` | Motivasyon, kişisel gelişim |
| `knowledge` | Genel bilgi, ilginç olgular |
| `finance` | Finans, yatırım, para yönetimi |
| `health` | Sağlık, yaşam tarzı |

---

## API Endpoint'leri

| Method | Endpoint | Açıklama |
|--------|----------|----------|
| GET | `/api/health` | Sistem durumu |
| GET | `/api/state` | Tam durum (keys, channels, jobs, settings) |
| GET | `/api/logs` | Son 200 log satırı |
| GET | `/api/stats` | İstatistikler |
| GET | `/api/outputs` | Çıktı dosyaları listesi |
| GET | `/api/outputs/:file` | Dosya indir |
| GET | `/api/events` | SSE canlı log akışı |
| POST | `/api/keys` | Key ekle |
| POST | `/api/keys/:id/toggle` | Key aktif/pasif |
| POST | `/api/keys/:id/test` | Key test et |
| DELETE | `/api/keys/:id` | Key sil |
| POST | `/api/channels` | Kanal ekle |
| PUT | `/api/channels/:id` | Kanal güncelle |
| POST | `/api/channels/:id/toggle` | Kanal aktif/pasif |
| DELETE | `/api/channels/:id` | Kanal sil |
| POST | `/api/settings` | Ayarları kaydet |
| POST | `/api/run` | İş başlat |
| DELETE | `/api/jobs/:id` | İş sil |
| POST | `/api/jobs/clear` | Tamamlanan işleri temizle |
| POST | `/api/learning/reset` | Öğrenme verisini sıfırla |

---

## Dizin Yapısı

```
gemini-executive-shorts-os-pro/
├── server.js              # Ana sunucu (tüm iş mantığı)
├── config.json            # Yapılandırma
├── package.json
├── start.sh               # Başlatma scripti
├── README.md
├── public/
│   └── index.html         # Web arayüzü (dashboard)
├── data/
│   └── db.json            # Veritabanı (keys, channels, jobs, learning)
├── storage/
│   ├── outputs/           # Üretilen videolar (.mp4) ve metin çıktılar (.txt)
│   ├── backgrounds/       # Arka plan videoları (buraya MP4 ekleyin)
│   ├── audio/             # TTS ses dosyaları (geçici)
│   ├── thumbnails/        # Thumbnail'lar (gelecek özellik)
│   ├── subtitles/         # Altyazılar (gelecek özellik)
│   └── temp/              # Geçici dosyalar
└── logs/
    └── server.log         # Uygulama logları
```

---

## Sürüm Geçmişi

### v2.0.0 (Pro Edition)
- Çoklu model desteği (Gemini 2.0 Flash dahil)
- Gelişmiş içerik puanlama motoru (6 metrik)
- Makine öğrenmesi tabanlı kalıp takibi
- TTS (Text-to-Speech) entegrasyonu
- Gerçek zamanlı SSE log akışı
- Modern karanlık tema dashboard
- İstatistik ve performans grafiği
- Key test ve sağlık takibi
- Webhook bildirimleri
- Watermark desteği
- Eşzamanlı iş desteği
- Gelişmiş FFmpeg video render
- API key maskeleme (güvenlik)
- Çok daha fazla API endpoint

### v1.0.0 (Original)
- Temel içerik üretimi
- Basit puanlama
- YouTube upload
- Minimal dashboard
