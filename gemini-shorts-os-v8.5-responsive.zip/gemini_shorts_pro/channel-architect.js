/**
 * Channel Architect — Kanal Mimarı
 * ================================
 * Kategori bazlı kanal yapılandırması, SEO optimizasyonu ve görsel kimlik rehberi
 */

// ─── Kategori Bazlı Kanal Ayarları ─────────────────────────────────────────
const CHANNEL_TEMPLATES = {
  psychology: {
    name: 'Psikoloji',
    youtubeCategory: 'Education',
    description: `Insan davranışının derinliklerine inin. Psikoloji, manipülasyon, davranış analizi ve zihinsel sağlık hakkında ilginç bilgiler. Her videoda yeni bir perspektif, her perspektifde yeni bir keşif.`,
    keywords: ['psikoloji', 'davranış', 'zihin', 'insan', 'düşünce', 'manipülasyon', 'analiz', 'bilim', 'davranış bilimi', 'kognitif', 'emosyon', 'sosyal', 'kişilik', 'gelişim', 'sağlık'],
    tags: ['#psikoloji', '#davranış', '#zihin', '#insan', '#bilim', '#manipülasyon', '#analiz', '#gelişim'],
    brandingPrompt: 'Minimalist, koyu renkli, gizemli ve entelektüel bir psikoloji kanalı logosunu tasarla. Beyin, soru işareti ve soyut geometrik şekilleri içer. Renkler: koyu mavi, siyah ve gümüş.',
    communityGuidelines: ['şiddet', 'nefret', 'uyuşturuç', 'cinsel içerik', 'spam', 'yanıltıcı bilgi'],
  },
  motivation: {
    name: 'Motivasyon',
    youtubeCategory: 'People & Blogs',
    description: `Başarı yolunda seni ilham ver. Motivasyon, kişisel gelişim, liderlik ve hayat dersleri. Her gün yeni bir hikaye, her hikayede yeni bir ders. Seni en iyi versiyonun olmaya davet ediyorum.`,
    keywords: ['motivasyon', 'başarı', 'hedef', 'ilham', 'gelişim', 'liderlik', 'kişisel', 'hayat', 'dersi', 'hikaye', 'dönüşüm', 'kapasite', 'potansiyel', 'disiplin', 'hayal'],
    tags: ['#motivasyon', '#başarı', '#hedef', '#ilham', '#gelişim', '#liderlik', '#hayat', '#dönüşüm'],
    brandingPrompt: 'Dinamik, enerjik ve ilham verici bir motivasyon kanalı logosunu tasarla. Yükselen grafik, ışık, ok ve insan figürü içer. Renkler: altın, turuncu, siyah ve beyaz.',
    communityGuidelines: ['nefret', 'ayrımcılık', 'yanıltıcı bilgi', 'spam', 'şiddet'],
  },
  health: {
    name: 'Sağlık',
    youtubeCategory: 'Howto & Style',
    description: `Sağlıklı yaşamın sırları burada. Beslenme, fitness, mental sağlık ve wellness. Bilimsel temelli, pratik ve uygulanabilir tüyolar. Sağlığın en büyük yatırım olduğunu biliyoruz.`,
    keywords: ['sağlık', 'beslenme', 'fitness', 'wellness', 'yaşam', 'spor', 'egzersiz', 'diyet', 'mental', 'meditasyon', 'yoga', 'uyku', 'stres', 'bağışıklık', 'doktor'],
    tags: ['#sağlık', '#beslenme', '#fitness', '#wellness', '#yaşam', '#spor', '#egzersiz', '#mental'],
    brandingPrompt: 'Temiz, modern ve sağlıklı bir sağlık kanalı logosunu tasarla. Kalp, yaprak, dumbbells ve tıbbi semboller içer. Renkler: yeşil, beyaz, açık mavi ve gümüş.',
    communityGuidelines: ['yanlış tıbbi bilgi', 'spam', 'reklam', 'uyuşturuç', 'yanıltıcı ürün'],
  },
  knowledge: {
    name: 'Bilgi',
    youtubeCategory: 'Education',
    description: `Merak edenlerin cenneti. İlginç gerçekler, bilimsel keşifler, tarih ve teknoloji. Her videoda yeni bir bilgi, her bilgide yeni bir dünya. Öğrenmeyi asla bırakma.`,
    keywords: ['bilgi', 'eğitim', 'öğrenme', 'merak', 'keşif', 'bilim', 'tarih', 'teknoloji', 'gerçek', 'araştırma', 'belgesel', 'deney', 'teori', 'kanıt', 'analiz'],
    tags: ['#bilgi', '#eğitim', '#öğrenme', '#merak', '#keşif', '#bilim', '#tarih', '#teknoloji'],
    brandingPrompt: 'Akademik, meraklı ve keşif odaklı bir bilgi kanalı logosunu tasarla. Kitap, ampul, teleskop ve soru işareti içer. Renkler: lacivert, altın, beyaz ve gri.',
    communityGuidelines: ['yanıltıcı bilgi', 'hoax', 'komplo teorileri', 'spam', 'nefret'],
  },
  finance: {
    name: 'Finans',
    youtubeCategory: 'Howto & Style',
    description: `Finansal özgürlüğe giden yol. Para yönetimi, yatırım, kripto, borsa ve iş. Bilimsel ve pratik rehberlik. Zenginlik sadece şans değil, bilgi ve disiplinin sonucu.`,
    keywords: ['finans', 'para', 'yatırım', 'borsa', 'kripto', 'iş', 'girişim', 'bütçe', 'tasarruf', 'gelir', 'pasif', 'portföy', 'risk', 'strateji', 'ekonomi'],
    tags: ['#finans', '#para', '#yatırım', '#borsa', '#kripto', '#iş', '#girişim', '#bütçe'],
    brandingPrompt: 'Profesyonel, güvenilir ve başarılı bir finans kanalı logosunu tasarla. Para, grafik, ok ve güvenlik sembolü içer. Renkler: koyu yeşil, altın, beyaz ve gri.',
    communityGuidelines: ['yanlış finansal tavsiye', 'dolandırıcılık', 'spam', 'reklam', 'pump & dump'],
  },
};

// ─── Kanal Açıklaması Oluştur ──────────────────────────────────────────────
export function generateChannelDescription(category, channelName) {
  const template = CHANNEL_TEMPLATES[category];
  if (!template) return null;

  return {
    channelName,
    category: template.name,
    description: template.description,
    youtubeCategory: template.youtubeCategory,
    recommendation: `✓ Bu açıklama ${template.name} kategorisi için SEO uyumlu ve izleyici çekici olarak tasarlandı.`,
  };
}

// ─── Kanal Anahtar Kelimeleri Oluştur ──────────────────────────────────────
export function generateChannelKeywords(category) {
  const template = CHANNEL_TEMPLATES[category];
  if (!template) return null;

  return {
    category: template.name,
    keywords: template.keywords,
    tags: template.tags,
    recommendation: `✓ Bu ${template.keywords.length} anahtar kelime ve ${template.tags.length} etiket, YouTube algoritmasının kanalınızı doğru sınıfa yerleştirmesine yardımcı olacak.`,
  };
}

// ─── Görsel Kimlik Rehberi (Branding Guide) ────────────────────────────────
export function generateBrandingGuide(category, channelName) {
  const template = CHANNEL_TEMPLATES[category];
  if (!template) return null;

  return {
    channelName,
    category: template.name,
    profilePicturePrompt: template.brandingPrompt,
    bannerPrompt: `${channelName} kanalı için geniş bir YouTube banner tasarla. ${template.brandingPrompt} Banner 2560x1440 piksel olmalı.`,
    watermarkPrompt: `${channelName} kanalı için sağ alt köşeye yerleştirilecek "Abone Ol" butonu tasarla. Şeffaf arka plan, beyaz ve renkli (${template.name} kategorisine uygun) tasarım.`,
    colorScheme: {
      primary: template.name === 'Psikoloji' ? '#1a1a2e' : 
               template.name === 'Motivasyon' ? '#ff6b35' : 
               template.name === 'Sağlık' ? '#2ecc71' : 
               template.name === 'Bilgi' ? '#3498db' : '#27ae60',
      secondary: template.name === 'Psikoloji' ? '#16213e' : 
                 template.name === 'Motivasyon' ? '#ffa500' : 
                 template.name === 'Sağlık' ? '#27ae60' : 
                 template.name === 'Bilgi' ? '#2980b9' : '#229954',
    },
    recommendation: `✓ Bu görseller ${template.name} kategorisinin profesyonel ve çekici görünümünü yansıtacak.`,
  };
}

// ─── Yükleme Varsayılanları (Upload Defaults) ──────────────────────────────
export function generateUploadDefaults(category, channelName) {
  const template = CHANNEL_TEMPLATES[category];
  if (!template) return null;

  const defaultDescription = `${channelName} - ${template.name} Kanalı

Videodaki konular hakkında daha fazla bilgi için:
📌 Kanalımıza abone olun: https://youtube.com/@${channelName.replace(/\s+/g, '')}
📌 Diğer videolarımız: [Playlist Linki]
📌 Sosyal Medya: [Instagram/Twitter]

${template.keywords.slice(0, 5).join(', ')}

Teşekkürler!`;

  return {
    category: template.name,
    defaultDescription,
    defaultLanguage: 'tr',
    defaultComments: 'ALLOW',
    defaultLicense: 'STANDARD_YOUTUBE_LICENSE',
    defaultCategory: template.youtubeCategory,
    tags: template.tags,
    recommendation: `✓ Bu varsayılanlar her video yüklediğinizde otomatik olarak uygulanacak.`,
  };
}

// ─── Topluluk Ayarları (Community Guidelines) ──────────────────────────────
export function generateCommunitySettings(category) {
  const template = CHANNEL_TEMPLATES[category];
  if (!template) return null;

  return {
    category: template.name,
    blockedWords: template.communityGuidelines,
    autoModeration: true,
    commentApprovalRequired: false,
    recommendation: `✓ Bu ${template.communityGuidelines.length} kelime otomatik olarak engellenenler listesine eklenecek.`,
  };
}

// ─── Tam Kanal Kurulum Paketi (Complete Channel Setup Kit) ──────────────────
export function generateCompleteChannelSetupKit(category, channelName) {
  const description = generateChannelDescription(category, channelName);
  const keywords = generateChannelKeywords(category);
  const branding = generateBrandingGuide(category, channelName);
  const uploadDefaults = generateUploadDefaults(category, channelName);
  const community = generateCommunitySettings(category);

  return {
    timestamp: new Date().toISOString(),
    channelName,
    category: CHANNEL_TEMPLATES[category]?.name || 'Bilinmiyor',
    setupKit: {
      description,
      keywords,
      branding,
      uploadDefaults,
      community,
    },
    instructions: [
      '1. YouTube Studio\'ya gidin → Ayarlar → Kanal Bilgileri',
      '2. "Kanal Açıklaması" alanına yukarıdaki metni yapıştırın',
      '3. "Kanal Anahtar Kelimeleri" alanına keywords listesini yapıştırın',
      '4. Profil Resmi ve Banner için branding promptlarını kullanarak görseller oluşturun',
      '5. Varsayılan yükleme ayarlarını ayarlayın',
      '6. Topluluk ayarlarında engellenen kelimeleri ekleyin',
    ],
    estimatedSetupTime: '15-20 dakika',
    recommendation: '✓ Bu paket tamamlandığında kanalınız profesyonel ve SEO uyumlu olacaktır.',
  };
}

// ─── Kanal Sağlık Kontrolü (Channel Health Check) ────────────────────────────
export function performChannelHealthCheck(channelData) {
  const checks = {
    descriptionComplete: channelData.description && channelData.description.length > 100,
    keywordsAdded: channelData.keywords && channelData.keywords.length > 5,
    profilePictureSet: !!channelData.profilePictureUrl,
    bannerSet: !!channelData.bannerUrl,
    categorySelected: !!channelData.youtubeCategory,
    customUrlSet: !!channelData.customUrl,
  };

  const completedChecks = Object.values(checks).filter(Boolean).length;
  const totalChecks = Object.keys(checks).length;
  const healthScore = Math.round((completedChecks / totalChecks) * 100);

  return {
    channelName: channelData.channelName,
    healthScore,
    checks,
    completedChecks,
    totalChecks,
    status: healthScore < 50 ? 'POOR' : healthScore < 75 ? 'FAIR' : 'EXCELLENT',
    recommendation: healthScore < 75
      ? `⚠️ Kanal kurulumu tamamlanmadı. Eksik ayarlar: ${Object.entries(checks).filter(([, v]) => !v).map(([k]) => k).join(', ')}`
      : `✓ Kanal kurulumu tamamlandı ve profesyonel görünüyor!`,
  };
}

// ─── Kategori Değişim Rehberi (Category Migration Guide) ──────────────────
export function generateCategoryMigrationGuide(oldCategory, newCategory) {
  const oldTemplate = CHANNEL_TEMPLATES[oldCategory];
  const newTemplate = CHANNEL_TEMPLATES[newCategory];

  if (!oldTemplate || !newTemplate) return null;

  return {
    oldCategory: oldTemplate.name,
    newCategory: newTemplate.name,
    warning: `⚠️ Kategori değişimi kanalın performansını etkileyebilir. Lütfen dikkatli olun.`,
    changes: {
      description: `"${oldTemplate.description.substring(0, 50)}..." → "${newTemplate.description.substring(0, 50)}..."`,
      keywords: `${oldTemplate.keywords.length} anahtar kelime → ${newTemplate.keywords.length} anahtar kelime`,
      branding: `${oldTemplate.name} stili → ${newTemplate.name} stili`,
    },
    recommendation: `Kategoriyi değiştirmek istiyorsanız, yeni kurulum paketini oluşturun ve YouTube Studio'dan manuel olarak güncelleyin.`,
  };
}
