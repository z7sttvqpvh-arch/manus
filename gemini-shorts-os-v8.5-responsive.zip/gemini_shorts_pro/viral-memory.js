/**
 * Viral Memory — Viral Zeka Hafızası
 * ===================================
 * Sistemin geçmiş başarılarından öğrenerek viral stratejisini dinamik olarak güncellemesi
 * - Başarılı hook türlerinin kaydı
 * - Optimal yayın saatleri
 * - Müzik-kategori eşleştirme başarı oranları
 * - İzleyici tutma (retention) analizi
 */

import fsp from 'fs/promises';
import path from 'path';

// ─── Viral Memory Şeması ────────────────────────────────────────────────────
/**
 * viral_memory.json yapısı:
 * {
 *   "hookStrategies": {
 *     "question": { successCount: 45, avgScore: 87, examples: [...] },
 *     "shock": { successCount: 32, avgScore: 82, examples: [...] },
 *     "mystery": { successCount: 28, avgScore: 79, examples: [...] }
 *   },
 *   "publishingTimes": {
 *     "08:00": { views: 5000, engagement: 0.12 },
 *     "20:00": { views: 8500, engagement: 0.18 }
 *   },
 *   "musicCategoryMatch": {
 *     "motivation-energetic": { successCount: 23, avgRetention: 0.85 },
 *     "psychology-ambient": { successCount: 19, avgRetention: 0.78 }
 *   },
 *   "topicPerformance": {
 *     "psikoloji-manipülasyon": { views: 12000, retention: 0.82 },
 *     "motivasyon-disiplin": { views: 8000, retention: 0.75 }
 *   },
 *   "scrollStopPatterns": [
 *     { pattern: "soru-cevap", successRate: 0.88 },
 *     { pattern: "şaşırtma-açıklama", successRate: 0.82 }
 *   ],
 *   "lastUpdated": "2026-04-07T19:54:00Z",
 *   "totalAnalyzed": 156
 * }
 */

const DEFAULT_MEMORY = {
  hookStrategies: {
    question: { successCount: 0, avgScore: 0, examples: [] },
    shock: { successCount: 0, avgScore: 0, examples: [] },
    mystery: { successCount: 0, avgScore: 0, examples: [] },
    direct: { successCount: 0, avgScore: 0, examples: [] },
    visual: { successCount: 0, avgScore: 0, examples: [] },
  },
  publishingTimes: {},
  musicCategoryMatch: {},
  topicPerformance: {},
  scrollStopPatterns: [
    { pattern: 'soru-cevap', successRate: 0.80 },
    { pattern: 'şaşırtma-açıklama', successRate: 0.75 },
    { pattern: 'gizem-çözüm', successRate: 0.78 },
    { pattern: 'doğrudan-kanıt', successRate: 0.72 },
    { pattern: 'görsel-metin', successRate: 0.76 },
  ],
  lastUpdated: new Date().toISOString(),
  totalAnalyzed: 0,
};

// ─── Viral Memory Yükle ──────────────────────────────────────────────────────
export async function loadViralMemory(dataDir) {
  const memoryPath = path.join(dataDir, 'viral_memory.json');
  
  try {
    const content = await fsp.readFile(memoryPath, 'utf8');
    return JSON.parse(content);
  } catch (e) {
    console.log('📝 Yeni Viral Memory oluşturuluyor...');
    await saveViralMemory(DEFAULT_MEMORY, dataDir);
    return DEFAULT_MEMORY;
  }
}

// ─── Viral Memory Kaydet ────────────────────────────────────────────────────
export async function saveViralMemory(memory, dataDir) {
  const memoryPath = path.join(dataDir, 'viral_memory.json');
  memory.lastUpdated = new Date().toISOString();
  
  try {
    await fsp.writeFile(memoryPath, JSON.stringify(memory, null, 2));
  } catch (e) {
    console.error('Viral Memory kayıt hatası:', e.message);
  }
}

// ─── Hook Stratejisini Kaydet ───────────────────────────────────────────────
export function recordHookSuccess(memory, hookType, scrollStopScore) {
  if (!memory.hookStrategies[hookType]) {
    memory.hookStrategies[hookType] = { successCount: 0, avgScore: 0, examples: [] };
  }

  const strategy = memory.hookStrategies[hookType];
  const oldAvg = strategy.avgScore;
  const oldCount = strategy.successCount;

  strategy.successCount += 1;
  strategy.avgScore = (oldAvg * oldCount + scrollStopScore) / (oldCount + 1);

  // Son 10 başarılı örneği tut
  if (strategy.examples.length >= 10) {
    strategy.examples.shift();
  }
  strategy.examples.push({
    score: scrollStopScore,
    timestamp: new Date().toISOString(),
  });

  memory.totalAnalyzed = (memory.totalAnalyzed || 0) + 1;
  return memory;
}

// ─── En İyi Hook Stratejisini Bul ───────────────────────────────────────────
export function getBestHookStrategy(memory) {
  let best = null;
  let bestScore = 0;

  for (const [hookType, data] of Object.entries(memory.hookStrategies)) {
    if (data.successCount > 0 && data.avgScore > bestScore) {
      best = hookType;
      bestScore = data.avgScore;
    }
  }

  return { hookType: best || 'question', avgScore: bestScore || 75 };
}

// ─── Yayın Saati Analizi ────────────────────────────────────────────────────
export function recordPublishingTime(memory, hour, views, engagement) {
  const timeKey = `${String(hour).padStart(2, '0')}:00`;
  
  if (!memory.publishingTimes[timeKey]) {
    memory.publishingTimes[timeKey] = { views: 0, engagement: 0, count: 0 };
  }

  const time = memory.publishingTimes[timeKey];
  time.views = (time.views + views) / 2;
  time.engagement = (time.engagement + engagement) / 2;
  time.count += 1;

  return memory;
}

// ─── Optimal Yayın Saatini Bul ──────────────────────────────────────────────
export function getOptimalPublishingTime(memory) {
  let best = null;
  let bestScore = 0;

  for (const [time, data] of Object.entries(memory.publishingTimes)) {
    const score = data.views * 0.6 + (data.engagement * 1000) * 0.4;
    if (score > bestScore) {
      best = time;
      bestScore = score;
    }
  }

  return best || '20:00'; // Varsayılan olarak akşam 8'i döndür
}

// ─── Müzik-Kategori Eşleştirmesini Kaydet ───────────────────────────────────
export function recordMusicCategoryMatch(memory, category, musicStyle, retentionScore) {
  const key = `${category}-${musicStyle}`;
  
  if (!memory.musicCategoryMatch[key]) {
    memory.musicCategoryMatch[key] = { successCount: 0, avgRetention: 0 };
  }

  const match = memory.musicCategoryMatch[key];
  const oldAvg = match.avgRetention;
  const oldCount = match.successCount;

  match.successCount += 1;
  match.avgRetention = (oldAvg * oldCount + retentionScore) / (oldCount + 1);

  return memory;
}

// ─── Konu Performansını Kaydet ──────────────────────────────────────────────
export function recordTopicPerformance(memory, category, topic, views, retention) {
  const key = `${category}-${topic}`;
  
  if (!memory.topicPerformance[key]) {
    memory.topicPerformance[key] = { views: 0, retention: 0, count: 0 };
  }

  const perf = memory.topicPerformance[key];
  perf.views = (perf.views + views) / 2;
  perf.retention = (perf.retention + retention) / 2;
  perf.count += 1;

  return memory;
}

// ─── En Başarılı Konuları Bul ───────────────────────────────────────────────
export function getTopPerformingTopics(memory, category, limit = 5) {
  const topics = Object.entries(memory.topicPerformance)
    .filter(([key]) => key.startsWith(category))
    .map(([key, data]) => ({
      topic: key.replace(`${category}-`, ''),
      views: data.views,
      retention: data.retention,
      score: data.views * 0.5 + (data.retention * 100) * 0.5,
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);

  return topics;
}

// ─── Scroll-Stop Deseni Analizi ─────────────────────────────────────────────
export function getBestScrollStopPattern(memory) {
  return memory.scrollStopPatterns
    .sort((a, b) => b.successRate - a.successRate)[0] || 
    { pattern: 'soru-cevap', successRate: 0.80 };
}

// ─── Viral Zeka Raporu ──────────────────────────────────────────────────────
export function generateViralIntelligenceReport(memory) {
  const bestHook = getBestHookStrategy(memory);
  const bestTime = getOptimalPublishingTime(memory);
  const bestPattern = getBestScrollStopPattern(memory);

  return {
    timestamp: new Date().toISOString(),
    totalAnalyzed: memory.totalAnalyzed,
    recommendations: {
      bestHookStrategy: {
        type: bestHook.hookType,
        avgScore: Math.round(bestHook.avgScore),
        advice: `${bestHook.hookType} tipi hook'lar ortalama ${Math.round(bestHook.avgScore)} puan alıyor. Bunu kullanmaya devam et.`,
      },
      bestPublishingTime: {
        time: bestTime,
        advice: `${bestTime} saatinde paylaşılan videolar en yüksek etkileşim alıyor.`,
      },
      bestScrollStopPattern: {
        pattern: bestPattern.pattern,
        successRate: Math.round(bestPattern.successRate * 100),
        advice: `"${bestPattern.pattern}" deseni %${Math.round(bestPattern.successRate * 100)} başarı oranına sahip.`,
      },
    },
    hookStrategies: Object.entries(memory.hookStrategies).map(([type, data]) => ({
      type,
      successCount: data.successCount,
      avgScore: Math.round(data.avgScore),
    })),
  };
}

// ─── Hafızayı Sıfırla (Test İçin) ────────────────────────────────────────────
export function resetViralMemory() {
  return JSON.parse(JSON.stringify(DEFAULT_MEMORY));
}

// ─── Hafıza İstatistikleri ──────────────────────────────────────────────────
export function getMemoryStats(memory) {
  const hookCount = Object.values(memory.hookStrategies).reduce((sum, h) => sum + h.successCount, 0);
  const topicCount = Object.keys(memory.topicPerformance).length;
  const timeCount = Object.keys(memory.publishingTimes).length;

  return {
    totalAnalyzed: memory.totalAnalyzed,
    hookStrategiesTracked: hookCount,
    topicsTracked: topicCount,
    publishingTimesTracked: timeCount,
    lastUpdated: memory.lastUpdated,
  };
}
