/**
 * Algorithm Master — YouTube Shorts 2025-2026 Algoritma Ustası
 * ==============================================================
 * YouTube'un Shorts algoritmasının gizli sosunu deşifre ederek
 * - Seed Audience (Tohum İzleyici) optimizasyonu
 * - Velocity (Hız) tetikleyicileri
 * - Rewatch Loop (Yeniden İzlenme Döngüsü) tasarımı
 * - Viewed vs Swiped analizi
 */

// ─── YouTube Shorts Algoritma Parametreleri (2025-2026) ─────────────────────
const ALGORITHM_PARAMETERS = {
  seedAudience: {
    stage1: { minViews: 100, minEngagement: 0.15 }, // İlk test: 100 kişiye göster
    stage2: { minViews: 500, minEngagement: 0.12 }, // 500 kişiye genişlet
    stage3: { minViews: 2000, minEngagement: 0.10 }, // 2000 kişiye genişlet
    stage4: { minViews: 10000, minEngagement: 0.08 }, // Viral aşamasına geç
  },
  velocityTriggers: {
    first1Hour: { viewsNeeded: 100, engagementNeeded: 0.20 }, // İlk 1 saatte
    first6Hours: { viewsNeeded: 500, engagementNeeded: 0.15 }, // İlk 6 saatte
    first24Hours: { viewsNeeded: 2000, engagementNeeded: 0.12 }, // İlk 24 saatte
  },
  rewatchMetrics: {
    minRewatchRate: 0.25, // En az %25 yeniden izlenme
    optimalLoopLength: 15, // 15 saniye ideal loop uzunluğu
    maxLoopLength: 30, // 30 saniyeden fazla loop yapma
  },
  engagementMetrics: {
    viewedVsSwiped: 0.70, // En az %70 izlenme oranı (swiped değil)
    avgWatchTime: 0.80, // Videonun %80'i izlenmeli
    clickThroughRate: 0.08, // %8 CTR hedefi
  },
};

// ─── Seed Audience Analizi ──────────────────────────────────────────────────
export function analyzeSeedAudiencePerformance(viewData) {
  const stages = [];
  let currentStage = 1;

  for (const [stageName, criteria] of Object.entries(ALGORITHM_PARAMETERS.seedAudience)) {
    const passed = viewData.views >= criteria.minViews && 
                   viewData.engagement >= criteria.minEngagement;

    stages.push({
      stage: stageName,
      number: currentStage,
      required: criteria,
      actual: {
        views: viewData.views,
        engagement: viewData.engagement,
      },
      passed,
      recommendation: passed 
        ? `✓ ${stageName} geçildi. Sonraki aşamaya ilerle.`
        : `⚠ ${stageName} geçilmedi. Etkileşim artırılmalı.`,
    });

    if (!passed) break;
    currentStage++;
  }

  return {
    currentStage: Math.min(currentStage, Object.keys(ALGORITHM_PARAMETERS.seedAudience).length),
    stages,
    viralPotential: calculateViralPotential(stages),
  };
}

// ─── Viral Potansiyel Hesapla ───────────────────────────────────────────────
function calculateViralPotential(stages) {
  const passedStages = stages.filter(s => s.passed).length;
  const totalStages = stages.length;
  const viralScore = (passedStages / totalStages) * 100;

  return {
    score: Math.round(viralScore),
    level: viralScore > 75 ? 'Very High' : viralScore > 50 ? 'High' : viralScore > 25 ? 'Medium' : 'Low',
    prediction: viralScore > 75 
      ? '🚀 Bu video viral olma potansiyeli çok yüksek!'
      : viralScore > 50
      ? '📈 Bu video viral olabilir, etkileşim artırılmalı'
      : '⚠️ Viral olma potansiyeli düşük, yeniden tasarla',
  };
}

// ─── Velocity (Hız) Tetikleyicisi ───────────────────────────────────────────
export function analyzeVelocity(viewData, hoursSincePublish) {
  const velocityMetrics = {};
  let velocityScore = 0;

  if (hoursSincePublish <= 1) {
    const trigger = ALGORITHM_PARAMETERS.velocityTriggers.first1Hour;
    const passed = viewData.views >= trigger.viewsNeeded && 
                   viewData.engagement >= trigger.engagementNeeded;
    velocityMetrics.first1Hour = {
      required: trigger,
      actual: { views: viewData.views, engagement: viewData.engagement },
      passed,
      weight: 0.5,
    };
    if (passed) velocityScore += 50;
  } else if (hoursSincePublish <= 6) {
    const trigger = ALGORITHM_PARAMETERS.velocityTriggers.first6Hours;
    const passed = viewData.views >= trigger.viewsNeeded && 
                   viewData.engagement >= trigger.engagementNeeded;
    velocityMetrics.first6Hours = {
      required: trigger,
      actual: { views: viewData.views, engagement: viewData.engagement },
      passed,
      weight: 0.35,
    };
    if (passed) velocityScore += 35;
  } else if (hoursSincePublish <= 24) {
    const trigger = ALGORITHM_PARAMETERS.velocityTriggers.first24Hours;
    const passed = viewData.views >= trigger.viewsNeeded && 
                   viewData.engagement >= trigger.engagementNeeded;
    velocityMetrics.first24Hours = {
      required: trigger,
      actual: { views: viewData.views, engagement: viewData.engagement },
      passed,
      weight: 0.25,
    };
    if (passed) velocityScore += 25;
  }

  return {
    velocityMetrics,
    velocityScore: Math.round(velocityScore),
    recommendation: velocityScore > 50
      ? '✓ Velocity tetikleyicisi geçildi! Algoritma videoyu keşfete itecek.'
      : '⚠ Velocity tetikleyicisi geçilmedi. İlk saatlerde etkileşim kritik!',
  };
}

// ─── Rewatch Loop (Yeniden İzlenme Döngüsü) Analizi ───────────────────────
export function analyzeRewatchLoop(videoScript) {
  const lines = videoScript.split('\n').filter(l => l.trim());
  
  // Hook ve Ending'in benzerliğini kontrol et
  const hook = lines[0] || '';
  const ending = lines[lines.length - 1] || '';

  const similarity = calculateSimilarity(hook, ending);
  const loopQuality = similarity > 0.4 ? 'high' : similarity > 0.2 ? 'medium' : 'low';

  return {
    hook,
    ending,
    similarity: Math.round(similarity * 100),
    loopQuality,
    recommendation: loopQuality === 'high'
      ? '✓ Hook ve ending mükemmel bir döngü oluşturuyor. İzleyici otomatik olarak yeniden izleyecek.'
      : loopQuality === 'medium'
      ? '⚠ Hook ve ending arasında bağlantı var ama güçlenebilir.'
      : '❌ Hook ve ending bağlantısız. Yeniden tasarla.',
    advice: generateLoopAdvice(hook, ending, loopQuality),
  };
}

// ─── Benzerlik Hesapla ──────────────────────────────────────────────────────
function calculateSimilarity(str1, str2) {
  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();

  if (s1 === s2) return 1;
  if (s1.length === 0 || s2.length === 0) return 0;

  // Anahtar kelimelerin çakışmasını kontrol et
  const words1 = s1.match(/\b\w+\b/g) || [];
  const words2 = s2.match(/\b\w+\b/g) || [];
  const commonWords = words1.filter(w => words2.includes(w)).length;
  
  return commonWords / Math.max(words1.length, words2.length);
}

// ─── Loop Önerisi ───────────────────────────────────────────────────────────
function generateLoopAdvice(hook, ending, quality) {
  if (quality === 'high') {
    return ['• Mükemmel! Bu döngü izleyiciyi otomatik olarak yeniden izlemeye itecek'];
  } else if (quality === 'medium') {
    return [
      '• Ending\'i hook\'a daha benzer yap',
      '• Aynı anahtar kelimeyi kullan',
      '• Merak uyandırıcı bir soru ile bitir',
    ];
  } else {
    return [
      '• Ending\'i hook\'a benzer hale getir',
      '• Başlangıçtaki merak uyandırıcı öğeyi sonunda tekrar et',
      '• Videonun başında ve sonunda aynı görsel/ses kullan',
      '• İzleyiciyi "bir daha izlemek" isteyecek şekilde bitir',
    ];
  }
}

// ─── Viewed vs Swiped Analizi ───────────────────────────────────────────────
export function analyzeViewedVsSwiped(engagementData) {
  const totalImpressions = engagementData.views + engagementData.swipes;
  const viewedPercentage = (engagementData.views / totalImpressions) * 100;
  const swipedPercentage = (engagementData.swipes / totalImpressions) * 100;

  const passed = viewedPercentage >= (ALGORITHM_PARAMETERS.engagementMetrics.viewedVsSwiped * 100);

  return {
    viewed: {
      count: engagementData.views,
      percentage: Math.round(viewedPercentage),
    },
    swiped: {
      count: engagementData.swipes,
      percentage: Math.round(swipedPercentage),
    },
    passed,
    recommendation: passed
      ? `✓ ${Math.round(viewedPercentage)}% izlenme oranı mükemmel! Algoritma videoyu keşfete itecek.`
      : `⚠ ${Math.round(viewedPercentage)}% izlenme oranı düşük. Hook'u güçlendir.`,
    algorithmScore: Math.round(viewedPercentage),
  };
}

// ─── Ortalama İzlenme Süresi Analizi ─────────────────────────────────────────
export function analyzeAverageWatchTime(watchTimeData, videoDuration) {
  const avgWatchPercentage = (watchTimeData.avgWatchSeconds / videoDuration) * 100;
  const passed = avgWatchPercentage >= (ALGORITHM_PARAMETERS.engagementMetrics.avgWatchTime * 100);

  return {
    videoDuration,
    avgWatchSeconds: watchTimeData.avgWatchSeconds,
    avgWatchPercentage: Math.round(avgWatchPercentage),
    passed,
    recommendation: passed
      ? `✓ İzleyiciler videonun %${Math.round(avgWatchPercentage)}'ini izliyor. Mükemmel tutulma!`
      : `⚠ İzleyiciler videonun %${Math.round(avgWatchPercentage)}'ini izliyor. Sıkıcı bölümleri kısalt.`,
    algorithmScore: Math.round(avgWatchPercentage),
  };
}

// ─── Algoritma Raporu ───────────────────────────────────────────────────────
export function generateAlgorithmReport(videoData) {
  const seedAnalysis = analyzeSeedAudiencePerformance({
    views: videoData.views || 0,
    engagement: videoData.engagement || 0,
  });

  const velocityAnalysis = analyzeVelocity(
    { views: videoData.views || 0, engagement: videoData.engagement || 0 },
    videoData.hoursSincePublish || 1
  );

  const rewatchAnalysis = analyzeRewatchLoop(videoData.script || '');

  const viewedVsSwipedAnalysis = analyzeViewedVsSwiped({
    views: videoData.views || 0,
    swipes: videoData.swipes || 0,
  });

  const watchTimeAnalysis = analyzeAverageWatchTime(
    { avgWatchSeconds: videoData.avgWatchSeconds || 0 },
    videoData.duration || 15
  );

  const overallAlgorithmScore = Math.round(
    (seedAnalysis.viralPotential.score * 0.25 +
      velocityAnalysis.velocityScore * 0.25 +
      viewedVsSwipedAnalysis.algorithmScore * 0.25 +
      watchTimeAnalysis.avgWatchPercentage * 0.25)
  );

  return {
    timestamp: new Date().toISOString(),
    overallAlgorithmScore,
    seedAudience: seedAnalysis,
    velocity: velocityAnalysis,
    rewatchLoop: rewatchAnalysis,
    viewedVsSwiped: viewedVsSwipedAnalysis,
    watchTime: watchTimeAnalysis,
    recommendation: generateFinalRecommendation(overallAlgorithmScore),
  };
}

// ─── Final Tavsiye ──────────────────────────────────────────────────────────
function generateFinalRecommendation(score) {
  if (score > 80) {
    return '🚀 VIRAL HAZIR! Bu video algoritmanın favorisi olacak. Yayınla!';
  } else if (score > 60) {
    return '📈 İYİ POTANSİYEL! Küçük iyileştirmelerle viral olabilir.';
  } else if (score > 40) {
    return '⚠️ ORTA SEVİYE! Önemli iyileştirmeler gerekli.';
  } else {
    return '❌ DÜŞÜK SKOR! Yeniden tasarla.';
  }
}

// ─── Optimal Yayınlama Zamanı Önerisi ────────────────────────────────────────
export function suggestOptimalPublishTime(category, timezone = 'UTC') {
  const optimalTimes = {
    motivation: ['08:00', '12:00', '20:00'], // Sabah, öğle, akşam
    psychology: ['19:00', '21:00'], // Akşam (düşünme zamanı)
    health: ['07:00', '18:00'], // Sabah (spor) ve akşam
    shock: ['12:00', '20:00'], // Öğle ve akşam
    knowledge: ['09:00', '14:00', '19:00'], // Sabah, öğleden sonra, akşam
    finance: ['09:00', '16:00'], // Sabah ve pazar kapanışı
  };

  return {
    category,
    suggestedTimes: optimalTimes[category] || ['12:00', '20:00'],
    timezone,
    reason: `${category} kategorisindeki videoların bu saatlerde en yüksek etkileşimi alması geçmiş verilerle kanıtlanmıştır.`,
  };
}
