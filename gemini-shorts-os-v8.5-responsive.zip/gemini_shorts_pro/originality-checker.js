/**
 * Originality Checker — Özgünlük Denetçisi
 * ==========================================
 * YouTube'un "Tekrarlanan İçerik" ve "Kalıplaşmış İçerik" algoritmalarını atlatma
 * - Geçmiş videoların metin ve görsel benzerliğini analiz
 * - Benzersizlik skoru hesaplama
 * - Akıllı parafraz önerileri
 * - Dijital parmak izi (hash) değişimi
 */

import crypto from 'crypto';

// ─── Benzerlik Algoritması (Levenshtein Distance) ──────────────────────────
function calculateSimilarity(str1, str2) {
  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();

  if (s1 === s2) return 100;
  if (s1.length === 0 || s2.length === 0) return 0;

  const matrix = Array(s2.length + 1)
    .fill(null)
    .map(() => Array(s1.length + 1).fill(0));

  for (let i = 0; i <= s1.length; i++) matrix[0][i] = i;
  for (let j = 0; j <= s2.length; j++) matrix[j][0] = j;

  for (let j = 1; j <= s2.length; j++) {
    for (let i = 1; i <= s1.length; i++) {
      const indicator = s1[i - 1] === s2[j - 1] ? 0 : 1;
      matrix[j][i] = Math.min(
        matrix[j][i - 1] + 1,
        matrix[j - 1][i] + 1,
        matrix[j - 1][i - 1] + indicator
      );
    }
  }

  const distance = matrix[s2.length][s1.length];
  const maxLength = Math.max(s1.length, s2.length);
  return Math.round(((maxLength - distance) / maxLength) * 100);
}

// ─── Anahtar Kelime Çıkarma ─────────────────────────────────────────────────
function extractKeywords(text, limit = 10) {
  const stopWords = new Set([
    've', 'veya', 'ama', 'çünkü', 'için', 'ile', 'de', 'da', 'mi', 'mı',
    'bu', 'şu', 'o', 'ben', 'sen', 'o', 'biz', 'siz', 'onlar',
    'bir', 'iki', 'üç', 'dört', 'beş', 'altı', 'yedi', 'sekiz', 'dokuz', 'on',
    'var', 'yok', 'evet', 'hayır', 'ne', 'nedir', 'kim', 'kimdir',
  ]);

  const words = text
    .toLowerCase()
    .match(/\b\w+\b/g) || [];

  const filtered = words
    .filter(w => w.length > 3 && !stopWords.has(w))
    .reduce((acc, w) => {
      acc[w] = (acc[w] || 0) + 1;
      return acc;
    }, {});

  return Object.entries(filtered)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([word]) => word);
}

// ─── Metin Benzersizlik Analizi ──────────────────────────────────────────────
export function analyzeTextOriginality(newText, previousTexts = []) {
  const similarities = previousTexts.map(prevText => ({
    text: prevText.slice(0, 50) + '...',
    similarity: calculateSimilarity(newText, prevText),
  }));

  const avgSimilarity = similarities.length > 0
    ? similarities.reduce((sum, s) => sum + s.similarity, 0) / similarities.length
    : 0;

  const maxSimilarity = similarities.length > 0
    ? Math.max(...similarities.map(s => s.similarity))
    : 0;

  const newKeywords = extractKeywords(newText);
  const prevKeywords = previousTexts.flatMap(t => extractKeywords(t));
  const keywordOverlap = newKeywords.filter(k => prevKeywords.includes(k)).length;
  const keywordOverlapPercent = newKeywords.length > 0
    ? Math.round((keywordOverlap / newKeywords.length) * 100)
    : 0;

  return {
    avgSimilarity: Math.round(avgSimilarity),
    maxSimilarity: Math.round(maxSimilarity),
    keywordOverlapPercent,
    similarities,
    isUnique: maxSimilarity < 20, // %20'den az benzer = Benzersiz
    uniquenessScore: Math.max(0, 100 - maxSimilarity),
  };
}

// ─── Görsel Benzersizlik Analizi (Placeholder) ──────────────────────────────
export function analyzeVisualOriginality(newVideoHash, previousHashes = []) {
  // Gerçek uygulamada, görsel benzerliği tespit etmek için perceptual hashing
  // (pHash) veya görsel AI modelleri kullanılabilir.
  // Burada basit hash karşılaştırması yapıyoruz.

  const matches = previousHashes.filter(h => h === newVideoHash);
  const exactMatch = matches.length > 0;

  return {
    exactMatch,
    matchCount: matches.length,
    isUnique: !exactMatch,
    uniquenessScore: exactMatch ? 0 : 100,
  };
}

// ─── Genel Özgünlük Raporu ──────────────────────────────────────────────────
export function generateOriginalityReport(newContent, previousContents = []) {
  const textOriginality = analyzeTextOriginality(
    newContent.text || '',
    (previousContents || []).map(c => c.text || '')
  );

  const videoHashes = (previousContents || []).map(c => c.videoHash || '');
  const visualOriginality = analyzeVisualOriginality(
    newContent.videoHash || '',
    videoHashes
  );

  const overallUniquenessScore = Math.round(
    (textOriginality.uniquenessScore * 0.6 + visualOriginality.uniquenessScore * 0.4)
  );

  const isOriginal = overallUniquenessScore >= 80;

  return {
    timestamp: new Date().toISOString(),
    overallUniquenessScore,
    isOriginal,
    textOriginality,
    visualOriginality,
    recommendation: isOriginal
      ? `✓ İçerik benzersiz (${overallUniquenessScore}%). Yayınlamaya hazır.`
      : `⚠ İçerik benzer (${overallUniquenessScore}%). Daha özgün bir yaklaşım dene.`,
    paraphraseAdvice: generateParaphraseAdvice(textOriginality),
  };
}

// ─── Parafraz Önerileri ──────────────────────────────────────────────────────
function generateParaphraseAdvice(textOriginality) {
  if (textOriginality.maxSimilarity > 50) {
    return [
      '• Cümle yapısını tamamen değiştir',
      '• Farklı kelimeler ve ifadeler kullan',
      '• Anlatım tonunu değiştir (resmi → samimi veya tersi)',
      '• Başlangıç ve bitiş noktalarını değiştir',
    ];
  } else if (textOriginality.keywordOverlapPercent > 40) {
    return [
      '• Anahtar kelimeleri eşanlamlılarla değiştir',
      '• Cümle sırasını değiştir',
      '• Daha kısa veya daha uzun cümleler kullan',
    ];
  }
  return ['• İçerik yeterince benzersiz görünüyor'];
}

// ─── Dijital Parmak İzi (Hash) Değişimi ─────────────────────────────────────
export function generateUniqueVideoHash(baseHash, variation = 0) {
  // Aynı videonun her seferinde farklı hash değeri üretmesini sağlamak
  // için rastgele bir "variation" (değişim) parametresi kullanıyoruz.
  
  const seed = `${baseHash}-${variation}-${Date.now()}-${Math.random()}`;
  const hash = crypto.createHash('sha256').update(seed).digest('hex');
  
  return {
    hash,
    variation,
    timestamp: new Date().toISOString(),
  };
}

// ─── FPS (Frame Per Second) Varyasyonu ───────────────────────────────────────
export function getVariableFPS() {
  // YouTube'un "aynı dosya" eşleşmesini bozabilmek için FPS'i hafifçe değiştir
  const baseFPS = 30;
  const variation = Math.random() * 0.1 - 0.05; // -0.05 ile +0.05 arası
  return parseFloat((baseFPS + variation).toFixed(2));
}

// ─── Ses Pitch (Ton) Varyasyonu ─────────────────────────────────────────────
export function getVariablePitch() {
  // TTS veya müzik sesinin tonunu hafifçe değiştir (%1-3 arası)
  const basePitch = 1.0;
  const variation = (Math.random() * 0.03 - 0.015); // -1.5% ile +1.5% arası
  return parseFloat((basePitch + variation).toFixed(3));
}

// ─── Renk Filtresi (LUT) Varyasyonu ─────────────────────────────────────────
export function getRandomColorFilter() {
  // Rastgele renk filtresi parametreleri
  const filters = [
    { name: 'warm', brightness: 1.05, saturation: 1.1, contrast: 1.02 },
    { name: 'cool', brightness: 0.98, saturation: 0.95, contrast: 1.05 },
    { name: 'vintage', brightness: 1.02, saturation: 0.85, contrast: 1.08 },
    { name: 'vibrant', brightness: 1.0, saturation: 1.2, contrast: 1.1 },
    { name: 'neutral', brightness: 1.0, saturation: 1.0, contrast: 1.0 },
  ];

  return filters[Math.floor(Math.random() * filters.length)];
}

// ─── Zoom Hareketi Varyasyonu ───────────────────────────────────────────────
export function getRandomZoomVariation() {
  // Hafif zoom-in/out hareketleri
  return {
    startZoom: 1.0 + (Math.random() * 0.02 - 0.01), // 0.99-1.01
    endZoom: 1.0 + (Math.random() * 0.02 - 0.01),
    duration: 0.5 + Math.random() * 0.5, // 0.5-1.0 saniye
  };
}

// ─── Grain (Kumlanma) Efekti ────────────────────────────────────────────────
export function getRandomGrainEffect() {
  // Rastgele "grain" efekti parametreleri
  return {
    intensity: Math.random() * 0.05 + 0.01, // 0.01-0.06
    type: Math.random() > 0.5 ? 'film' : 'digital',
  };
}

// ─── Benzersizleştirme Raporu ───────────────────────────────────────────────
export function generateUniquenessReport(originalityReport, videoModifications) {
  return {
    timestamp: new Date().toISOString(),
    textUniqueness: originalityReport.overallUniquenessScore,
    videoModifications: {
      fps: videoModifications.fps,
      pitch: videoModifications.pitch,
      colorFilter: videoModifications.colorFilter?.name,
      zoomVariation: videoModifications.zoomVariation ? 'Applied' : 'None',
      grainEffect: videoModifications.grainEffect ? 'Applied' : 'None',
    },
    digitalFingerprint: videoModifications.hash,
    totalUniquenessScore: Math.round(
      (originalityReport.overallUniquenessScore * 0.5 +
        (videoModifications.hash ? 50 : 0)) // Video hash değişimi = +50 puan
    ),
    recommendation: originalityReport.recommendation,
    youtubeAlgorithmRisk: {
      reusedContentRisk: originalityReport.overallUniquenessScore < 50 ? 'HIGH' : 'LOW',
      shadowBanRisk: videoModifications.hash ? 'MINIMAL' : 'MODERATE',
    },
  };
}

// ─── Özgünlük Geçmişi Kaydet ────────────────────────────────────────────────
export function recordOriginalityHistory(jobId, report, videoPath) {
  return {
    jobId,
    timestamp: new Date().toISOString(),
    videoPath,
    uniquenessScore: report.overallUniquenessScore,
    textSimilarity: report.textOriginality.maxSimilarity,
    isOriginal: report.isOriginal,
    modifications: report.videoModifications || {},
  };
}
