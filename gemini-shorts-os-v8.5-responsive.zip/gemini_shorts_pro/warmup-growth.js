/**
 * Warm-Up & Growth — Isınma ve Büyüme
 * ====================================
 * Sıfır (yeni açılmış) hesaplar için güvenli ve hızlı büyüme stratejisi
 */

// ─── Hesap Yaşı Kategorileri ────────────────────────────────────────────────
const ACCOUNT_AGE_STAGES = {
  stage1: {
    name: 'Yeni Hesap (0-3 gün)',
    daysOld: 3,
    dailyUploadLimit: 1,
    riskLevel: 'CRITICAL',
    strategy: 'Minimum Activity - Algoritma Tanıma',
  },
  stage2: {
    name: 'Gelişen Hesap (4-7 gün)',
    daysOld: 7,
    dailyUploadLimit: 2,
    riskLevel: 'HIGH',
    strategy: 'Kademeli Artış - Niş Doğrulama',
  },
  stage3: {
    name: 'Güvenli Hesap (8-14 gün)',
    daysOld: 14,
    dailyUploadLimit: 3,
    riskLevel: 'MEDIUM',
    strategy: 'Hızlı Büyüme - Algoritma Güveni',
  },
  stage4: {
    name: 'Olgun Hesap (15+ gün)',
    daysOld: Infinity,
    dailyUploadLimit: 5,
    riskLevel: 'LOW',
    strategy: 'Agresif Büyüme - Viral Potansiyeli',
  },
};

// ─── Hesap Yaşını Belirle ve Aşamasını Döndür ──────────────────────────────
export function determineAccountStage(accountCreatedDate) {
  const now = new Date();
  const createdDate = new Date(accountCreatedDate);
  const daysOld = Math.floor((now - createdDate) / (1000 * 60 * 60 * 24));

  let stage = ACCOUNT_AGE_STAGES.stage1;
  
  if (daysOld > 14) stage = ACCOUNT_AGE_STAGES.stage4;
  else if (daysOld > 7) stage = ACCOUNT_AGE_STAGES.stage3;
  else if (daysOld > 3) stage = ACCOUNT_AGE_STAGES.stage2;

  return {
    daysOld,
    stage,
    dailyUploadLimit: stage.dailyUploadLimit,
    riskLevel: stage.riskLevel,
    recommendation: `${stage.name}: ${stage.strategy}`,
  };
}

// ─── Günlük Yükleme Sınırı Kontrolü ────────────────────────────────────────
export function checkDailyUploadLimit(accountStage, uploadedToday) {
  const limit = accountStage.dailyUploadLimit;
  const remaining = limit - uploadedToday;

  return {
    limit,
    uploadedToday,
    remaining,
    canUpload: remaining > 0,
    recommendation: remaining > 0
      ? `✓ Bugün ${remaining} video daha yükleyebilirsiniz`
      : `❌ Günlük limit (${limit}) aşıldı. Yarın tekrar deneyin.`,
  };
}

// ─── İnsan Gibi Etkileşim Simülasyonu ───────────────────────────────────────
export function generateHumanLikeInteraction(accountStage) {
  const interactions = {
    browsing: {
      duration: Math.random() * 120 + 60, // 60-180 saniye
      actions: [
        'YouTube ana sayfasına git',
        'Rastgele 3-5 Shorts videosu kaydır',
        'Rastgele 1-2 videoya tıkla (izleme)',
        'Arama yaparak kanalın kategorisine uygun videolar ara',
      ],
      frequency: accountStage.riskLevel === 'CRITICAL' ? 'Her video yüklemeden önce' : 'Her 2 video yüklemeden sonra',
    },
    watching: {
      duration: Math.random() * 30 + 15, // 15-45 saniye
      videoCount: Math.floor(Math.random() * 3) + 1, // 1-3 video
      completionRate: Math.random() * 0.5 + 0.3, // %30-80 izlenme
    },
    liking: {
      probability: 0.3, // %30 ihtimalle beğeni yap
      frequency: 'Rastgele',
    },
    commenting: {
      probability: 0.1, // %10 ihtimalle yorum yap
      frequency: 'Çok nadir',
    },
  };

  return {
    accountStage: accountStage.name,
    interactions,
    recommendation: `Günde ${interactions.browsing.frequency} insan gibi gezinme yapın`,
  };
}

// ─── Niş Doğrulama Stratejisi (İlk 5 Video) ────────────────────────────────
export function generateNicheValidationStrategy(category, videoCount) {
  const strategies = {
    psychology: {
      keywords: ['psikoloji', 'davranış', 'zihin', 'insan', 'düşünce'],
      tags: ['#psikoloji', '#davranış', '#zihin', '#insan', '#bilim'],
      themes: ['Karanlık Psikoloji', 'Manipülasyon', 'Davranış Analizi', 'Zihinsel Sağlık'],
    },
    motivation: {
      keywords: ['motivasyon', 'başarı', 'hedef', 'ilham', 'gelişim'],
      tags: ['#motivasyon', '#başarı', '#hedef', '#ilham', '#gelişim'],
      themes: ['Başarı Hikayeleri', 'Kişisel Gelişim', 'Liderlik', 'Hayat Dersleri'],
    },
    health: {
      keywords: ['sağlık', 'beslenme', 'fitness', 'wellness', 'yaşam'],
      tags: ['#sağlık', '#beslenme', '#fitness', '#wellness', '#yaşam'],
      themes: ['Beslenme Tüyoları', 'Egzersiz', 'Mental Sağlık', 'Yaşam Kalitesi'],
    },
    knowledge: {
      keywords: ['bilgi', 'eğitim', 'öğrenme', 'merak', 'keşif'],
      tags: ['#bilgi', '#eğitim', '#öğrenme', '#merak', '#keşif'],
      themes: ['İlginç Gerçekler', 'Bilimsel Keşifler', 'Tarih', 'Teknoloji'],
    },
  };

  const strategy = strategies[category] || strategies.knowledge;
  const isFirstFiveVideos = videoCount <= 5;

  return {
    category,
    videoCount,
    isFirstFiveVideos,
    strategy: {
      keywords: strategy.keywords,
      tags: strategy.tags,
      themes: strategy.themes,
      consistency: isFirstFiveVideos ? 'STRICT' : 'FLEXIBLE',
    },
    recommendation: isFirstFiveVideos
      ? `✓ İlk 5 video için katı niş doğrulama: ${strategy.keywords.join(', ')} anahtar kelimelerini kullanın`
      : `✓ 5. videodan sonra biraz daha esneklik kazandınız`,
  };
}

// ─── Otomatik Yorum Sabitleme (Engagement Starter) ───────────────────────────
export function generateEngagementStarterComment(videoTitle, category) {
  const commentTemplates = {
    psychology: [
      'Bu davranışı gözlemlediniz mi? Yorumlarda deneyiminizi paylaşın 👇',
      'Bu psikolojik numarayı daha önce fark ettiniz mi? 🤔',
      'Sizce bu doğru mu? Düşüncelerinizi yazın 👇',
    ],
    motivation: [
      'Bu başarı hikayesi sizi ilham verdi mi? Kendi hikayenizi paylaşın 👇',
      'Hangi adım sizin için en zor oldu? Yorumda belirtin 👇',
      'Bu yolculuğun hangi aşamasında olduğunuzu biliyor musunuz? 👇',
    ],
    health: [
      'Bu tüyoyu deneyecek misiniz? Sonuçlarınızı paylaşın 👇',
      'Sizin sağlık rutininiz nedir? Yorumda yazın 👇',
      'Bu bilgiyi daha önce biliyor muydunuz? 👇',
    ],
    knowledge: [
      'Bu gerçeği biliyor muydunuz? Yorumda tepkinizi yazın 👇',
      'Hangi bilgi sizi en çok şaşırttı? 👇',
      'Bunun hakkında ne düşünüyorsunuz? Paylaşın 👇',
    ],
  };

  const templates = commentTemplates[category] || commentTemplates.knowledge;
  const randomComment = templates[Math.floor(Math.random() * templates.length)];

  return {
    comment: randomComment,
    shouldPin: true,
    timing: 'Video yüklendikten 5 dakika sonra',
    recommendation: '✓ Bu yorum izleyicileri etkileşime teşvik edecektir',
  };
}

// ─── Algoritma Güveni Skoru (Trust Score) ──────────────────────────────────
export function calculateTrustScore(accountData) {
  let score = 0;

  // Hesap yaşı
  const stage = determineAccountStage(accountData.createdDate);
  if (stage.daysOld > 14) score += 30;
  else if (stage.daysOld > 7) score += 20;
  else if (stage.daysOld > 3) score += 10;

  // Video sayısı ve tutarlılık
  if (accountData.videoCount >= 5) score += 20;
  if (accountData.videoCount >= 10) score += 10;

  // Etkileşim oranı
  if (accountData.averageEngagementRate > 0.1) score += 20;
  if (accountData.averageEngagementRate > 0.15) score += 10;

  // Niş tutarlılığı
  if (accountData.nichConsistency > 0.8) score += 20;

  // Spam belirtileri
  if (accountData.hasSpamWarnings) score -= 30;
  if (accountData.hasContentIdStrikes) score -= 50;

  return {
    trustScore: Math.max(0, Math.min(100, score)),
    riskLevel: score < 30 ? 'CRITICAL' : score < 60 ? 'HIGH' : score < 80 ? 'MEDIUM' : 'LOW',
    recommendation: score < 30
      ? '❌ Hesap riskli, çok dikkatli olun'
      : score < 60
      ? '⚠️ Hesap gelişiyor, kademeli büyüme devam edin'
      : score < 80
      ? '✓ Hesap güvenli, hızlı büyüme başlayabilir'
      : '✓✓ Hesap güvenilir, agresif büyüme yapabilirsiniz',
  };
}

// ─── Isınma Durumu Raporu ──────────────────────────────────────────────────
export function generateWarmupStatusReport(accountData) {
  const stage = determineAccountStage(accountData.createdDate);
  const trustScore = calculateTrustScore(accountData);
  const interaction = generateHumanLikeInteraction(stage.stage);
  const niche = generateNicheValidationStrategy(accountData.category, accountData.videoCount);

  return {
    timestamp: new Date().toISOString(),
    accountAge: stage,
    trustScore,
    humanInteraction: interaction,
    nicheValidation: niche,
    dailyUploadStatus: checkDailyUploadLimit(stage.stage, accountData.uploadedToday || 0),
    overallRecommendation: `${trustScore.recommendation}. ${stage.recommendation}`,
  };
}

// ─── Güvenli Yükleme Zamanı Hesapla ────────────────────────────────────────
export function calculateSafeUploadTiming(accountStage, lastUploadTime) {
  const minimumGapMinutes = accountStage.riskLevel === 'CRITICAL' ? 120 : 
                            accountStage.riskLevel === 'HIGH' ? 60 : 30;

  const now = new Date();
  const lastUpload = new Date(lastUploadTime);
  const minutesSinceLastUpload = Math.floor((now - lastUpload) / (1000 * 60));
  const minutesUntilNextUpload = Math.max(0, minimumGapMinutes - minutesSinceLastUpload);

  return {
    minimumGapMinutes,
    minutesSinceLastUpload,
    canUploadNow: minutesUntilNextUpload === 0,
    minutesUntilNextUpload,
    recommendation: minutesUntilNextUpload === 0
      ? '✓ Şimdi yükleyebilirsiniz'
      : `⏳ ${minutesUntilNextUpload} dakika sonra yükleyebilirsiniz`,
  };
}

// ─── Sıfır Hesap Başlangıç Kontrol Listesi ──────────────────────────────────
export function getZeroAccountStartupChecklist() {
  return {
    checklist: [
      {
        step: 1,
        task: 'Hesap Oluştur',
        description: 'Yeni Gmail hesabı oluştur ve YouTube kanalını aç',
        status: 'TODO',
      },
      {
        step: 2,
        task: 'Kanal Bilgilerini Doldur',
        description: 'Kanal adı, açıklaması ve profil resmini ekle',
        status: 'TODO',
      },
      {
        step: 3,
        task: 'Niş Belirle',
        description: 'Kanalın kategorisini (Psikoloji, Motivasyon vb.) seç',
        status: 'TODO',
      },
      {
        step: 4,
        task: 'Isınma Modunu Aktif Et',
        description: 'Panelden "Warm-Up Mode" seçeneğini aç',
        status: 'TODO',
      },
      {
        step: 5,
        task: 'İlk Videoyu Yükle',
        description: 'Sistem tarafından üretilen ilk videoyu yükle',
        status: 'TODO',
      },
      {
        step: 6,
        task: 'İnsan Gibi Gezin',
        description: 'YouTube\'da 2-3 dakika rastgele videolar kaydır',
        status: 'TODO',
      },
      {
        step: 7,
        task: '3 Gün Bekle',
        description: 'Algoritmanın kanalı tanıması için 3 gün bekle',
        status: 'TODO',
      },
      {
        step: 8,
        task: 'Hızı Artır',
        description: 'Sistem otomatik olarak günlük video sayısını artıracak',
        status: 'TODO',
      },
    ],
    estimatedTimeToViralReady: '14-21 gün',
    recommendation: '✓ Bu adımları takip ederseniz hesabınız güvenli ve hızlı büyüyecektir',
  };
}
