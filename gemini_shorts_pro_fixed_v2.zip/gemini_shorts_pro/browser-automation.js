/**
 * Browser Automation Module — Tarayıcı Otomasyonu
 * ================================================
 * ChatGPT ve Gemini Web arayüzlerini Puppeteer ile kontrol eder
 * - İnsan gibi davranma (stealth mode)
 * - Mesaj yazma ve cevap okuma
 * - Dosya yükleme
 * - Video analizi
 */

import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import fsp from 'fs/promises';
import path from 'path';

puppeteer.use(StealthPlugin());

let browser = null;
let chatgptPage = null;
let geminiPage = null;

// ─── Browser Başlatma ───────────────────────────────────────────────────────
export async function initBrowser() {
  if (browser) return browser;
  try {
    browser = await puppeteer.launch({
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--single-process=false',
      ],
      defaultViewport: { width: 1280, height: 720 },
    });
    console.log(' Tarayıcı başlatıldı');
    return browser;
  } catch (e) {
    console.error(' Tarayıcı başlatma hatası:', e.message);
    throw e;
  }
}

// ─── Browser Kapatma ────────────────────────────────────────────────────────
export async function closeBrowser() {
  if (browser) {
    await browser.close();
    browser = null;
    chatgptPage = null;
    geminiPage = null;
  }
}

// ─── ChatGPT Bağlantısı ─────────────────────────────────────────────────────
export async function connectChatGPT() {
  if (chatgptPage) return chatgptPage;
  const b = await initBrowser();
  chatgptPage = await b.newPage();
  await chatgptPage.goto('https://chatgpt.com', { waitUntil: 'networkidle2', timeout: 60000 });
  
  // Oturum açılmış mı kontrol et
  await chatgptPage.waitForTimeout(2000);
  const loggedIn = await chatgptPage.evaluate(() => {
    return !!document.querySelector('[data-testid="send-button"]') || 
           !!document.querySelector('button[aria-label*="Send"]') ||
           !!document.querySelector('textarea');
  });

  if (!loggedIn) {
    console.log(' ChatGPT\'ye oturum açmanız gerekiyor. Tarayıcı açıldı, lütfen manuel olarak giriş yapın.');
    console.log('   URL: https://chatgpt.com');
    console.log('   Giriş yaptıktan sonra sisteme devam edebilirsiniz.');
    await chatgptPage.waitForTimeout(30000); // 30 saniye bekle
  }

  return chatgptPage;
}

// ─── Gemini Web Bağlantısı ──────────────────────────────────────────────────
export async function connectGemini() {
  if (geminiPage) return geminiPage;
  const b = await initBrowser();
  geminiPage = await b.newPage();
  await geminiPage.goto('https://gemini.google.com', { waitUntil: 'networkidle2', timeout: 60000 });
  
  await geminiPage.waitForTimeout(2000);
  const loggedIn = await geminiPage.evaluate(() => {
    return !!document.querySelector('[aria-label*="Message"]') ||
           !!document.querySelector('textarea') ||
           !!document.querySelector('[role="textbox"]');
  });

  if (!loggedIn) {
    console.log(' Gemini\'ye oturum açmanız gerekiyor. Tarayıcı açıldı, lütfen manuel olarak giriş yapın.');
    console.log('   URL: https://gemini.google.com');
    console.log('   Giriş yaptıktan sonra sisteme devam edebilirsiniz.');
    await geminiPage.waitForTimeout(30000);
  }

  return geminiPage;
}

// ─── ChatGPT'ye Mesaj Gönder ────────────────────────────────────────────────
export async function sendMessageToChatGPT(message) {
  const page = await connectChatGPT();
  
  try {
    // Textarea'yı bul
    const textarea = await page.$('textarea');
    if (!textarea) throw new Error('ChatGPT textarea bulunamadı');

    // Mesajı yaz (insan gibi, karakter karakter)
    await textarea.click();
    await page.waitForTimeout(300);
    
    // Mesajı yapıştır (daha hızlı)
    await page.evaluate((msg) => {
      const ta = document.querySelector('textarea');
      if (ta) ta.value = msg;
      ta?.dispatchEvent(new Event('input', { bubbles: true }));
    }, message);

    await page.waitForTimeout(500);

    // Gönder butonunu bul ve tıkla
    const sendBtn = await page.$('button[aria-label*="Send"], button[data-testid="send-button"]');
    if (!sendBtn) throw new Error('Gönder butonu bulunamadı');
    
    await sendBtn.click();
    console.log(' ChatGPT\'ye mesaj gönderildi');

    // Cevabı bekle (max 2 dakika)
    const response = await waitForChatGPTResponse(page, 120000);
    return response;

  } catch (e) {
    console.error('ChatGPT mesaj hatası:', e.message);
    throw e;
  }
}

// ─── ChatGPT Cevabını Bekle ─────────────────────────────────────────────────
async function waitForChatGPTResponse(page, timeout = 120000) {
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    // Son mesajı oku
    const lastMessage = await page.evaluate(() => {
      const msgs = Array.from(document.querySelectorAll('[data-message-id], [role="article"]'));
      if (!msgs.length) return null;
      const last = msgs[msgs.length - 1];
      return last?.innerText || last?.textContent || null;
    });

    if (lastMessage && lastMessage.length > 20) {
      console.log(' ChatGPT cevabı alındı');
      return lastMessage;
    }

    await page.waitForTimeout(1000);
  }

  throw new Error('ChatGPT cevap verme timeout');
}

// ─── Gemini'ye Mesaj Gönder ─────────────────────────────────────────────────
export async function sendMessageToGemini(message) {
  const page = await connectGemini();
  
  try {
    // Textarea'yı bul
    const textarea = await page.$('textarea, [role="textbox"]');
    if (!textarea) throw new Error('Gemini textarea bulunamadı');

    await textarea.click();
    await page.waitForTimeout(300);

    // Mesajı yapıştır
    await page.evaluate((msg) => {
      const ta = document.querySelector('textarea, [role="textbox"]');
      if (ta) {
        ta.value = msg;
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }, message);

    await page.waitForTimeout(500);

    // Gönder butonunu tıkla (Enter tuşu veya buton)
    await page.keyboard.press('Enter');
    console.log(' Gemini\'ye mesaj gönderildi');

    // Cevabı bekle
    const response = await waitForGeminiResponse(page, 120000);
    return response;

  } catch (e) {
    console.error('Gemini mesaj hatası:', e.message);
    throw e;
  }
}

// ─── Gemini Cevabını Bekle ──────────────────────────────────────────────────
async function waitForGeminiResponse(page, timeout = 120000) {
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    const lastMessage = await page.evaluate(() => {
      const msgs = Array.from(document.querySelectorAll('[data-message-id], [role="article"], .response-text'));
      if (!msgs.length) return null;
      const last = msgs[msgs.length - 1];
      return last?.innerText || last?.textContent || null;
    });

    if (lastMessage && lastMessage.length > 20) {
      console.log(' Gemini cevabı alındı');
      return lastMessage;
    }

    await page.waitForTimeout(1000);
  }

  throw new Error('Gemini cevap verme timeout');
}

// ─── Dosya Yükleme (Video Analizi için) ──────────────────────────────────
export async function uploadFileToGemini(filePath) {
  const page = await connectGemini();
  
  try {
    // Dosya yükleme input'unu bul
    const fileInput = await page.$('input[type="file"]');
    if (!fileInput) throw new Error('Dosya yükleme input bulunamadı');

    // Dosyayı yükle
    await fileInput.uploadFile(filePath);
    console.log(' Dosya Gemini\'ye yüklendi');

    // Yüklemenin tamamlanmasını bekle
    await page.waitForTimeout(3000);
    return true;

  } catch (e) {
    console.error('Dosya yükleme hatası:', e.message);
    throw e;
  }
}

// ─── İçerik Üretim Prompt'u Oluştur ─────────────────────────────────────────
export function generateContentPrompt(channel, topic, maxCandidates = 5) {
  return `Sen YouTube Shorts için yüksek kalite Türkçe içerik üretim motorusun.

KURALLAR:
- JSON dışında HİÇBİR ŞEY döndürme
- İlk cümle (hook) çok güçlü ve merak uyandırıcı olsun
- Başlık ve içerik tam uyumlu olsun
- voiceText 20-35 saniye arasında okunabilir uzunlukta olsun (yaklaşık 60-100 kelime)
- Türkçe dil bilgisi mükemmel olsun
- İnsan gibi, doğal konuşma dili kullan

KANAL BİLGİSİ:
- Kanal Adı: ${channel.name}
- Kategori: ${channel.category}

KONU: ${topic}

${maxCandidates} adet farklı aday üret.

JSON ŞEMASI (kesinlikle bu formatta):
{
  "candidates": [
    {
      "hook": "İlk cümle - çok güçlü merak uyandırıcı",
      "title": "YouTube başlığı (max 70 karakter)",
      "firstFrameText": "Ekranda görünecek kısa metin (max 50 karakter)",
      "voiceText": "Seslendirilecek tam metin (60-100 kelime)",
      "cta": "Sona eklenen harekete geçirici çağrı",
      "thumbnailText": "Thumbnail üstündeki büyük yazı (max 40 karakter, BÜYÜK HARF)",
      "description": "YouTube açıklaması (hashtag dahil)",
      "tags": ["#tag1", "#tag2"],
      "scenePlan": [
        {"sceneType": "intro|body|end", "intent": "hook|explain|cta", "visualQuery": "görsel arama terimi", "durationHint": 5}
      ]
    }
  ]
}`;
}

// ─── Video Viral Analizi Prompt'u ────────────────────────────────────────────
export function generateVideoAnalysisPrompt() {
  return `Bu YouTube Shorts videosunu analiz et ve aşağıdaki sorulara cevap ver:

1. **Viral Potansiyeli (0-100):** Bu video viral olma ihtimali nedir? Neden?

2. **Hook Etkisi:** İlk 3 saniye yeterince güçlü mü? İzleyiciyi çekiyor mu?

3. **Tutma Analizi:** 
   - Hangi saniyede izleyici sıkılmaya başlayabilir?
   - Hangi bölümler en ilgi çekici?
   - Hangi bölümler kesilebilir?

4. **Thumbnail & Başlık:** Başlık ve görsel merak uyandırıyor mu?

5. **CTA (Call-to-Action):** Son mesaj yeterince güçlü mü?

6. **İyileştirme Önerileri:** 
   - Neleri değiştirmeliyiz?
   - Hangi kısımlar daha uzun olmalı?
   - Hangi kısımlar daha kısa olmalı?

7. **Hedef Kitle:** Bu video hangi yaş grubu/demografiye hitap ediyor?

8. **Psikolojik Tetikleyiciler:** Hangi psikolojik mekanizmalar kullanılmış?

Cevaplarını JSON formatında ver:
{
  "viralScore": 0-100,
  "hookStrength": "açıklama",
  "retentionAnalysis": {
    "boringPointSeconds": [3, 15, 28],
    "bestSegments": ["0-5s: hook", "10-15s: açıklama"],
    "improvementAreas": ["5-10s: daha hızlı olmalı"]
  },
  "thumbnailTitleScore": 0-100,
  "ctaStrength": "açıklama",
  "improvements": ["öneri 1", "öneri 2"],
  "targetAudience": "yaş ve demografik",
  "psychologicalTriggers": ["tetikleyici 1", "tetikleyici 2"],
  "finalRecommendation": "genel tavsiye"
}`;
}

// ─── İçerik Üretim (ChatGPT/Gemini aracılığıyla) ──────────────────────────
export async function generateContentViaAI(channel, topic, aiService = 'gemini') {
  try {
    const prompt = generateContentPrompt(channel, topic);
    let response;

    if (aiService === 'chatgpt') {
      response = await sendMessageToChatGPT(prompt);
    } else {
      response = await sendMessageToGemini(prompt);
    }

    // JSON'ı çıkart
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('JSON bulunamadı');

    const data = JSON.parse(jsonMatch[0]);
    const candidates = (data.candidates || []).map(c => ({
      id: `cand_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
      ...c,
    }));

    console.log(` ${candidates.length} aday üretildi`);
    return candidates;

  } catch (e) {
    console.error('İçerik üretim hatası:', e.message);
    throw e;
  }
}

// ─── Video Analizi (ChatGPT/Gemini aracılığıyla) ──────────────────────────
export async function analyzeVideoViaAI(videoPath, aiService = 'gemini') {
  try {
    const prompt = generateVideoAnalysisPrompt();
    let response;

    if (aiService === 'chatgpt') {
      // ChatGPT'ye dosya yükleme daha karmaşık, şimdilik sadece prompt gönder
      const msg = `Lütfen aşağıdaki analiz yapabilmem için video yükleme özelliğini kullan.\n\n${prompt}`;
      response = await sendMessageToChatGPT(msg);
    } else {
      // Gemini'ye dosya yükle
      await uploadFileToGemini(videoPath);
      response = await sendMessageToGemini(prompt);
    }

    // JSON'ı çıkart
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Analiz JSON bulunamadı');

    const analysis = JSON.parse(jsonMatch[0]);
    console.log(' Video analizi tamamlandı');
    return analysis;

  } catch (e) {
    console.error('Video analizi hatası:', e.message);
    throw e;
  }
}

// ─── Tarayıcı Durumu Kontrol ────────────────────────────────────────────────
export async function getBrowserStatus() {
  return {
    browserActive: !!browser,
    chatgptConnected: !!chatgptPage,
    geminiConnected: !!geminiPage,
  };
}

// ─── Tarayıcı Sayfasını Aç (Manuel Giriş için) ──────────────────────────────
export async function openBrowserForManualLogin(service = 'gemini') {
  const b = await initBrowser();
  const page = await b.newPage();
  
  const url = service === 'chatgpt' ? 'https://chatgpt.com' : 'https://gemini.google.com';
  await page.goto(url, { waitUntil: 'networkidle2' });
  
  console.log(` Tarayıcı açıldı: ${url}`);
  console.log('  Lütfen manuel olarak giriş yapın ve sistem devam edecektir.');
  
  if (service === 'chatgpt') {
    chatgptPage = page;
  } else {
    geminiPage = page;
  }

  return page;
}
