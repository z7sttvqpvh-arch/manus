/**
 * Safety Guard — Politika Denetçisi
 * ==================================
 * Videoları "Shadow Ban" ve platform kısıtlamalarına karşı koruma
 * - Yasaklı kelime tespiti
 * - Telif hakkı riski analizi
 * - Topluluk kuralları uygunluğu
 * - Hassas içerik uyarıları
 */

// ─── Yasaklı Kelimeler (YouTube/TikTok) ──────────────────────────────────────
const BANNED_KEYWORDS = {
  high_risk: [
    'ölüm', 'intihar', 'uyuşturucu', 'haram', 'terör', 'şiddet', 'cinsel istismar',
    'pedofili', 'tecavüz', 'bomba', 'silah', 'katliam', 'nefret', 'ırkçılık',
    'ayrımcılık', 'kötüye kullanım', 'spam', 'dolandırıcılık', 'sahte',
  ],
  medium_risk: [
    'alkol', 'sigara', 'kumar', 'borç', 'yoksulluk', 'hastalık', 'cerrahi',
    'kan', 'yaralanma', 'acı', 'korku', 'fobia', 'paranoia', 'psikoz',
  ],
  low_risk: [
    'seks', 'çıplak', 'iç çamaşırı', 'masöz', 'masaj', 'fantezi', 'rol oynama',
  ],
};

// ─── Telif Hakkı Riski Kelimeleri ────────────────────────────────────────────
const COPYRIGHT_RISK_KEYWORDS = [
  'müzik', 'şarkı', 'film', 'dizi', 'oyuncu', 'yönetmen', 'prodüktör',
  'lisanslı', 'resmi', 'orijinal', 'cover', 'remix', 'parodi',
];

// ─── Hassas Konular ─────────────────────────────────────────────────────────
const SENSITIVE_TOPICS = [
  'din', 'siyaset', 'seçim', 'hükümet', 'devlet', 'asker', 'polis',
  'mahkeme', 'avukat', 'hukuk', 'vergi', 'gümrük', 'sınır',
];

// ─── Metin Analizi (Yasaklı Kelimeler) ──────────────────────────────────────
export function analyzeTextForBannedWords(text) {
  const lowerText = text.toLowerCase();
  const results = {
    high_risk: [],
    medium_risk: [],
    low_risk: [],
    totalRiskScore: 0,
  };

  // High Risk
  for (const word of BANNED_KEYWORDS.high_risk) {
    if (lowerText.includes(word)) {
      results.high_risk.push(word);
      results.totalRiskScore += 30;
    }
  }

  // Medium Risk
  for (const word of BANNED_KEYWORDS.medium_risk) {
    if (lowerText.includes(word)) {
      results.medium_risk.push(word);
      results.totalRiskScore += 15;
    }
  }

  // Low Risk
  for (const word of BANNED_KEYWORDS.low_risk) {
    if (lowerText.includes(word)) {
      results.low_risk.push(word);
      results.totalRiskScore += 5;
    }
  }

  return results;
}

// ─── Telif Hakkı Riski Analizi ──────────────────────────────────────────────
export function analyzeCopyrightRisk(text) {
  const lowerText = text.toLowerCase();
  const riskKeywords = [];
  let copyrightRiskScore = 0;

  for (const keyword of COPYRIGHT_RISK_KEYWORDS) {
    if (lowerText.includes(keyword)) {
      riskKeywords.push(keyword);
      copyrightRiskScore += 10;
    }
  }

  return {
    riskKeywords,
    copyrightRiskScore: Math.min(100, copyrightRiskScore),
    hasCopyrightRisk: copyrightRiskScore > 30,
    advice: copyrightRiskScore > 30 
      ? 'Telif hakkı riski yüksek. Orijinal içerik kullanmaya dikkat et.'
      : 'Telif hakkı riski düşük.',
  };
}

// ─── Hassas Konu Tespiti ────────────────────────────────────────────────────
export function detectSensitiveTopics(text) {
  const lowerText = text.toLowerCase();
  const detectedTopics = [];

  for (const topic of SENSITIVE_TOPICS) {
    if (lowerText.includes(topic)) {
      detectedTopics.push(topic);
    }
  }

  return {
    detectedTopics,
    hasSensitiveContent: detectedTopics.length > 0,
    advice: detectedTopics.length > 0
      ? `Hassas konular tespit edildi: ${detectedTopics.join(', ')}. Tarafsız ve bilgilendirici tonda kalınız.`
      : 'Hassas konu tespit edilmedi.',
  };
}

// ─── Genel Güvenlik Raporu ──────────────────────────────────────────────────
export function generateSafetyReport(text) {
  const bannedWords = analyzeTextForBannedWords(text);
  const copyright = analyzeCopyrightRisk(text);
  const sensitive = detectSensitiveTopics(text);

  const totalRiskScore = bannedWords.totalRiskScore + copyright.copyrightRiskScore;
  const shadowBanRisk = totalRiskScore > 50 ? 'HIGH' : totalRiskScore > 25 ? 'MEDIUM' : 'LOW';

  return {
    timestamp: new Date().toISOString(),
    textLength: text.length,
    bannedWords,
    copyright,
    sensitive,
    totalRiskScore: Math.min(100, totalRiskScore),
    shadowBanRisk,
    recommendation: getSafetyRecommendation(shadowBanRisk, bannedWords, copyright, sensitive),
    canPublish: shadowBanRisk === 'LOW' && bannedWords.high_risk.length === 0,
  };
}

// ─── Güvenlik Önerisi ───────────────────────────────────────────────────────
function getSafetyRecommendation(riskLevel, banned, copyright, sensitive) {
  const recommendations = [];

  if (riskLevel === 'HIGH') {
    recommendations.push('YÜKSEK RİSK: Bu video Shadow Ban yeme riski taşıyor.');
  } else if (riskLevel === 'MEDIUM') {
    recommendations.push('ORTA RİSK: Bazı kısıtlamalar yaşayabilirsiniz.');
  } else {
    recommendations.push(' DÜŞÜK RİSK: Yayınlanmaya hazır.');
  }

  if (banned.high_risk.length > 0) {
    recommendations.push(` Yasaklı kelimeler: ${banned.high_risk.join(', ')}`);
  }

  if (banned.medium_risk.length > 0) {
    recommendations.push(`' Riskli kelimeler: ${banned.medium_risk.join(', ')}`);
  }

  if (copyright.hasCopyrightRisk) {
    recommendations.push(`📜 ${copyright.advice}`);
  }

  if (sensitive.hasSensitiveContent) {
    recommendations.push(`🔒 ${sensitive.advice}`);
  }

  return recommendations;
}

// ─── Metin Düzeltme Önerisi ─────────────────────────────────────────────────
export function suggestTextFixes(text) {
  const fixes = [];
  const lowerText = text.toLowerCase();

  // Yasaklı kelimeleri değiştir
  for (const word of BANNED_KEYWORDS.high_risk) {
    if (lowerText.includes(word)) {
      const replacement = getAlternativeWord(word);
      fixes.push({
        original: word,
        replacement,
        reason: 'Yasaklı kelime',
      });
    }
  }

  return fixes;
}

// ─── Alternatif Kelime Önerisi ──────────────────────────────────────────────
function getAlternativeWord(word) {
  const alternatives = {
    'ölüm': 'son',
    'intihar': 'kendi hayatını bitirmek',
    'uyuşturucu': 'madde',
    'haram': 'yasak',
    'terör': 'şiddet eylemi',
    'şiddet': 'agresif davranış',
    'cinsel istismar': 'kötüye kullanım',
    'pedofili': 'çocuk istismarı',
    'tecavüz': 'cinsel saldırı',
    'bomba': 'patlayıcı',
    'silah': 'alet',
    'katliam': 'toplu ölüm',
    'nefret': 'olumsuz duygu',
    'ırkçılık': 'ayrımcılık',
    'ayrımcılık': 'eşitsiz muamele',
    'kötüye kullanım': 'yanlış kullanım',
    'spam': 'tekrarlayan içerik',
    'dolandırıcılık': 'aldatma',
    'sahte': 'gerçek olmayan',
  };

  return alternatives[word] || word;
}

// ─── Gemini'ye Gönderilecek Güvenlik Sorusu ──────────────────────────────────
export function generateSafetyCheckPrompt(text, category) {
  return `Aşağıdaki video açıklaması ve başlığı, YouTube/TikTok topluluk kurallarına uygun mu? 
  
Kategori: ${category}
Metin: "${text}"

Kontrol et:
1. Yasaklı içerik (şiddet, uyuşturuç, cinsel içerik vb.) var mı?
2. Telif hakkı ihlali riski var mı?
3. Nefret söylemi veya ayrımcılık var mı?
4. Yanıltıcı veya sahte bilgi var mı?

Cevap JSON formatında:
{
  "isSafe": true/false,
  "risks": ["risk1", "risk2"],
  "suggestions": ["öneri1", "öneri2"],
  "shadowBanRisk": "LOW/MEDIUM/HIGH"
}

JSON dışında HİÇBİR ŞEY yazma.`;
}

// ─── Güvenlik Skoru Hesapla ─────────────────────────────────────────────────
export function calculateSafetyScore(report) {
  let score = 100;

  // Yasaklı kelimeler
  score -= report.bannedWords.high_risk.length * 20;
  score -= report.bannedWords.medium_risk.length * 10;
  score -= report.bannedWords.low_risk.length * 5;

  // Telif hakkı riski
  if (report.copyright.hasCopyrightRisk) {
    score -= 15;
  }

  // Hassas konular
  if (report.sensitive.hasSensitiveContent) {
    score -= report.sensitive.detectedTopics.length * 5;
  }

  return Math.max(0, score);
}
