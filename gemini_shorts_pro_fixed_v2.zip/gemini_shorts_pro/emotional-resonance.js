/**
 * Emotional Resonance Engine — Duygusal Rezonans Motoru
 * ======================================================
 * İçeriğin izleyicide uyandıracağı duyguları analiz eder
 * - Duygusal Tetikleyicileri (Triggers) tespit eder
 * - Duygusal Yoğunluk Skoru hesaplar
 * - İçeriği "Duygusal Frekans" modunda yeniden yazar
 */

// ─── Duygusal Tetikleyiciler (Emotional Triggers) ──────────────────────────
const EMOTIONAL_TRIGGERS = {
  curiosity: {
    name: 'Merak (Curiosity)',
    keywords: ['neden', 'nasıl', 'bilmiyorsun', 'gizli', 'sırrı', 'ortaya çıktı', 'açıklandı', 'keşfet'],
    weight: 0.25,
    intensity: 'medium',
  },
  fear: {
    name: 'Korku (Fear)',
    keywords: ['uyarı', 'tehlike', 'dikkat', 'hata yapma', 'kaybet', 'başarısız', 'riskli', 'öldürücü'],
    weight: 0.30,
    intensity: 'high',
  },
  relief: {
    name: 'Rahatlama (Relief)',
    keywords: ['çözüm', 'basit', 'kolay', 'hızlı', 'etkili', 'kanıtlanmış', 'garanti', 'başarılı'],
    weight: 0.20,
    intensity: 'low',
  },
  shock: {
    name: 'Şaşkınlık (Shock)',
    keywords: ['inanılmaz', 'şaşırtıcı', 'hiç beklemiyordum', 'çılgın', 'imkansız', 'gerçek mi', 'doğru mu'],
    weight: 0.15,
    intensity: 'high',
  },
  aspiration: {
    name: 'Özlem (Aspiration)',
    keywords: ['başarı', 'zengin', 'güzel', 'mutlu', 'özgür', 'güçlü', 'başarılı', 'harika'],
    weight: 0.10,
    intensity: 'medium',
  },
};

// ─── Duygusal Tetikleyici Tespiti ───────────────────────────────────────────
export function detectEmotionalTriggers(text) {
  const lowerText = text.toLowerCase();
  const triggers = {};
  let totalScore = 0;

  for (const [triggerType, triggerData] of Object.entries(EMOTIONAL_TRIGGERS)) {
    let count = 0;
    for (const keyword of triggerData.keywords) {
      const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
      const matches = text.match(regex);
      if (matches) count += matches.length;
    }

    if (count > 0) {
      triggers[triggerType] = {
        name: triggerData.name,
        count,
        weight: triggerData.weight,
        intensity: triggerData.intensity,
        score: count * triggerData.weight * 10,
      };
      totalScore += triggers[triggerType].score;
    }
  }

  return {
    triggers,
    totalEmotionalScore: Math.min(100, totalScore),
    dominantEmotion: Object.entries(triggers).length > 0
      ? Object.entries(triggers).sort((a, b) => b[1].score - a[1].score)[0][0]
      : null,
  };
}

// ─── Duygusal Denge Analizi ─────────────────────────────────────────────────
export function analyzeEmotionalBalance(triggers) {
  const balance = {
    curiosity: triggers.curiosity?.score || 0,
    fear: triggers.fear?.score || 0,
    relief: triggers.relief?.score || 0,
    shock: triggers.shock?.score || 0,
    aspiration: triggers.aspiration?.score || 0,
  };

  const total = Object.values(balance).reduce((a, b) => a + b, 0);
  const normalized = Object.entries(balance).reduce((acc, [key, val]) => {
    acc[key] = total > 0 ? Math.round((val / total) * 100) : 0;
    return acc;
  }, {});

  return {
    raw: balance,
    normalized,
    recommendation: generateEmotionalRecommendation(normalized),
  };
}

// ─── Duygusal Denge Önerisi ─────────────────────────────────────────────────
function generateEmotionalRecommendation(normalized) {
  const recommendations = [];

  if (normalized.curiosity < 20) {
    recommendations.push('• Merak uyandırıcı unsurlar ekle (soru, gizem)');
  }
  if (normalized.fear < 15) {
    recommendations.push('• Uyarı veya tehlike unsurları ekle');
  }
  if (normalized.relief < 15) {
    recommendations.push('• Çözüm ve rahatlama unsurları ekle');
  }
  if (normalized.shock < 10) {
    recommendations.push('• Şaşırtıcı veya beklenmedik unsurlar ekle');
  }

  return recommendations.length > 0 ? recommendations : ['• Duygusal denge iyi görünüyor'];
}

// ─── Duygusal Yoğunluk Skoru ────────────────────────────────────────────────
export function calculateEmotionalIntensity(triggers) {
  let highIntensityScore = 0;
  let mediumIntensityScore = 0;
  let lowIntensityScore = 0;

  for (const trigger of Object.values(triggers)) {
    if (trigger.intensity === 'high') highIntensityScore += trigger.score;
    else if (trigger.intensity === 'medium') mediumIntensityScore += trigger.score;
    else if (trigger.intensity === 'low') lowIntensityScore += trigger.score;
  }

  const totalIntensity = highIntensityScore * 1.5 + mediumIntensityScore + lowIntensityScore * 0.5;

  return {
    highIntensity: Math.round(highIntensityScore),
    mediumIntensity: Math.round(mediumIntensityScore),
    lowIntensity: Math.round(lowIntensityScore),
    totalIntensity: Math.min(100, Math.round(totalIntensity)),
    level: totalIntensity > 70 ? 'Very High' : totalIntensity > 50 ? 'High' : totalIntensity > 30 ? 'Medium' : 'Low',
  };
}

// ─── Duygusal Rezonans Raporu ───────────────────────────────────────────────
export function generateEmotionalResonanceReport(text) {
  const triggers = detectEmotionalTriggers(text);
  const balance = analyzeEmotionalBalance(triggers.triggers);
  const intensity = calculateEmotionalIntensity(triggers.triggers);

  return {
    timestamp: new Date().toISOString(),
    textLength: text.length,
    triggers: triggers.triggers,
    dominantEmotion: triggers.dominantEmotion,
    emotionalBalance: balance,
    emotionalIntensity: intensity,
    resonanceScore: Math.round((intensity.totalIntensity * 0.6 + triggers.totalEmotionalScore * 0.4)),
    isEmotionallyRich: intensity.totalIntensity > 50,
    recommendations: balance.recommendation,
  };
}

// ─── Gemini'ye Gönderilecek Duygusal Yeniden Yazma Prompt'u ─────────────────
export function generateEmotionalRewritePrompt(text, targetEmotions = {}) {
  const emotionString = Object.entries(targetEmotions)
    .map(([emotion, percent]) => `${emotion}: %${percent}`)
    .join(', ');

  return `Aşağıdaki metni, belirtilen duygusal oranlarla yeniden yaz:

Orijinal Metin: "${text}"

Hedef Duygusal Oranlar:
${emotionString}

Kurallar:
1. Metin uzunluğu aynı kalmalı
2. Anlam değişmemeli, sadece duygusal ton değişmeli
3. Daha etkileyici ve izleyiciyi tutacak şekilde yaz

Yeniden yazılmış metin (SADECE METİN, başka hiçbir şey yazma):`;
}

// ─── Duygusal Isı Haritası (Heatmap) ────────────────────────────────────────
export function generateEmotionalHeatmap(text) {
  const lines = text.split('\n');
  const heatmap = lines.map(line => {
    const triggers = detectEmotionalTriggers(line);
    return {
      line: line.slice(0, 50) + (line.length > 50 ? '...' : ''),
      emotionalScore: triggers.totalEmotionalScore,
      dominantEmotion: triggers.dominantEmotion,
    };
  });

  return {
    heatmap,
    averageScore: Math.round(heatmap.reduce((sum, h) => sum + h.emotionalScore, 0) / heatmap.length),
    peakScore: Math.max(...heatmap.map(h => h.emotionalScore)),
    lowScore: Math.min(...heatmap.map(h => h.emotionalScore)),
  };
}

// ─── Duygusal Uyum Skoru (Emotional Fit) ────────────────────────────────────
export function calculateEmotionalFit(text, category) {
  const categoryEmotions = {
    motivation: { aspiration: 40, relief: 30, curiosity: 20, shock: 10 },
    psychology: { curiosity: 40, fear: 25, relief: 20, shock: 15 },
    health: { relief: 35, fear: 25, aspiration: 25, curiosity: 15 },
    shock: { shock: 50, fear: 30, curiosity: 15, relief: 5 },
    knowledge: { curiosity: 50, relief: 25, aspiration: 15, shock: 10 },
    finance: { aspiration: 40, relief: 30, fear: 20, curiosity: 10 },
  };

  const targetEmotions = categoryEmotions[category] || categoryEmotions.knowledge;
  const report = generateEmotionalResonanceReport(text);
  const balance = report.emotionalBalance.normalized;

  let fitScore = 0;
  for (const [emotion, targetPercent] of Object.entries(targetEmotions)) {
    const actualPercent = balance[emotion] || 0;
    const diff = Math.abs(actualPercent - targetPercent);
    fitScore += Math.max(0, 100 - diff);
  }

  const avgFitScore = fitScore / Object.keys(targetEmotions).length;

  return {
    category,
    targetEmotions,
    actualEmotions: balance,
    fitScore: Math.round(avgFitScore),
    isFit: avgFitScore > 70,
    advice: avgFitScore > 70
      ? ` İçerik ${category} kategorisine duygusal olarak uygun.`
      : `' İçerik ${category} kategorisine duygusal olarak tam uymuyor. Yeniden yazılmasını öner.`,
  };
}
