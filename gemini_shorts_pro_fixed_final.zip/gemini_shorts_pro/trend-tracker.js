/**
 * Trend Tracker - Kategori Odaklı Trend Takibi
 * =============================================
 * Kanalın kategorisine uygun popüler konuları bulup sunuyor
 * - Google Trends benzeri veri kaynakları
 * - Kategori filtrelemesi
 * - Gemini'ye sordurarak doğrulama
 */

import * as browser from './browser-automation.js';

// ─── Kategori Trend Anahtar Kelimeleri ───────────────────────────────────────
const CATEGORY_KEYWORDS = {
  psychology: {
    keywords: ['psikoloji', 'davranış', 'insan', 'zihin', 'bilinç', 'ego', 'manipülasyon', 'ilişki', 'anksiyete', 'depresyon'],
    sources: ['psikoloji', 'davranış bilimi', 'sosyal psikoloji', 'klinik psikoloji'],
    trendTopics: [
      'Neden insanlar aynı hataları tekrar eder',
      'Kendi kendini sabote etme davranışı',
      'İlk izlenim neden bu kadar güçlü',
      'Sosyal medya bağımlılığı',
      'Kişilik bozuklukları',
      'Empati ve sempati farkı',
      'Kaygı bozukluğu belirtileri',
      'Kendine güven nasıl artar',
    ],
  },
  shock: {
    keywords: ['ilginç', 'şaşırtıcı', 'inanılmaz', 'gerçek', 'bilim', 'keşif', 'gizem', 'sır', 'sıradışı'],
    sources: ['bilim', 'keşif', 'teknoloji', 'tarih'],
    trendTopics: [
      'Çoğu kişinin bilmediği zihinsel hata',
      'Bir kararın hayatı nasıl saptırdığı',
      'Kimsenin fark etmediği günlük tuzak',
      'Beyin hakkında bilinmeyen gerçekler',
      'Teknoloji ve insan beyni',
      'Tarihte gizli kalmış olaylar',
      'Bilim insanlarını şaşırtan keşifler',
    ],
  },
  motivation: {
    keywords: ['motivasyon', 'başarı', 'hedef', 'disiplin', 'alışkanlık', 'kişisel gelişim', 'başarısızlık', 'enerji', 'azim'],
    sources: ['kişisel gelişim', 'girişimcilik', 'başarı', 'motivasyon'],
    trendTopics: [
      'Disiplini öldüren görünmez alışkanlık',
      'Ertelemenin arkasındaki gerçek neden',
      'İlerlemeyi durduran küçük hata',
      'Başarılı insanların sabah rutini',
      'Başarısızlıktan öğrenme',
      'Hedef belirleme stratejileri',
      'Motivasyon nasıl sürdürülür',
      'Başarı için gerekli 1 şey',
    ],
  },
  knowledge: {
    keywords: ['bilgi', 'öğrenme', 'eğitim', 'tarih', 'coğrafya', 'kültür', 'sanat', 'felsefe'],
    sources: ['eğitim', 'tarih', 'coğrafya', 'kültür'],
    trendTopics: [
      'Tarihte en ilginç olaylar',
      'Ülkeler hakkında bilinmeyen gerçekler',
      'Sanat ve kültür hakkında',
      'Felsefe ve düşünce',
      'Dil ve iletişim',
      'İnsan medeniyeti',
      'Antik çağ gizemleri',
    ],
  },
  finance: {
    keywords: ['para', 'yatırım', 'finans', 'borsa', 'kripto', 'tasarruf', 'gelir', 'zenginlik', 'ekonomi'],
    sources: ['finans', 'yatırım', 'ekonomi', 'iş'],
    trendTopics: [
      'Para kazanmanın gizli yolları',
      'Zengin insanların alışkanlıkları',
      'Kripto para hakkında gerçekler',
      'Borsa nasıl çalışır',
      'Pasif gelir kaynakları',
      'Tasarruf stratejileri',
      'Finansal özgürlük',
    ],
  },
  health: {
    keywords: ['sağlık', 'beslenme', 'spor', 'fitness', 'yaşam tarzı', 'uyku', 'stres', 'bağışıklık', 'wellness'],
    sources: ['sağlık', 'tıp', 'beslenme', 'spor'],
    trendTopics: [
      'Sağlıklı yaşamın sırları',
      'Beslenme hataları',
      'Uyku kalitesi nasıl artar',
      'Stres yönetimi teknikleri',
      'Egzersiz faydaları',
      'Bağışıklık sistemi güçlendirme',
      'Yaşlanmayı yavaşlatma',
      'Mental sağlık ipuçları',
    ],
  },
};

// ─── Trend Önerisi Oluştur (Kategori Bazlı) ─────────────────────────────────
export function generateCategoryTrends(category, count = 5) {
  const categoryData = CATEGORY_KEYWORDS[category] || CATEGORY_KEYWORDS.psychology;
  const trends = categoryData.trendTopics || [];
  
  // Rastgele seç
  const selected = [];
  for (let i = 0; i < Math.min(count, trends.length); i++) {
    const idx = Math.floor(Math.random() * trends.length);
    if (!selected.includes(trends[idx])) {
      selected.push(trends[idx]);
    }
  }

  return selected.map(trend => ({
    id: `trend_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
    topic: trend,
    category,
    source: 'category_pool',
    confidence: 0.85,
    timestamp: new Date().toISOString(),
  }));
}

// ─── Trend Doğrulama (Gemini'ye Sor) ──────────────────────────────────────────
export async function validateTrendWithGemini(trend, category) {
  const prompt = `Aşağıdaki konu, "${category}" kategorisine uygun mu? Cevap sadece "evet" veya "hayır" olsun.

Konu: "${trend}"
Kategori: "${category}"

Cevap (sadece "evet" veya "hayır"):`;

  try {
    const response = await browser.sendMessageToGemini(prompt);
    const isValid = response.toLowerCase().includes('evet');
    return { valid: isValid, response };
  } catch (e) {
    console.error('Trend doğrulama hatası:', e.message);
    return { valid: true, response: 'Hata nedeniyle varsayılan olarak geçerli kabul edildi' };
  }
}

// ─── Trend Çeşitlendirme (Aynı Konuyu Tekrar Önlemek) ────────────────────────
export function diversifyTrends(trends, recentTopics = []) {
  // Son 50 konuyu filtrele
  const recentSet = new Set(recentTopics.slice(0, 50));
  const filtered = trends.filter(t => !recentSet.has(t.topic));

  if (filtered.length === 0) {
    console.warn('Tüm trendler son konularla eşleşti, tüm trendleri döndürüyorum');
    return trends;
  }

  return filtered;
}

// ─── Trend Puanlaması (Popülarite ve Relevans) ────────────────────────────────
export function scoreTrend(trend, category) {
  const categoryData = CATEGORY_KEYWORDS[category] || CATEGORY_KEYWORDS.psychology;
  
  // Anahtar kelime eşleştirmesi
  const keywordMatch = categoryData.keywords.filter(kw => 
    trend.topic.toLowerCase().includes(kw)
  ).length;

  const keywordScore = Math.min(100, keywordMatch * 15);
  const relevanceScore = trend.confidence ? trend.confidence * 100 : 80;
  const recencyScore = 90; // Varsayılan olarak yeni trendler yüksek skor alır

  const finalScore = Math.round((keywordScore * 0.3 + relevanceScore * 0.4 + recencyScore * 0.3));

  return {
    topic: trend.topic,
    keywordScore,
    relevanceScore,
    recencyScore,
    finalScore,
  };
}

// ─── En İyi Trend'i Seç ──────────────────────────────────────────────────────
export function selectBestTrend(trends, category, recentTopics = []) {
  // Çeşitlendirme
  const diversified = diversifyTrends(trends, recentTopics);

  // Puanlama
  const scored = diversified.map(t => ({
    ...t,
    score: scoreTrend(t, category),
  }));

  // En yüksek puan alan trend'i seç
  const best = scored.reduce((prev, current) => 
    (prev.score.finalScore > current.score.finalScore) ? prev : current
  );

  return best;
}

// ─── Trend Önerisi Raporu ────────────────────────────────────────────────────
export function createTrendReport(trends, selectedTrend, category) {
  return {
    timestamp: new Date().toISOString(),
    category,
    totalTrends: trends.length,
    selectedTrend: selectedTrend.topic,
    selectedScore: selectedTrend.score.finalScore,
    allTrends: trends.map(t => ({
      topic: t.topic,
      score: scoreTrend(t, category).finalScore,
    })),
    recommendation: `"${selectedTrend.topic}" konusu ${category} kategorisi için en uygun trend.`,
  };
}

// ─── Trend Takibi Prompt'u (Gemini'ye Sordurma) ──────────────────────────────
export function generateTrendPrompt(category, count = 5) {
  const categoryData = CATEGORY_KEYWORDS[category] || CATEGORY_KEYWORDS.psychology;
  
  return `${category.toUpperCase()} kategorisinde şu anda popüler olan ${count} adet konu/trend öner.

Kategori açıklaması: ${categoryData.sources.join(', ')}

Öneriler şu JSON formatında olsun:
{
  "trends": [
    {"topic": "Konu 1", "reason": "Neden popüler", "relevance": 0-100},
    {"topic": "Konu 2", "reason": "Neden popüler", "relevance": 0-100}
  ]
}

JSON dışında HİÇBİR ŞEY yazma.`;
}

// ─── Gemini'den Trend Önerisi Al ─────────────────────────────────────────────
export async function getTrendsFromGemini(category, count = 5) {
  try {
    const prompt = generateTrendPrompt(category, count);
    const response = await browser.sendMessageToGemini(prompt);

    // JSON'ı çıkart
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Trend JSON bulunamadı');

    const data = JSON.parse(jsonMatch[0]);
    const trends = (data.trends || []).map(t => ({
      id: `trend_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
      topic: t.topic,
      reason: t.reason,
      relevance: t.relevance || 80,
      category,
      source: 'gemini',
      timestamp: new Date().toISOString(),
    }));

    console.log(` Gemini'den ${trends.length} trend alındı`);
    return trends;

  } catch (e) {
    console.error('Gemini trend hatası:', e.message);
    // Fallback: kategori havuzundan seç
    return generateCategoryTrends(category, count);
  }
}

// ─── Haftalık Trend Raporu ──────────────────────────────────────────────────
export function generateWeeklyTrendReport(trends, category) {
  const grouped = {};
  
  for (const trend of trends) {
    const week = Math.floor((Date.now() - new Date(trend.timestamp).getTime()) / (7 * 24 * 60 * 60 * 1000));
    if (!grouped[week]) grouped[week] = [];
    grouped[week].push(trend);
  }

  return {
    category,
    reportDate: new Date().toISOString(),
    weeklyBreakdown: Object.entries(grouped).map(([week, weekTrends]) => ({
      week: parseInt(week),
      count: weekTrends.length,
      topTrend: weekTrends[0]?.topic,
    })),
    totalTrends: trends.length,
  };
}
