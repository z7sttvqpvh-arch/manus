/**
 * Video Review Engine - Video İnceleme Motoru
 * ============================================
 * Render edilen videoyu Gemini'ye gönderip saniye saniye analiz eder
 * - Viral skoru hesaplar
 * - İlk 2 saniye gücünü değerlendirir
 * - Sıkıcı bölümleri (boring segments) tespit eder
 * - Tempo düşüşlerini işaretler
 * - Publish / Repair / Reject kararı verir
 */

import * as browser from './browser-automation.js';

// ─── Video Review Prompt ────────────────────────────────────────────────────
export function generateVideoReviewPrompt() {
  return `YouTube Shorts videosunu SANIYE SANIYE analiz et. 
Aşağıdaki JSON formatında KESINLIKLE bu şemayı kullan:

{
  "viral_score": 0-100,
  "hook_strength": 0-100,
  "first_2s_score": 0-100,
  "boring_segments": [
    {"start_sec": 3, "end_sec": 7, "reason": "açıklama çok yavaş", "severity": "medium"},
    {"start_sec": 15, "end_sec": 18, "reason": "tekrar eden sahne", "severity": "high"}
  ],
  "drop_risk_reasons": ["İlk 3 saniye yeterince güçlü değil", "Orta bölüm monoton"],
  "pacing_issues": [
    {"segment": "0-5s", "issue": "çok hızlı", "fix": "biraz yavaşlat"},
    {"segment": "10-15s", "issue": "çok yavaş", "fix": "hızlandır"}
  ],
  "hook_analysis": {
    "effective": true,
    "strength": "Merak uyandırıcı açılış",
    "improvement": "Daha keskin olabilir"
  },
  "scene_quality": [
    {"scene": "intro", "score": 85, "note": "Güçlü açılış"},
    {"scene": "body", "score": 72, "note": "Biraz monoton"},
    {"scene": "cta", "score": 88, "note": "Etkili kapanış"}
  ],
  "rewrite_advice": [
    "Hook'u daha keskin yap",
    "Orta bölümde daha fazla görsel değişim ekle",
    "CTA'yı daha acil hale getir"
  ],
  "reedit_advice": [
    "3-7 saniye arası 2 saniye kırp",
    "15-18 saniye arası hızlandır",
    "Müzik temposu arttır",
    "Altyazı pacing'i sıkılaştır"
  ],
  "decision": "publish|repair|reject",
  "decision_reason": "Açıklama",
  "repair_priority": ["hook", "pacing", "boring_segments"],
  "estimated_repair_time_sec": 10
}

KURALLAR:
- JSON dışında HİÇBİR ŞEY döndürme
- viral_score >= 80 ve kritik sorun yoksa → "publish"
- 65-79 arasıysa → "repair"
- < 65 ise → "reject"
- boring_segments'de SANIYE ARALIKLARI kesinlikle doğru olmalı
- drop_risk_reasons'da somut nedenler ver
- reedit_advice'da FFmpeg ile yapılabilecek şeyler yaz`;
}

// ─── Video Review (Gemini'ye Gönder ve Analiz Al) ──────────────────────────
export async function reviewVideoWithGemini(videoPath) {
  try {
    console.log(`📹 Video inceleniyor: ${videoPath}`);

    // Videoyu Gemini'ye yükle
    await browser.uploadFileToGemini(videoPath);
    console.log('Video Gemini\'ye yüklendi');

    // Analiz prompt'unu gönder
    const prompt = generateVideoReviewPrompt();
    const response = await browser.sendMessageToGemini(prompt);

    // JSON'ı çıkart
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Review JSON bulunamadı');

    const review = JSON.parse(jsonMatch[0]);
    
    // Validasyon
    validateReview(review);
    
    console.log(` Video incelendi | Skor: ${review.viral_score} | Karar: ${review.decision}`);
    return review;

  } catch (e) {
    console.error('Video review hatası:', e.message);
    throw e;
  }
}

// ─── Review Validasyonu ─────────────────────────────────────────────────────
function validateReview(review) {
  if (typeof review.viral_score !== 'number' || review.viral_score < 0 || review.viral_score > 100) {
    throw new Error('viral_score 0-100 arasında olmalı');
  }
  if (!['publish', 'repair', 'reject'].includes(review.decision)) {
    throw new Error('decision publish/repair/reject olmalı');
  }
  if (!Array.isArray(review.boring_segments)) {
    throw new Error('boring_segments array olmalı');
  }
  for (const seg of review.boring_segments) {
    if (typeof seg.start_sec !== 'number' || typeof seg.end_sec !== 'number') {
      throw new Error('boring_segments saniye aralıkları number olmalı');
    }
    if (seg.end_sec <= seg.start_sec) {
      throw new Error('end_sec > start_sec olmalı');
    }
  }
}

// ─── Karar Mantığı ──────────────────────────────────────────────────────────
export function makeDecision(review) {
  const { viral_score, decision, boring_segments, drop_risk_reasons } = review;

  // Karar ağacı
  if (decision === 'publish' && viral_score >= 80) {
    return {
      action: 'publish',
      reason: 'Skor yeterli ve kritik sorun yok',
      confidence: 'high',
    };
  }

  if (decision === 'repair' || (65 <= viral_score && viral_score < 80)) {
    return {
      action: 'repair',
      reason: `Skor ${viral_score} - Onarım gerekli`,
      priority: review.repair_priority || ['hook', 'pacing', 'boring_segments'],
      confidence: 'medium',
    };
  }

  if (decision === 'reject' || viral_score < 65) {
    return {
      action: 'reject',
      reason: `Skor ${viral_score} - Yeniden üretim gerekli`,
      confidence: 'high',
    };
  }

  // Default
  return {
    action: 'repair',
    reason: 'Belirsiz durum - Onarım dene',
    confidence: 'low',
  };
}

// ─── Review Raporu Oluştur ──────────────────────────────────────────────────
export function createReviewReport(review, decision) {
  return {
    timestamp: new Date().toISOString(),
    scores: {
      viral: review.viral_score,
      hook: review.hook_strength,
      first_2s: review.first_2s_score,
    },
    boringSegments: review.boring_segments,
    dropRisks: review.drop_risk_reasons,
    pacingIssues: review.pacing_issues || [],
    hookAnalysis: review.hook_analysis,
    sceneQuality: review.scene_quality || [],
    rewriteAdvice: review.rewrite_advice || [],
    reeditAdvice: review.reedit_advice || [],
    decision: decision.action,
    decisionReason: decision.reason,
    decisionConfidence: decision.confidence,
    repairPriority: decision.priority || [],
    estimatedRepairTime: review.estimated_repair_time_sec || 0,
  };
}

// ─── Sıkıcı Bölümleri Kırp (FFmpeg) ─────────────────────────────────────────
export async function trimBoringSegments(inputVideo, boringSegments, duration) {
  if (!boringSegments || boringSegments.length === 0) {
    return { trimmed: false, reason: 'Kırpılacak bölüm yok' };
  }

  // Kırpılacak bölümleri sırala
  const toTrim = boringSegments
    .filter(s => s.severity === 'high' || s.severity === 'medium')
    .sort((a, b) => a.start_sec - b.start_sec);

  if (toTrim.length === 0) {
    return { trimmed: false, reason: 'Yüksek öncelikli kırpılacak bölüm yok' };
  }

  // İlk yüksek öncelikli bölümü kırp
  const seg = toTrim[0];
  const trimAmount = seg.end_sec - seg.start_sec;
  
  console.log(`✂ Kırpılıyor: ${seg.start_sec}s-${seg.end_sec}s (${trimAmount}s, neden: ${seg.reason})`);

  // FFmpeg ile kırp (basit yaklaşım: concat filter)
  const part1End = seg.start_sec;
  const part2Start = seg.end_sec;

  // Daha karmaşık kırpma için FFmpeg concat filter kullanılabilir
  // Şimdilik basit bir uyarı döndür
  return {
    trimmed: true,
    segment: seg,
    trimAmount,
    newDuration: duration - trimAmount,
    ffmpegCommand: `ffmpeg -i input.mp4 -vf "select='not(between(t,${part1End},${part2Start}))',setpts=N/FRAME_RATE/TB" -af "aselect='not(between(t,${part1End},${part2Start}))',asetpts=N/SR/TB" output.mp4`,
  };
}

// ─── Altyazı Hızını Sıkılaştır ──────────────────────────────────────────────
export function suggestCaptionPacingFix(pacingIssues) {
  const fixes = [];
  
  for (const issue of pacingIssues || []) {
    if (issue.issue === 'çok yavaş') {
      fixes.push({
        segment: issue.segment,
        action: 'speed_up_captions',
        factor: 1.2, // %20 hızlandır
        reason: issue.fix,
      });
    } else if (issue.issue === 'çok hızlı') {
      fixes.push({
        segment: issue.segment,
        action: 'slow_down_captions',
        factor: 0.85, // %15 yavaşlat
        reason: issue.fix,
      });
    }
  }

  return fixes;
}

// ─── Hook Güçlendirme Önerisi ───────────────────────────────────────────────
export function suggestHookReinforcement(hookAnalysis, rewriteAdvice) {
  if (!hookAnalysis || hookAnalysis.effective) {
    return null;
  }

  return {
    action: 'reinforce_hook',
    currentStrength: hookAnalysis.strength,
    suggestedImprovement: hookAnalysis.improvement,
    rewriteAdvice: rewriteAdvice.filter(a => a.toLowerCase().includes('hook')),
    priority: 'high',
  };
}

// ─── Onarım Planı Oluştur ───────────────────────────────────────────────────
export function createRepairPlan(review, decision) {
  const plan = {
    steps: [],
    estimatedTime: 0,
  };

  const priority = decision.priority || [];

  // 1. Hook güçlendirme
  if (priority.includes('hook')) {
    const hookFix = suggestHookReinforcement(review.hook_analysis, review.rewrite_advice);
    if (hookFix) {
      plan.steps.push({
        order: 1,
        type: 'rewrite_hook',
        ...hookFix,
        estimatedTime: 5,
      });
      plan.estimatedTime += 5;
    }
  }

  // 2. Sıkıcı bölümleri kırp
  if (priority.includes('boring_segments') && review.boring_segments.length > 0) {
    plan.steps.push({
      order: 2,
      type: 'trim_boring_segments',
      segments: review.boring_segments.filter(s => s.severity === 'high'),
      estimatedTime: 10,
    });
    plan.estimatedTime += 10;
  }

  // 3. Pacing düzelt
  if (priority.includes('pacing') && review.pacing_issues && review.pacing_issues.length > 0) {
    plan.steps.push({
      order: 3,
      type: 'fix_pacing',
      issues: review.pacing_issues,
      estimatedTime: 8,
    });
    plan.estimatedTime += 8;
  }

  // 4. Altyazı hızını sıkılaştır
  if (review.reedit_advice && review.reedit_advice.some(a => a.includes('altyazı'))) {
    plan.steps.push({
      order: 4,
      type: 'adjust_caption_pacing',
      advice: review.reedit_advice.filter(a => a.includes('altyazı')),
      estimatedTime: 5,
    });
    plan.estimatedTime += 5;
  }

  // 5. Yeniden render
  plan.steps.push({
    order: plan.steps.length + 1,
    type: 'rerender_video',
    estimatedTime: 15,
  });
  plan.estimatedTime += 15;

  // 6. Yeniden inceleme
  plan.steps.push({
    order: plan.steps.length + 1,
    type: 'review_again',
    estimatedTime: 30,
  });
  plan.estimatedTime += 30;

  return plan;
}

// ─── Onarım Durumu Takip ────────────────────────────────────────────────────
export class RepairTracker {
  constructor(jobId) {
    this.jobId = jobId;
    this.attempts = 0;
    this.maxAttempts = 3;
    this.history = [];
  }

  addAttempt(review, decision, repairPlan) {
    this.attempts++;
    this.history.push({
      attempt: this.attempts,
      timestamp: new Date().toISOString(),
      review,
      decision,
      repairPlan,
    });
  }

  canRepairAgain() {
    return this.attempts < this.maxAttempts;
  }

  getHistory() {
    return this.history;
  }

  getSummary() {
    const scores = this.history.map(h => h.review.viral_score);
    return {
      totalAttempts: this.attempts,
      maxAttempts: this.maxAttempts,
      canRepairAgain: this.canRepairAgain(),
      scoreProgression: scores,
      finalScore: scores[scores.length - 1] || 0,
      improvements: scores.length > 1 ? scores[scores.length - 1] - scores[0] : 0,
    };
  }
}
