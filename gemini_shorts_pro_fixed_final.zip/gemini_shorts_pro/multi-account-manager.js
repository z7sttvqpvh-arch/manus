/**
 * Multi-Account Manager - Çoklu Hesap Yöneticisi
 * ================================================
 * Her kanal için izole tarayıcı profilleri ve güvenli geçiş yönetimi
 */

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// ─── Profil Yönetimi ────────────────────────────────────────────────────────
export class MultiAccountManager {
  constructor(baseDataPath = './data/profiles') {
    this.baseDataPath = baseDataPath;
    this.ensureProfilesDirectory();
  }

  // Profiller klasörünü oluştur
  ensureProfilesDirectory() {
    if (!fs.existsSync(this.baseDataPath)) {
      fs.mkdirSync(this.baseDataPath, { recursive: true });
    }
  }

  // Kanal için izole profil oluştur
  createChannelProfile(channelId, channelName, gmailAccount) {
    const profilePath = path.join(this.baseDataPath, channelId);
    
    if (!fs.existsSync(profilePath)) {
      fs.mkdirSync(profilePath, { recursive: true });
    }

    const profileConfig = {
      channelId,
      channelName,
      gmailAccount,
      createdAt: new Date().toISOString(),
      lastUsed: null,
      browserFingerprint: this.generateBrowserFingerprint(),
      sessionFiles: {
        cookies: path.join(profilePath, 'cookies.json'),
        localStorage: path.join(profilePath, 'localStorage.json'),
        sessionStorage: path.join(profilePath, 'sessionStorage.json'),
      },
      status: 'CREATED',
    };

    // Profil yapılandırmasını kaydet
    fs.writeFileSync(
      path.join(profilePath, 'profile.json'),
      JSON.stringify(profileConfig, null, 2)
    );

    return profileConfig;
  }

  // Tarayıcı Parmak İzi (Fingerprint) Oluştur
  generateBrowserFingerprint() {
    const fingerprints = [
      {
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        screenResolution: '1920x1080',
        timezone: 'Europe/Istanbul',
        language: 'tr-TR',
      },
      {
        userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        screenResolution: '1440x900',
        timezone: 'Europe/Istanbul',
        language: 'tr-TR',
      },
      {
        userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        screenResolution: '1680x1050',
        timezone: 'Europe/Istanbul',
        language: 'tr-TR',
      },
    ];

    return fingerprints[Math.floor(Math.random() * fingerprints.length)];
  }

  // Profil Bilgilerini Getir
  getChannelProfile(channelId) {
    const profilePath = path.join(this.baseDataPath, channelId, 'profile.json');
    
    if (!fs.existsSync(profilePath)) {
      return null;
    }

    return JSON.parse(fs.readFileSync(profilePath, 'utf-8'));
  }

  // Tüm Profilleri Listele
  getAllProfiles() {
    if (!fs.existsSync(this.baseDataPath)) {
      return [];
    }

    const profiles = [];
    const channels = fs.readdirSync(this.baseDataPath);

    for (const channel of channels) {
      const profilePath = path.join(this.baseDataPath, channel, 'profile.json');
      if (fs.existsSync(profilePath)) {
        profiles.push(JSON.parse(fs.readFileSync(profilePath, 'utf-8')));
      }
    }

    return profiles;
  }

  // Profil Durumunu Güncelle
  updateProfileStatus(channelId, status, lastUsed = true) {
    const profile = this.getChannelProfile(channelId);
    if (!profile) return null;

    profile.status = status;
    if (lastUsed) {
      profile.lastUsed = new Date().toISOString();
    }

    const profilePath = path.join(this.baseDataPath, channelId, 'profile.json');
    fs.writeFileSync(profilePath, JSON.stringify(profile, null, 2));

    return profile;
  }

  // Oturum Dosyasını Kaydet
  saveSessionData(channelId, sessionType, data) {
    const profile = this.getChannelProfile(channelId);
    if (!profile) return null;

    const sessionPath = profile.sessionFiles[sessionType];
    fs.writeFileSync(sessionPath, JSON.stringify(data, null, 2));

    return { channelId, sessionType, saved: true };
  }

  // Oturum Dosyasını Yükle
  loadSessionData(channelId, sessionType) {
    const profile = this.getChannelProfile(channelId);
    if (!profile) return null;

    const sessionPath = profile.sessionFiles[sessionType];
    if (!fs.existsSync(sessionPath)) {
      return null;
    }

    return JSON.parse(fs.readFileSync(sessionPath, 'utf-8'));
  }
}

// ─── Akıllı Geçiş Yönetimi (Smart Switching) ────────────────────────────────
export class SmartSwitcher {
  constructor(accountManager) {
    this.accountManager = accountManager;
    this.currentChannel = null;
    this.switchHistory = [];
  }

  // Kanal Değiştir
  async switchToChannel(channelId, waitTime = 30000) {
    // Mevcut kanaldan çık
    if (this.currentChannel) {
      await this.exitChannel(this.currentChannel);
    }

    // Yeni kanala gir
    this.currentChannel = channelId;
    this.accountManager.updateProfileStatus(channelId, 'ACTIVE');

    // Geçiş geçmişine ekle
    this.switchHistory.push({
      timestamp: new Date().toISOString(),
      from: this.switchHistory.length > 0 ? this.switchHistory[this.switchHistory.length - 1].to : null,
      to: channelId,
      waitTime,
    });

    // Bekleme süresi (YouTube'un aynı IP'den çok hızlı geçişleri şüpheli görmemesi için)
    await new Promise(resolve => setTimeout(resolve, waitTime));

    return {
      status: 'SWITCHED',
      channelId,
      profile: this.accountManager.getChannelProfile(channelId),
    };
  }

  // Kanaldan Çık
  async exitChannel(channelId) {
    this.accountManager.updateProfileStatus(channelId, 'INACTIVE');
    return { status: 'EXITED', channelId };
  }

  // Geçiş Geçmişini Getir
  getSwitchHistory() {
    return {
      totalSwitches: this.switchHistory.length,
      history: this.switchHistory,
      currentChannel: this.currentChannel,
    };
  }
}

// ─── Profil Denetim Raporu ─────────────────────────────────────────────────
export function generateProfileAuditReport(accountManager) {
  const profiles = accountManager.getAllProfiles();
  
  const report = {
    timestamp: new Date().toISOString(),
    totalProfiles: profiles.length,
    profiles: profiles.map(p => ({
      channelId: p.channelId,
      channelName: p.channelName,
      gmailAccount: p.gmailAccount,
      status: p.status,
      createdAt: p.createdAt,
      lastUsed: p.lastUsed,
      fingerprint: {
        userAgent: p.browserFingerprint.userAgent.substring(0, 50) + '...',
        screenResolution: p.browserFingerprint.screenResolution,
      },
    })),
    recommendation: profiles.length > 0
      ? ` ${profiles.length} profil aktif ve izole durumda`
      : 'Henüz profil oluşturulmadı',
  };

  return report;
}

// ─── Profil Güvenlik Kontrol ───────────────────────────────────────────────
export function validateProfileSecurity(profile) {
  const issues = [];
  const warnings = [];

  // Oturum dosyaları kontrol et
  if (!fs.existsSync(profile.sessionFiles.cookies)) {
    warnings.push('Cookies dosyası henüz oluşturulmadı');
  }

  // Parmak izi kontrol et
  if (!profile.browserFingerprint) {
    issues.push(' Tarayıcı parmak izi eksik');
  }

  // Durum kontrol et
  if (profile.status === 'INACTIVE') {
    warnings.push('Profil şu anda inaktif');
  }

  return {
    profileId: profile.channelId,
    isSecure: issues.length === 0,
    issues,
    warnings,
    recommendation: issues.length === 0
      ? ' Profil güvenli'
      : ' Güvenlik sorunları var',
  };
}

// ─── Profil Temizleme (Cleanup) ─────────────────────────────────────────────
export function cleanupOldProfiles(accountManager, daysOld = 30) {
  const profiles = accountManager.getAllProfiles();
  const now = new Date();
  const cleanupReport = {
    timestamp: new Date().toISOString(),
    daysOld,
    cleanedProfiles: [],
    skippedProfiles: [],
  };

  for (const profile of profiles) {
    const lastUsed = new Date(profile.lastUsed || profile.createdAt);
    const daysSinceUsed = Math.floor((now - lastUsed) / (1000 * 60 * 60 * 24));

    if (daysSinceUsed > daysOld && profile.status === 'INACTIVE') {
      cleanupReport.cleanedProfiles.push({
        channelId: profile.channelId,
        daysSinceUsed,
        reason: 'Eski ve inaktif profil',
      });
      // Profil klasörünü sil
      const profilePath = path.join(accountManager.baseDataPath, profile.channelId);
      if (fs.existsSync(profilePath)) {
        fs.rmSync(profilePath, { recursive: true });
      }
    } else {
      cleanupReport.skippedProfiles.push({
        channelId: profile.channelId,
        daysSinceUsed,
        reason: daysSinceUsed <= daysOld ? 'Yakın zamanda kullanıldı' : 'Aktif profil',
      });
    }
  }

  return cleanupReport;
}

// ─── Profil İhracat/İthalatı ───────────────────────────────────────────────
export function exportProfile(accountManager, channelId) {
  const profile = accountManager.getChannelProfile(channelId);
  if (!profile) return null;

  const exportData = {
    profile,
    sessions: {
      cookies: accountManager.loadSessionData(channelId, 'cookies'),
      localStorage: accountManager.loadSessionData(channelId, 'localStorage'),
      sessionStorage: accountManager.loadSessionData(channelId, 'sessionStorage'),
    },
    exportedAt: new Date().toISOString(),
  };

  return exportData;
}

export function importProfile(accountManager, channelId, exportedData) {
  // Profili oluştur
  accountManager.createChannelProfile(
    channelId,
    exportedData.profile.channelName,
    exportedData.profile.gmailAccount
  );

  // Oturum verilerini yükle
  if (exportedData.sessions.cookies) {
    accountManager.saveSessionData(channelId, 'cookies', exportedData.sessions.cookies);
  }
  if (exportedData.sessions.localStorage) {
    accountManager.saveSessionData(channelId, 'localStorage', exportedData.sessions.localStorage);
  }
  if (exportedData.sessions.sessionStorage) {
    accountManager.saveSessionData(channelId, 'sessionStorage', exportedData.sessions.sessionStorage);
  }

  return { status: 'IMPORTED', channelId };
}
