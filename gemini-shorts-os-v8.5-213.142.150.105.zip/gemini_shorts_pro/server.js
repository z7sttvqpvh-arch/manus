/**
 * Gemini Executive Shorts OS — Free Edition v3.0
 * ================================================
 * Tarayıcı Otomasyonu + Video Review & Repair Engine
 * - Videoyu saniye saniye analiz eder
 * - Otomatik onarım (Publish/Repair/Reject)
 * - Kapalı döngü kalite kontrol
 */

import http from 'http';
import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import crypto from 'crypto';
import * as browser from './browser-automation.js';
import * as videoReview from './video-review.js';
import * as videoRepair from './video-repair.js';
import * as trendTracker from './trend-tracker.js';
import * as musicEngine from './music-engine.js';
import { analyzeVideoForEditingCommands, generatePexelsUltraEffects } from './neural-director.js';
import VideoProcessor from './video-processor.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir   = path.join(__dirname, 'public');
const dataDir     = path.join(__dirname, 'data');
const storageDir  = path.join(__dirname, 'storage');
const outputsDir  = path.join(storageDir, 'outputs');
const analysisDir = path.join(storageDir, 'analysis');
const dbPath      = path.join(dataDir, 'db.json');
const configPath  = path.join(__dirname, 'config.json');
const logPath     = path.join(__dirname, 'logs', 'server.log');

// ─── SSE istemcileri ────────────────────────────────────────────────────────
const sseClients = new Set();

// ─── Varsayılan veritabanı şeması ───────────────────────────────────────────
const defaultDb = {
  channels: [],
  jobs: [],
  settings: {
    autoMode: false,
    autoIntervalMinutes: 180,
    aiService: 'gemini',
    model: 'free',
    targetVideoSeconds: 30,
    publishThreshold: 80,
    repairThreshold: 65,
    maxCandidates: 5,
    maxRepairRounds: 3,
    maxDailyPerChannel: 2,
    minUploadIntervalMinutes: 120,
    ttsEnabled: false,
    ttsVoice: 'tr-TR-EmelNeural',
    watermark: '',
    defaultPrivacy: 'public',
    notifyWebhook: '',
    maxJobHistory: 100,
    concurrentJobs: false,
    videoReviewEnabled: true,
    autoRepairEnabled: true,
    trendTrackingEnabled: true,
    musicEnabled: true,
    musicVolume: 0.6,
    useGeminiTrends: true,
    dynamicZoomPan: true,
    cinematicColorGrading: true,
    smartMirroring: true,
    speedRamping: true,
    aiTextureOverlay: true,
  },
  learning: {
    badOpenings: [],
    goodPatterns: [],
    badPatterns: [],
    topicHistory: [],
    performanceLog: [],
    trendHistory: [],
  },
  stats: {
    totalJobs: 0,
    successJobs: 0,
    failedJobs: 0,
    rejectedJobs: 0,
    repairedJobs: 0,
    totalUploads: 0,
    totalReviews: 0,
    totalRepairs: 0,
    trendSuggestions: 0,
    musicsUsed: 0,
  }
};

// ─── Boot & DB ──────────────────────────────────────────────────────────────
await ensureBoot();
let db = await loadDb();
const fileLocks = new Map();
let schedulerTimer = null;
let activeJobs = new Map();
const musicDir = path.join(storageDir, 'music');
await musicEngine.initializeMusicLibrary(storageDir);
ensureScheduler();

// ─── Yardımcı fonksiyonlar ──────────────────────────────────────────────────
function uid(prefix = 'id') { return `${prefix}_${crypto.randomBytes(8).toString('hex')}`; }
function nowIso() { return new Date().toISOString(); }
function delay(ms) { return new Promise(r => setTimeout(r, ms)); }
function rand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

async function ensureBoot() {
  const dirs = [
    dataDir, outputsDir, analysisDir,
    path.join(storageDir, 'temp'),
    path.join(storageDir, 'audio'),
    path.join(storageDir, 'backgrounds'),
    path.join(__dirname, 'logs'),
  ];
  for (const d of dirs) await fsp.mkdir(d, { recursive: true });
  try { await fsp.access(dbPath); } catch {
    await fsp.writeFile(dbPath, JSON.stringify(defaultDb, null, 2));
  }
}

async function loadDb() {
  let raw = { ...defaultDb };
  try { raw = JSON.parse(await fsp.readFile(dbPath, 'utf8')); } catch {}
  raw.settings  = { ...defaultDb.settings, ...(raw.settings || {}) };
  raw.channels  = raw.channels || [];
  raw.jobs      = raw.jobs || [];
  raw.learning  = { ...defaultDb.learning, ...(raw.learning || {}) };
  raw.stats     = { ...defaultDb.stats, ...(raw.stats || {}) };
  return raw;
}

async function saveDb() {
  while (fileLocks.get('db')) await delay(10);
  fileLocks.set('db', true);
  try {
    await fsp.writeFile(dbPath, JSON.stringify(db, null, 2));
  } finally {
    fileLocks.delete('db');
  }
}

// ─── Loglama & SSE ──────────────────────────────────────────────────────────
async function log(msg, level = 'info') {
  const line = `[${nowIso()}] [${level.toUpperCase()}] ${msg}\n`;
  await fsp.appendFile(logPath, line).catch(() => {});
  if (level !== 'debug') console.log(`[${level.toUpperCase()}] ${msg}`);
  broadcastSSE({ type: 'log', level, msg, ts: nowIso() });
}

function broadcastSSE(data) {
  const payload = `data: ${JSON.stringify(data)}\n\n`;
  for (const res of sseClients) {
    try { res.write(payload); } catch { sseClients.delete(res); }
  }
}

// ─── HTTP yardımcıları ───────────────────────────────────────────────────────
function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
    'Access-Control-Allow-Origin': '*',
  });
  res.end(body);
}

async function parseBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > 10e6) { req.destroy(); reject(new Error('Body too large')); }
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

function serveFile(res, filePath, contentType = 'text/html; charset=utf-8') {
  fs.readFile(filePath, (err, data) => {
    if (err) return sendJson(res, 404, { error: 'Not found' });
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
}

// ─── Video Render ───────────────────────────────────────────────────────────
const videoProcessor = new VideoProcessor();

async function renderWinner(job) {
  const winner  = job.winner;
  const outMp4  = path.join(outputsDir, `${job.id}.mp4`);
  const dur     = db.settings.targetVideoSeconds || 30;

  try {
    // Sessiz ses oluştur
    const audioPath = path.join(storageDir, 'audio', `${job.id}.wav`);
    await execSpawn('ffmpeg', [
      '-y', '-f', 'lavfi',
      '-i', `anullsrc=r=44100:cl=stereo`,
      '-t', String(dur),
      audioPath,
    ]);

    // Video render et
    const safeTitle = (winner.firstFrameText || winner.title || 'Shorts').replace(/[:'\\]/g, '').slice(0, 80);
    const pexelsVideoPath = job.winner.videoPath; // Varsayılan olarak Pexels videosu olduğunu varsayıyoruz
    const tempProcessedVideoPath = path.join(storageDir, 'temp', `${job.id}_processed.mp4`);

    // 1. Neural Director'dan kurgu komutlarını al
    const editingSequence = analyzeVideoForEditingCommands({ id: job.id, duration: dur });

    // 2. Pexels Ultra-Customizer efekt konfigürasyonunu oluştur (Kullanıcı ayarlarıyla birleştir)
    const baseEffectsConfig = generatePexelsUltraEffects({ id: job.id, duration: dur }, editingSequence.commands);
    const effectsConfig = {
      dynamicZoomPan: db.settings.dynamicZoomPan !== undefined ? db.settings.dynamicZoomPan : baseEffectsConfig.dynamicZoomPan,
      cinematicColorGrading: db.settings.cinematicColorGrading !== undefined ? db.settings.cinematicColorGrading : baseEffectsConfig.cinematicColorGrading,
      smartMirroring: db.settings.smartMirroring !== undefined ? db.settings.smartMirroring : baseEffectsConfig.smartMirroring,
      speedRamping: db.settings.speedRamping !== undefined ? db.settings.speedRamping : baseEffectsConfig.speedRamping,
      aiTextureOverlay: db.settings.aiTextureOverlay !== undefined ? db.settings.aiTextureOverlay : baseEffectsConfig.aiTextureOverlay,
    };

    // 3. Pexels videosunu Ultra-Customizer ile işle
    await log(`[${job.id}] Pexels videosu Ultra-Customizer ile işleniyor...`);
    await videoProcessor.processPexelsVideo(pexelsVideoPath, tempProcessedVideoPath, effectsConfig, dur);
    await log(`[${job.id}] Pexels videosu başarıyla işlendi: ${tempProcessedVideoPath}`);

    // FFmpeg komutları
    const vf = [
      'drawbox=x=0:y=0:w=1080:h=1920:color=#0f1729:t=fill',
      `drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='${safeTitle}':fontcolor=white:fontsize=52:x=(w-text_w)/2:y=100`,
      `drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:text='${(winner.cta||'').replace(/[:'\\]/g,'').slice(0,60)}':fontcolor=white:fontsize=36:x=(w-text_w)/2:y=1700`,
    ];

    await execSpawn('ffmpeg', [
      '-y', '-i', tempProcessedVideoPath,
      '-i', audioPath,
      '-map', '0:v:0', // İşlenmiş videonun video akışını kullan
      '-map', '1:a:0', // Oluşturulan sessiz sesin ses akışını kullan
      '-vf', vf.join(','),
      '-t', String(dur), // Süreyi burada belirtiyoruz
      '-c:v', 'libx264', '-preset', 'fast', '-crf', '23',
      '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-b:a', '128k',
      outMp4,
    ]);

    await log(`Video render tamamlandı: ${outMp4}`);
    return { outputPath: outMp4, rendered: true };

  } catch (e) {
    await log(`Video render hatası: ${e.message}`, 'error');
    return { outputPath: null, rendered: false, error: e.message };
  }
}

async function execSpawn(cmd, args) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { stdio: 'ignore' });
    p.on('error', reject);
    p.on('close', code => code === 0 ? resolve() : reject(new Error(`${cmd} exit ${code}`)));
  });
}

// ─── İçerik Üretim ──────────────────────────────────────────────────────────
async function generateCandidates(channel, topic) {
  try {
    await log(`[${channel.name}] İçerik üretiliyor: "${topic}"`);
    const candidates = await browser.generateContentViaAI(channel, topic, db.settings.aiService);
    await log(`[${channel.name}] ${candidates.length} aday üretildi`);
    return candidates;
  } catch (e) {
    await log(`İçerik üretim hatası: ${e.message}`, 'error');
    throw e;
  }
}

// ─── Basit Puanlama ─────────────────────────────────────────────────────────
function scoreCandidate(c) {
  const voice = c.voiceText || '';
  const hook  = c.hook || '';
  const title = c.title || '';

  const hookLen = hook.length;
  const hookImpact = Math.min(100, 60 + Math.floor(hookLen / 4));
  const clarity = voice.split(/[.!?]/).length > 2 ? 85 : 75;
  const titleStrength = /\?|neden|kimse/.test(title.toLowerCase()) ? 84 : 76;
  const humanLikeness = /çünkü|ama|aslında/.test(voice.toLowerCase()) ? 82 : 72;
  const retentionProxy = Math.round((hookImpact + clarity + titleStrength + humanLikeness) / 4);

  return {
    hookImpact, clarity, titleStrength, humanLikeness, retentionProxy,
    repetitionRisk: 15, policyRisk: 8,
  };
}

// ─── Varsayılan Konu ────────────────────────────────────────────────────────
const TOPIC_POOLS = {
  psychology: [
    'İnsanlar neden aynı hataları tekrar eder',
    'Kendi kendini sabote etme davranışı',
    'İlk izlenim neden bu kadar güçlü',
  ],
  shock: [
    'Çoğu kişinin bilmediği zihinsel hata',
    'Bir kararın hayatı nasıl saptırdığı',
    'Kimsenin fark etmediği günlük tuzak',
  ],
  motivation: [
    'Disiplini öldüren görünmez alışkanlık',
    'Ertelemenin arkasındaki gerçek neden',
    'İlerlemeyi durduran küçük hata',
  ],
};

function defaultIdea(channel) {
  const pool = TOPIC_POOLS[channel.category] || TOPIC_POOLS.psychology;
  return rand(pool);
}

// ─── Fallback İçerik ────────────────────────────────────────────────────────
function fallbackCandidates(topic, channel, count = 5) {
  return Array.from({ length: count }).map((_, i) => ({
    id: uid('cand'),
    hook: `Çoğu kişinin fark etmediği şey şu: ${topic}`,
    title: `Neden ${topic}`,
    firstFrameText: topic.slice(0, 48),
    voiceText: `${topic}. Çoğu insan sorunun ne olduğunu anladığını sanıyor ama asıl mesele görünmeyen alışkanlıkta başlıyor.`,
    cta: 'Sence bu sende de var mı?',
    thumbnailText: 'KİMSE BUNU BÖYLE ANLATMIYOR',
    description: `${topic} üzerine kısa bir anlatım.`,
    tags: ['#shorts', '#psikoloji', '#motivasyon'],
  }));
}

// ─── ANA İŞ AKIŞI: Üretim → Render → Review → Repair/Publish ────────────────
async function runJob(channelId, forceTopic = null) {
  if (!db.settings.concurrentJobs && activeJobs.size > 0) {
    return { ok: false, reason: 'job_active' };
  }

  const channel = db.channels.find(c => c.id === channelId && c.enabled !== false);
  if (!channel) return { ok: false, reason: 'channel_not_found' };

  let topic = forceTopic;
  let trendSuggestion = null;
  let selectedMusic = null;

  if (!topic && db.settings.trendTrackingEnabled) {
    try {
      const trends = db.settings.useGeminiTrends
        ? await trendTracker.getTrendsFromGemini(channel.category, 3)
        : trendTracker.generateCategoryTrends(channel.category, 3);
      const diversified = trendTracker.diversifyTrends(trends, db.learning.trendHistory || []);
      const best = trendTracker.selectBestTrend(diversified, channel.category, db.learning.trendHistory);
      topic = best.topic;
      trendSuggestion = best;
      db.stats.trendSuggestions = (db.stats.trendSuggestions || 0) + 1;
      await log(`📈 Trend: ${topic}`);
    } catch (e) {
      await log(`Trend hatası: ${e.message}`, 'warn');
      topic = defaultIdea(channel);
    }
  }
  if (!topic) topic = defaultIdea(channel);

  if (db.settings.musicEnabled) {
    try {
      const musicFiles = await musicEngine.getMusicFiles(channel.category, musicDir);
      selectedMusic = musicEngine.selectRandomMusic(musicFiles);
      if (selectedMusic) {
        db.stats.musicsUsed = (db.stats.musicsUsed || 0) + 1;
        await log(`🎵 Müzik: ${selectedMusic.filename}`);
      }
    } catch (e) {
      await log(`Müzik hatası: ${e.message}`, 'warn');
    }
  }

  const job = {
    id:          uid('job'),
    channelId,
    channelName: channel.name,
    status:      'generating',
    createdAt:   nowIso(),
    topic,
    trendSuggestion,
    selectedMusic,
    candidates:  [],
    winner:      null,
    render:      null,
    reviews:     [],
    repairs:     [],
    finalStatus: null,
    error:       null,
    duration:    null,
  };

  db.jobs.unshift(job);
  if (db.jobs.length > db.settings.maxJobHistory) {
    db.jobs = db.jobs.slice(0, db.settings.maxJobHistory);
  }
  db.stats.totalJobs = (db.stats.totalJobs || 0) + 1;
  await saveDb();

  activeJobs.set(channelId, job.id);
  broadcastSSE({ type: 'job_start', jobId: job.id, channelId, topic });
  await log(`🎬 İş başladı [${job.id}] — Kanal: ${channel.name}, Konu: "${topic}"`);

  const jobStart = Date.now();
  try {
    // 1. İçerik Üret
    await log(`[${job.id}] 📝 İçerik üretiliyor...`);
    let candidates = await generateCandidates(channel, topic);
    if (!candidates || candidates.length === 0) {
      candidates = fallbackCandidates(topic, channel, db.settings.maxCandidates);
      await log(`[${job.id}] ⚠ Fallback içerik kullanılıyor`);
    }
    job.candidates = candidates.map(c => ({ ...c, scores: scoreCandidate(c) }));

    // 2. Kazananı Seç
    const winner = job.candidates.find(c => c.scores.retentionProxy >= 75) || job.candidates[0];
    job.winner = winner;
    job.status = 'rendering';
    await saveDb();
    broadcastSSE({ type: 'job_update', jobId: job.id, status: 'rendering' });

    // 3. Video Render Et
    await log(`[${job.id}] 🎥 Video render ediliyor...`);
    const render = await renderWinner(job);
    job.render = render;

    if (!render.rendered) {
      throw new Error('Video render başarısız');
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // 4. VIDEO REVIEW & REPAIR LOOP (Kapalı Döngü)
    // ═══════════════════════════════════════════════════════════════════════════

    if (!db.settings.videoReviewEnabled) {
      // Review devre dışı → Direkt publish
      job.finalStatus = 'published';
      job.status = 'completed';
      db.stats.successJobs = (db.stats.successJobs || 0) + 1;
      await saveDb();
      await log(`[${job.id}] ✅ Video yayınlandı (review devre dışı)`);
      return { ok: true, job };
    }

    // Review başlat
    const repairTracker = new videoReview.RepairTracker(job.id);
    let currentVideoPath = render.outputPath;
    let reviewCount = 0;
    const maxReviews = db.settings.maxRepairRounds + 1;

    while (reviewCount < maxReviews) {
      reviewCount++;
      job.status = 'reviewing';
      await saveDb();
      broadcastSSE({ type: 'job_update', jobId: job.id, status: 'reviewing', reviewRound: reviewCount });

      await log(`[${job.id}] 🔍 Video inceleniyor (Round ${reviewCount}/${maxReviews})...`);
      
      // Videoyu Gemini'ye gönder ve analiz al
      const review = await videoReview.reviewVideoWithGemini(currentVideoPath);
      const decision = videoReview.makeDecision(review);
      const reviewReport = videoReview.createReviewReport(review, decision);

      job.reviews.push(reviewReport);
      db.stats.totalReviews = (db.stats.totalReviews || 0) + 1;
      repairTracker.addAttempt(review, decision, null);

      await log(`[${job.id}] 📊 Review sonuç: ${decision.action} (Skor: ${review.viral_score})`);
      broadcastSSE({ 
        type: 'job_review', 
        jobId: job.id, 
        decision: decision.action, 
        score: review.viral_score,
        round: reviewCount,
      });

      // ─── KARAR MEKANIZMASI ──────────────────────────────────────────────────
      if (decision.action === 'publish') {
        // ✅ PUBLISH: Skor yeterli, yayınla
        job.finalStatus = 'published';
        job.status = 'completed';
        db.stats.successJobs = (db.stats.successJobs || 0) + 1;
        await saveDb();
        await log(`[${job.id}] ✅ Video yayınlandı (Skor: ${review.viral_score})`);
        break;
      }

      else if (decision.action === 'repair') {
        // 🔧 REPAIR: Onarım dene
        if (!repairTracker.canRepairAgain()) {
          // Onarım limiti aşıldı → Reject
          job.finalStatus = 'rejected';
          job.status = 'completed';
          db.stats.rejectedJobs = (db.stats.rejectedJobs || 0) + 1;
          await saveDb();
          await log(`[${job.id}] ❌ Video reddedildi (Onarım limiti aşıldı, Skor: ${review.viral_score})`);
          break;
        }

        if (!db.settings.autoRepairEnabled) {
          // Auto repair devre dışı → Reject
          job.finalStatus = 'rejected_no_auto_repair';
          job.status = 'completed';
          db.stats.rejectedJobs = (db.stats.rejectedJobs || 0) + 1;
          await saveDb();
          await log(`[${job.id}] ❌ Video reddedildi (Auto repair devre dışı)`);
          break;
        }

        // Onarım planı oluştur
        const repairPlan = videoReview.createRepairPlan(review, decision);
        job.status = 'repairing';
        await saveDb();
        broadcastSSE({ type: 'job_update', jobId: job.id, status: 'repairing', repairRound: reviewCount });

        await log(`[${job.id}] 🔧 Onarım başlanıyor (${repairPlan.steps.length} adım, ~${repairPlan.estimatedTime}s)...`);

        // Onarımı uygula
        const tempRepaired = path.join(path.dirname(currentVideoPath), `${job.id}_repaired_${reviewCount}.mp4`);
        const repairResult = await videoRepair.executeRepairPlan(currentVideoPath, repairPlan, tempRepaired);

        if (!repairResult.success) {
          await log(`[${job.id}] ⚠ Onarım başarısız: ${repairResult.error || 'Bilinmeyen hata'}`, 'warn');
          // Fallback: hızlı onarım dene
          const quickRepairResult = await videoRepair.quickRepair(currentVideoPath, tempRepaired);
          if (!quickRepairResult.success) {
            // Hızlı onarım da başarısız → Reject
            job.finalStatus = 'rejected_repair_failed';
            job.status = 'completed';
            db.stats.rejectedJobs = (db.stats.rejectedJobs || 0) + 1;
            await saveDb();
            await log(`[${job.id}] ❌ Video reddedildi (Onarım başarısız)`);
            break;
          }
        }

        job.repairs.push({
          round: reviewCount,
          plan: repairPlan,
          result: repairResult,
          timestamp: nowIso(),
        });
        db.stats.totalRepairs = (db.stats.totalRepairs || 0) + 1;
        db.stats.repairedJobs = (db.stats.repairedJobs || 0) + 1;
        await saveDb();

        currentVideoPath = tempRepaired;
        await log(`[${job.id}] ✓ Onarım tamamlandı. Yeniden inceleme için hazırlanıyor...`);
        // Loop devam eder, yeniden review yapılacak
      }

      else if (decision.action === 'reject') {
        // ❌ REJECT: Kalite çok düşük
        job.finalStatus = 'rejected';
        job.status = 'completed';
        db.stats.rejectedJobs = (db.stats.rejectedJobs || 0) + 1;
        await saveDb();
        await log(`[${job.id}] ❌ Video reddedildi (Skor: ${review.viral_score}, Neden: ${decision.reason})`);
        break;
      }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Loop sonu
    // ═══════════════════════════════════════════════════════════════════════════

    job.duration = Date.now() - jobStart;
    const summary = repairTracker.getSummary();
    
    await log(`[${job.id}] 📈 İş Özeti: ${job.finalStatus} | Denemeler: ${summary.totalAttempts} | Skor Gelişimi: ${summary.scoreProgression.join(' → ')}`);
    
    return { ok: true, job, summary };

  } catch (e) {
    job.status = 'failed';
    job.finalStatus = 'error';
    job.error  = e.message;
    job.duration = Date.now() - jobStart;
    db.stats.failedJobs = (db.stats.failedJobs || 0) + 1;
    await saveDb();
    broadcastSSE({ type: 'job_error', jobId: job.id, error: e.message });
    await log(`[${job.id}] ❌ İş başarısız: ${e.message}`, 'error');
    return { ok: false, error: e.message };
  } finally {
    activeJobs.delete(channelId);
  }
}

// ─── Zamanlayıcı ────────────────────────────────────────────────────────────
function ensureScheduler() {
  if (schedulerTimer) clearInterval(schedulerTimer);
  schedulerTimer = setInterval(async () => {
    try {
      db = await loadDb();
      if (!db.settings.autoMode) return;
      const channels = db.channels.filter(c => c.enabled !== false);
      for (const channel of channels) {
        if (activeJobs.has(channel.id)) continue;
        const lastJob = db.jobs.find(j => j.channelId === channel.id);
        if (lastJob) {
          const elapsed = Date.now() - new Date(lastJob.createdAt).getTime();
          const interval = db.settings.autoIntervalMinutes * 60_000;
          if (elapsed < interval) continue;
        }
        await log(`⏰ Otomatik iş tetiklendi: ${channel.name}`);
        runJob(channel.id).catch(e => log(`Otomatik iş hatası: ${e.message}`, 'error'));
        if (!db.settings.concurrentJobs) break;
      }
    } catch (e) {
      await log(`Zamanlayıcı hatası: ${e.message}`, 'error');
    }
  }, 30_000);
}

// ─── API Endpoint'leri ───────────────────────────────────────────────────────
async function handleApi(req, res, pathname) {
  if (req.method === 'GET' && pathname === '/api/health') {
    const browserStatus = await browser.getBrowserStatus();
    return sendJson(res, 200, {
      ok: true,
      version: '3.0.0-review-repair',
      aiService: db.settings.aiService,
      browserStatus,
      stats: db.stats,
      features: {
        videoReview: db.settings.videoReviewEnabled,
        autoRepair: db.settings.autoRepairEnabled,
      },
    });
  }

  if (req.method === 'GET' && pathname === '/api/state') {
    return sendJson(res, 200, {
      channels:  db.channels,
      jobs:      db.jobs.slice(0, 30),
      settings:  db.settings,
      stats:     db.stats,
      learning:  db.learning,
      activeJobs: [...activeJobs.entries()].map(([ch, jid]) => ({ channelId: ch, jobId: jid })),
    });
  }

  if (req.method === 'GET' && pathname === '/api/logs') {
    try {
      const lines = (await fsp.readFile(logPath, 'utf8')).split('\n').filter(Boolean);
      return sendJson(res, 200, { logs: lines.slice(-200) });
    } catch {
      return sendJson(res, 200, { logs: [] });
    }
  }

  if (req.method === 'GET' && pathname === '/api/events') {
    res.writeHead(200, {
      'Content-Type':  'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection':    'keep-alive',
      'Access-Control-Allow-Origin': '*',
    });
    res.write('data: {"type":"connected"}\n\n');
    sseClients.add(res);
    req.on('close', () => sseClients.delete(res));
    return;
  }

  if (req.method === 'POST' && pathname === '/api/channels') {
    const body = await parseBody(req);
    if (!body.name) return sendJson(res, 400, { error: 'name zorunlu' });
    const channel = {
      id:        uid('ch'),
      name:      body.name.trim(),
      category:  body.category || 'psychology',
      enabled:   true,
      createdAt: nowIso(),
    };
    db.channels.push(channel);
    await saveDb();
    await log(`➕ Kanal eklendi: ${channel.name}`);
    return sendJson(res, 200, { ok: true, channel });
  }

  if (req.method === 'DELETE' && pathname.startsWith('/api/channels/')) {
    const id = pathname.split('/')[3];
    const idx = db.channels.findIndex(c => c.id === id);
    if (idx === -1) return sendJson(res, 404, { error: 'Kanal bulunamadı' });
    db.channels.splice(idx, 1);
    await saveDb();
    return sendJson(res, 200, { ok: true });
  }

  if (req.method === 'POST' && pathname.startsWith('/api/channels/') && pathname.endsWith('/toggle')) {
    const id = pathname.split('/')[3];
    const ch = db.channels.find(c => c.id === id);
    if (!ch) return sendJson(res, 404, { error: 'Kanal bulunamadı' });
    ch.enabled = !ch.enabled;
    await saveDb();
    return sendJson(res, 200, { ok: true, channel: ch });
  }

  if (req.method === 'POST' && pathname === '/api/settings') {
    const body = await parseBody(req);
    const allowed = [
      'autoMode', 'autoIntervalMinutes', 'aiService', 'targetVideoSeconds',
      'publishThreshold', 'repairThreshold', 'maxCandidates', 'maxRepairRounds',
      'maxDailyPerChannel', 'minUploadIntervalMinutes', 'ttsEnabled', 'ttsVoice',
      'watermark', 'defaultPrivacy', 'notifyWebhook', 'maxJobHistory',
      'concurrentJobs', 'videoReviewEnabled', 'autoRepairEnabled',
      'dynamicZoomPan', 'cinematicColorGrading', 'smartMirroring', 'speedRamping', 'aiTextureOverlay',
    ];
    for (const k of allowed) {
      if (body[k] !== undefined) db.settings[k] = body[k];
    }
    await saveDb();
    ensureScheduler();
    return sendJson(res, 200, { ok: true, settings: db.settings });
  }

  if (req.method === 'POST' && pathname === '/api/run') {
    const body = await parseBody(req);
    if (!body.channelId) return sendJson(res, 400, { error: 'channelId zorunlu' });
    const result = await runJob(body.channelId, body.topic || null);
    return sendJson(res, 200, result);
  }

  if (req.method === 'POST' && pathname === '/api/browser/login') {
    const body = await parseBody(req);
    const service = body.service || 'gemini';
    try {
      await browser.openBrowserForManualLogin(service);
      return sendJson(res, 200, { ok: true, message: `${service} tarayıcısı açıldı` });
    } catch (e) {
      return sendJson(res, 500, { error: e.message });
    }
  }

  if (req.method === 'GET' && pathname === '/api/browser/status') {
    const status = await browser.getBrowserStatus();
    return sendJson(res, 200, status);
  }

  if (req.method === 'GET' && pathname.startsWith('/api/outputs/')) {
    const fname = path.basename(pathname.slice('/api/outputs/'.length));
    const fp = path.join(outputsDir, fname);
    try {
      await fsp.access(fp);
      const ext = path.extname(fp).toLowerCase();
      const types = { '.mp4': 'video/mp4', '.txt': 'text/plain', '.json': 'application/json' };
      fs.readFile(fp, (err, data) => {
        if (err) return sendJson(res, 404, { error: 'Dosya bulunamadı' });
        res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
        res.end(data);
      });
    } catch {
      sendJson(res, 404, { error: 'Dosya bulunamadı' });
    }
    return;
  }

  if (req.method === 'GET' && pathname.startsWith('/api/analysis/')) {
    const fname = path.basename(pathname.slice('/api/analysis/'.length));
    const fp = path.join(analysisDir, fname);
    try {
      await fsp.access(fp);
      serveFile(res, fp, 'application/json');
    } catch {
      sendJson(res, 404, { error: 'Analiz bulunamadı' });
    }
    return;
  }

  return sendJson(res, 404, { error: 'API endpoint bulunamadı' });
}

// ─── HTTP Sunucu ────────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  try {
    const url      = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = url.pathname;

    if (req.method === 'OPTIONS') {
      res.writeHead(204, {
        'Access-Control-Allow-Origin':  '*',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      });
      return res.end();
    }

    if (pathname.startsWith('/api/')) return handleApi(req, res, pathname);
    if (pathname === '/' || pathname === '/index.html') return serveFile(res, path.join(publicDir, 'index.html'));
    return sendJson(res, 404, { error: 'Sayfa bulunamadı' });

  } catch (e) {
    await log(`Sunucu hatası: ${e.message}`, 'error');
    return sendJson(res, 500, { error: e.message });
  }
});

const PORT = 3001;
const HOST = '213.142.150.105';
server.listen(PORT, HOST, async () => {
  await log(`🚀 Gemini Executive Shorts OS v3.0 — http://${HOST}:${PORT}`);
  await log(`AI Service: ${db.settings.aiService.toUpperCase()} | Video Review: ${db.settings.videoReviewEnabled ? '✓' : '✗'} | Auto Repair: ${db.settings.autoRepairEnabled ? '✓' : '✗'}`);
  await log(`Kapalı Döngü Kalite Kontrol: Aktif`);
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n⏹ Sistem kapatılıyor...');
  await browser.closeBrowser();
  process.exit(0);
});
