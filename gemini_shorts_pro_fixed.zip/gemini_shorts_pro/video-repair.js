/**
 * Video Repair Engine — Video Onarım Motoru
 * ==========================================
 * Gemini'nin önerilerine göre videoyu otomatik olarak onarır
 * - Sıkıcı bölümleri kırpar
 * - Tempo ve pacing'i ayarlar
 * - Hook'u güçlendirir
 * - Altyazı hızını sıkılaştırır
 * - FFmpeg ile yeniden render eder
 */

import { spawn } from 'child_process';
import fsp from 'fs/promises';
import path from 'path';

// ─── FFmpeg Komut Yardımcısı ────────────────────────────────────────────────
async function execFFmpeg(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn('ffmpeg', args, { stdio: ['ignore', 'ignore', 'pipe'] });
    let stderr = '';
    
    proc.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    proc.on('error', reject);
    proc.on('close', (code) => {
      if (code === 0) resolve();
      else reject(new Error(`FFmpeg exit ${code}: ${stderr}`));
    });
  });
}

// ─── Sıkıcı Bölümleri Kırp ──────────────────────────────────────────────────
/**
 * Boring segments'i kırpar. Basit yaklaşım: ilk high-severity segment'i kırp.
 * Daha karmaşık: multiple segments için concat filter.
 */
export async function trimBoringSegments(inputVideo, boringSegments, outputVideo) {
  if (!boringSegments || boringSegments.length === 0) {
    return { success: false, reason: 'Kırpılacak segment yok' };
  }

  // High severity segments'i bul
  const highSeverity = boringSegments.filter(s => s.severity === 'high');
  if (highSeverity.length === 0) {
    return { success: false, reason: 'High severity segment yok' };
  }

  // İlk segment'i kırp
  const seg = highSeverity[0];
  const trimAmount = seg.end_sec - seg.start_sec;

  console.log(`✂ Kırpılıyor: ${seg.start_sec}s-${seg.end_sec}s (${trimAmount}s) — ${seg.reason}`);

  try {
    // FFmpeg concat filter ile kırp
    const filterComplex = `[0:v]select='not(between(t,${seg.start_sec},${seg.end_sec}))',setpts=N/FRAME_RATE/TB[v];[0:a]aselect='not(between(t,${seg.start_sec},${seg.end_sec}))',asetpts=N/SR/TB[a]`;

    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-filter_complex', filterComplex,
      '-map', '[v]',
      '-map', '[a]',
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(`✓ Segment kırpıldı: ${trimAmount}s çıkarıldı`);
    return {
      success: true,
      trimmedSegment: seg,
      trimAmount,
      newDuration: null, // Hesaplanacak
    };

  } catch (e) {
    console.error('Kırpma hatası:', e.message);
    return { success: false, error: e.message };
  }
}

// ─── Hız Ayarla (Tempo) ──────────────────────────────────────────────────────
/**
 * Videoyu belirli bir faktörle hızlandırır veya yavaşlatır.
 * factor > 1: hızlandır, factor < 1: yavaşlat
 */
export async function adjustSpeed(inputVideo, factor, outputVideo) {
  if (factor <= 0 || factor > 2) {
    return { success: false, reason: 'Factor 0-2 arasında olmalı' };
  }

  if (Math.abs(factor - 1) < 0.05) {
    return { success: false, reason: 'Hız değişimi çok az' };
  }

  console.log(`⏱ Hız ayarlanıyor: ${factor.toFixed(2)}x`);

  try {
    const vf = `setpts=${1/factor}*PTS`;
    const af = `atempo=${factor}`;

    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-vf', vf,
      '-af', af,
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(`✓ Hız ayarlandı: ${factor.toFixed(2)}x`);
    return { success: true, factor };

  } catch (e) {
    console.error('Hız ayarlama hatası:', e.message);
    return { success: false, error: e.message };
  }
}

// ─── Belirli Bölümün Hızını Ayarla ──────────────────────────────────────────
/**
 * Videoyu parçalara ayırıp sadece belirli bölümün hızını değiştirir.
 */
export async function adjustSegmentSpeed(inputVideo, startSec, endSec, factor, outputVideo) {
  console.log(`⏱ ${startSec}s-${endSec}s arası hız: ${factor.toFixed(2)}x`);

  try {
    // Parça 1: 0 - startSec (normal)
    // Parça 2: startSec - endSec (değiştirilmiş)
    // Parça 3: endSec - son (normal)

    const filterComplex = 
      `[0:v]split[v1][v2];` +
      `[v1]select='lte(t,${startSec})',setpts=N/FRAME_RATE/TB[part1v];` +
      `[v2]select='gt(t,${startSec})*lt(t,${endSec})',setpts=N/FRAME_RATE/TB,setpts=${1/factor}*PTS[part2v];` +
      `[part1v][part2v]concat[vout];` +
      `[0:a]split[a1][a2];` +
      `[a1]aselect='lte(t,${startSec})',asetpts=N/SR/TB[part1a];` +
      `[a2]aselect='gt(t,${startSec})*lt(t,${endSec})',asetpts=N/SR/TB,atempo=${factor}[part2a];` +
      `[part1a][part2a]concat=v=0:a=1[aout]`;

    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-filter_complex', filterComplex,
      '-map', '[vout]',
      '-map', '[aout]',
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(`✓ Segment hızı ayarlandı`);
    return { success: true, segment: { startSec, endSec }, factor };

  } catch (e) {
    console.error('Segment hız ayarlama hatası:', e.message);
    return { success: false, error: e.message };
  }
}

// ─── Altyazı Hızını Sıkılaştır (Caption Pacing) ──────────────────────────────
/**
 * Altyazıların ekranda kalma süresini ayarlar.
 * factor > 1: daha hızlı (kısa süre), factor < 1: daha yavaş (uzun süre)
 */
export async function adjustCaptionPacing(inputVideo, factor, outputVideo) {
  console.log(`📝 Altyazı hızı ayarlanıyor: ${factor.toFixed(2)}x`);

  try {
    // Basit yaklaşım: video hızını ayarla (altyazı da otomatik hızlanır)
    // Daha gelişmiş: SRT dosyasını parse edip timing'i değiştir

    const vf = `setpts=${1/factor}*PTS`;
    const af = `atempo=${factor}`;

    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-vf', vf,
      '-af', af,
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(`✓ Altyazı hızı ayarlandı: ${factor.toFixed(2)}x`);
    return { success: true, factor };

  } catch (e) {
    console.error('Altyazı hız ayarlama hatası:', e.message);
    return { success: false, error: e.message };
  }
}

// ─── Hook Güçlendirme (Görsel Efekt Ekle) ──────────────────────────────────
/**
 * Videonun ilk 2 saniyesine görsel efekt ekler.
 * - Zoom in
 * - Renk yoğunluğu artır
 * - Müzik volümü artır
 */
export async function reinforceHook(inputVideo, outputVideo, audioVolume = 1.5) {
  console.log(`🎬 Hook güçlendiriliyor...`);

  try {
    // İlk 2 saniye: zoom in + brightness artır
    const filterComplex = 
      `[0:v]split[v1][v2];` +
      `[v1]select='lt(t,2)',setpts=N/FRAME_RATE/TB,scale=iw*1.1:ih*1.1,crop=1080:1920[part1];` +
      `[v2]select='gte(t,2)',setpts=N/FRAME_RATE/TB[part2];` +
      `[part1][part2]concat[vout];` +
      `[0:a]volume=${audioVolume}[aout]`;

    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-filter_complex', filterComplex,
      '-map', '[vout]',
      '-map', '[aout]',
      '-c:v', 'libx264',
      '-preset', 'fast',
      '-crf', '23',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(`✓ Hook güçlendirildi`);
    return { success: true, audioVolume };

  } catch (e) {
    console.error('Hook güçlendirme hatası:', e.message);
    return { success: false, error: e.message };
  }
}

// ─── Müzik Volümü Artır ─────────────────────────────────────────────────────
export async function increaseAudioVolume(inputVideo, factor, outputVideo) {
  console.log(`🔊 Ses volümü artırılıyor: ${factor.toFixed(2)}x`);

  try {
    await execFFmpeg([
      '-y',
      '-i', inputVideo,
      '-af', `volume=${factor}`,
      '-c:v', 'copy',
      '-c:a', 'aac',
      '-b:a', '128k',
      outputVideo,
    ]);

    console.log(`✓ Ses volümü ayarlandı: ${factor.toFixed(2)}x`);
    return { success: true, factor };

  } catch (e) {
    console.error('Ses ayarlama hatası:', e.message);
    return { success: false, error: e.message };
  }
}

// ─── Yeniden Render (Tüm Onarımları Uygula) ────────────────────────────────
/**
 * Onarım planını uygulayıp videoyu yeniden render eder.
 */
export async function executeRepairPlan(inputVideo, repairPlan, outputVideo) {
  console.log(`🔧 Onarım planı uygulanıyor (${repairPlan.steps.length} adım)...`);

  let currentVideo = inputVideo;
  let stepResults = [];

  for (const step of repairPlan.steps) {
    if (step.type === 'rewrite_hook') {
      console.log(`  [${step.order}] Hook yeniden yazılıyor...`);
      const tempOutput = `${outputVideo}.hook.mp4`;
      const result = await reinforceHook(currentVideo, tempOutput);
      stepResults.push({ step: step.order, type: step.type, result });
      if (result.success) currentVideo = tempOutput;
    }

    else if (step.type === 'trim_boring_segments') {
      console.log(`  [${step.order}] Sıkıcı bölümler kırpılıyor...`);
      const tempOutput = `${outputVideo}.trim.mp4`;
      const result = await trimBoringSegments(currentVideo, step.segments, tempOutput);
      stepResults.push({ step: step.order, type: step.type, result });
      if (result.success) currentVideo = tempOutput;
    }

    else if (step.type === 'fix_pacing') {
      console.log(`  [${step.order}] Pacing düzeltiliyor...`);
      // İlk pacing issue'yi al
      const issue = step.issues[0];
      const tempOutput = `${outputVideo}.pacing.mp4`;
      
      // Segment aralığını parse et (örn: "10-15s" → 10, 15)
      const match = issue.segment.match(/(\d+)-(\d+)/);
      if (match) {
        const [, start, end] = match;
        const factor = issue.issue === 'çok yavaş' ? 1.15 : 0.9;
        const result = await adjustSegmentSpeed(currentVideo, parseInt(start), parseInt(end), factor, tempOutput);
        stepResults.push({ step: step.order, type: step.type, result });
        if (result.success) currentVideo = tempOutput;
      }
    }

    else if (step.type === 'adjust_caption_pacing') {
      console.log(`  [${step.order}] Altyazı hızı sıkılaştırılıyor...`);
      const tempOutput = `${outputVideo}.caption.mp4`;
      const result = await adjustCaptionPacing(currentVideo, 1.1, tempOutput);
      stepResults.push({ step: step.order, type: step.type, result });
      if (result.success) currentVideo = tempOutput;
    }

    else if (step.type === 'rerender_video') {
      console.log(`  [${step.order}] Video yeniden render ediliyor...`);
      // Zaten render ediliyor, sadece final output'a kopyala
      if (currentVideo !== outputVideo) {
        await fsp.copyFile(currentVideo, outputVideo);
      }
      stepResults.push({ step: step.order, type: step.type, result: { success: true } });
    }

    else if (step.type === 'review_again') {
      console.log(`  [${step.order}] Yeniden inceleme için hazırlanıyor...`);
      stepResults.push({ step: step.order, type: step.type, result: { success: true } });
    }
  }

  // Temp dosyaları temizle
  for (const result of stepResults) {
    if (result.result.tempFile) {
      try {
        await fsp.unlink(result.result.tempFile);
      } catch {}
    }
  }

  console.log(`✓ Onarım planı tamamlandı`);
  return {
    success: true,
    stepsExecuted: stepResults.length,
    results: stepResults,
    outputVideo,
  };
}

// ─── Hızlı Onarım (Basit Hız Artırma) ───────────────────────────────────────
/**
 * Hızlı bir onarım: videoyu %10 hızlandır ve bitir.
 * Zaman kısıtlı durumlarda kullanılır.
 */
export async function quickRepair(inputVideo, outputVideo) {
  console.log(`' Hızlı onarım: Video %10 hızlandırılıyor...`);
  return adjustSpeed(inputVideo, 1.1, outputVideo);
}
