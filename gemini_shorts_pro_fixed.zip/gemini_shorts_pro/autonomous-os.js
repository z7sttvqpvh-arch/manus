/**
 * Autonomous OS — Otonom İşletim Sistemi
 * =======================================
 * Sistem kendi kararlarını verir:
 * - Gerçek zamanlı olaylara (Real-time Events) saniyeler içinde tepki verir
 * - Bütçesini (API limitleri, render süresi) yönetir
 * - Kendi stratejisini dinamik olarak günceller
 */

// ─── Otonom OS Durumu ────────────────────────────────────────────────────────
export class AutonomousOS {
  constructor(config = {}) {
    this.state = {
      isActive: true,
      mode: 'normal', // normal, emergency, learning, standby
      budget: {
        dailyRenderMinutes: config.dailyRenderMinutes || 120,
        usedRenderMinutes: 0,
        dailyGeminiCalls: config.dailyGeminiCalls || 50,
        usedGeminiCalls: 0,
      },
      recentEvents: [],
      strategy: 'balanced', // aggressive, balanced, conservative
      lastDecision: null,
      decisionLog: [],
    };

    this.eventHandlers = {
      viralTrend: this.handleViralTrend.bind(this),
      breakingNews: this.handleBreakingNews.bind(this),
      lowPerformance: this.handleLowPerformance.bind(this),
      budgetLow: this.handleBudgetLow.bind(this),
    };
  }

  // ─── Bütçe Durumunu Kontrol Et ──────────────────────────────────────────
  checkBudgetStatus() {
    const renderUsagePercent = (this.state.budget.usedRenderMinutes / this.state.budget.dailyRenderMinutes) * 100;
    const geminiUsagePercent = (this.state.budget.usedGeminiCalls / this.state.budget.dailyGeminiCalls) * 100;

    return {
      renderBudget: {
        total: this.state.budget.dailyRenderMinutes,
        used: this.state.budget.usedRenderMinutes,
        remaining: this.state.budget.dailyRenderMinutes - this.state.budget.usedRenderMinutes,
        usagePercent: Math.round(renderUsagePercent),
        status: renderUsagePercent > 80 ? 'critical' : renderUsagePercent > 50 ? 'warning' : 'ok',
      },
      geminiBudget: {
        total: this.state.budget.dailyGeminiCalls,
        used: this.state.budget.usedGeminiCalls,
        remaining: this.state.budget.dailyGeminiCalls - this.state.budget.usedGeminiCalls,
        usagePercent: Math.round(geminiUsagePercent),
        status: geminiUsagePercent > 80 ? 'critical' : geminiUsagePercent > 50 ? 'warning' : 'ok',
      },
    };
  }

  // ─── Otonom Karar Ver ──────────────────────────────────────────────────────
  makeAutonomousDecision(context = {}) {
    const budget = this.checkBudgetStatus();
    const decision = {
      timestamp: new Date().toISOString(),
      context,
      budgetStatus: budget,
      decision: null,
      reasoning: [],
    };

    // Bütçe kontrol et
    if (budget.renderBudget.status === 'critical' || budget.geminiBudget.status === 'critical') {
      decision.decision = 'STANDBY';
      decision.reasoning.push('Bütçe kritik seviyeye ulaştı, bekleme moduna geçiliyor');
      this.state.mode = 'standby';
    }
    // Viral trend tespit et
    else if (context.viralTrendDetected) {
      decision.decision = 'EMERGENCY_PRODUCTION';
      decision.reasoning.push('Viral trend tespit edildi, acil üretim moduna geçiliyor');
      this.state.mode = 'emergency';
    }
    // Normal üretim
    else {
      decision.decision = 'NORMAL_PRODUCTION';
      decision.reasoning.push('Normal üretim modunda devam et');
      this.state.mode = 'normal';
    }

    this.state.lastDecision = decision;
    this.state.decisionLog.push(decision);

    return decision;
  }

  // ─── Viral Trend Olayını İşle ──────────────────────────────────────────────
  handleViralTrend(trendData) {
    console.log(`🔥 Viral Trend Tespit Edildi: ${trendData.topic}`);

    const action = {
      type: 'viral_trend',
      timestamp: new Date().toISOString(),
      trend: trendData,
      action: 'PRODUCE_3_VIDEOS_IMMEDIATELY',
      priority: 'critical',
      expectedRenderTime: 15, // dakika
      expectedGeminiCalls: 12,
    };

    this.state.recentEvents.push(action);
    return action;
  }

  // ─── Haber Olayını İşle ────────────────────────────────────────────────────
  handleBreakingNews(newsData) {
    console.log(`📰 Haber Tespit Edildi: ${newsData.headline}`);

    const action = {
      type: 'breaking_news',
      timestamp: new Date().toISOString(),
      news: newsData,
      action: 'PRODUCE_COMMENTARY_VIDEO',
      priority: 'high',
      expectedRenderTime: 8,
      expectedGeminiCalls: 5,
    };

    this.state.recentEvents.push(action);
    return action;
  }

  // ─── Düşük Performans Olayını İşle ─────────────────────────────────────────
  handleLowPerformance(performanceData) {
    console.log(`📉 Düşük Performans: ${performanceData.avgScore}`);

    const action = {
      type: 'low_performance',
      timestamp: new Date().toISOString(),
      performance: performanceData,
      action: 'SWITCH_TO_LEARNING_MODE',
      priority: 'medium',
      recommendation: 'Son 10 başarılı videoyu analiz et ve stratejisini güncelle',
    };

    this.state.recentEvents.push(action);
    this.state.mode = 'learning';
    return action;
  }

  // ─── Bütçe Düşük Olayını İşle ──────────────────────────────────────────────
  handleBudgetLow(budgetData) {
    console.log(`💰 Bütçe Düşük: ${budgetData.remainingPercent}%`);

    const action = {
      type: 'budget_low',
      timestamp: new Date().toISOString(),
      budget: budgetData,
      action: 'REDUCE_PRODUCTION_SPEED',
      priority: 'high',
      recommendation: 'Üretim hızını %50 azalt, bütçeyi koru',
    };

    this.state.recentEvents.push(action);
    return action;
  }

  // ─── Gerçek Zamanlı Olay Dinleyicisi ────────────────────────────────────────
  async processRealTimeEvent(eventType, eventData) {
    const handler = this.eventHandlers[eventType];

    if (handler) {
      const action = handler(eventData);
      const decision = this.makeAutonomousDecision({ [eventType]: true });

      return {
        event: eventType,
        action,
        decision,
      };
    }

    return { error: 'Unknown event type' };
  }

  // ─── Strategi Güncelle ─────────────────────────────────────────────────────
  updateStrategy(performanceMetrics) {
    const avgScore = performanceMetrics.avgScore || 0;
    const trendingTopicCount = performanceMetrics.trendingTopicCount || 0;
    const viralVideoCount = performanceMetrics.viralVideoCount || 0;

    if (avgScore > 80 && trendingTopicCount > 5) {
      this.state.strategy = 'aggressive';
      console.log('📈 Strategi: AGGRESSIVE (Yüksek performans, agresif üretim)');
    } else if (avgScore > 60) {
      this.state.strategy = 'balanced';
      console.log('⚖ Strategi: BALANCED (Dengeli üretim)');
    } else {
      this.state.strategy = 'conservative';
      console.log('🛡 Strategi: CONSERVATIVE (Düşük performans, koruma modu)');
    }

    return {
      strategy: this.state.strategy,
      reason: `Ortalama Skor: ${avgScore}, Trending Konular: ${trendingTopicCount}, Viral Videolar: ${viralVideoCount}`,
    };
  }

  // ─── Günlük Rapor ──────────────────────────────────────────────────────────
  generateDailyReport() {
    const budget = this.checkBudgetStatus();

    return {
      timestamp: new Date().toISOString(),
      mode: this.state.mode,
      strategy: this.state.strategy,
      budget,
      recentEvents: this.state.recentEvents.slice(-10),
      lastDecision: this.state.lastDecision,
      decisionCount: this.state.decisionLog.length,
      recommendation: this.generateRecommendation(),
    };
  }

  // ─── Tavsiye Oluştur ────────────────────────────────────────────────────────
  generateRecommendation() {
    const budget = this.checkBudgetStatus();

    if (this.state.mode === 'standby') {
      return '⏸ Sistem bekleme modunda. Bütçe yenilenmesini bekle.';
    }

    if (this.state.mode === 'emergency') {
      return '🔥 Viral trend tespit edildi! Acil üretim modunda çalış.';
    }

    if (this.state.mode === 'learning') {
      return '📚 Sistem öğrenme modunda. Geçmiş başarıları analiz et.';
    }

    if (budget.renderBudget.usagePercent > 70) {
      return '' Render bütçesi %70\'i geçti. Üretim hızını azalt.';
    }

    return '✓ Sistem normal şekilde çalışıyor. Üretim devam et.';
  }

  // ─── Bütçeyi Güncelle ──────────────────────────────────────────────────────
  updateBudgetUsage(renderMinutes, geminiCalls) {
    this.state.budget.usedRenderMinutes += renderMinutes;
    this.state.budget.usedGeminiCalls += geminiCalls;

    return this.checkBudgetStatus();
  }

  // ─── Bütçeyi Sıfırla (Günlük) ──────────────────────────────────────────────
  resetDailyBudget() {
    this.state.budget.usedRenderMinutes = 0;
    this.state.budget.usedGeminiCalls = 0;
    this.state.recentEvents = [];
    this.state.decisionLog = [];

    return {
      message: 'Günlük bütçe sıfırlandı',
      budget: this.state.budget,
    };
  }

  // ─── Otonom OS Durumu ───────────────────────────────────────────────────────
  getStatus() {
    return {
      timestamp: new Date().toISOString(),
      isActive: this.state.isActive,
      mode: this.state.mode,
      strategy: this.state.strategy,
      budget: this.checkBudgetStatus(),
      recentEventCount: this.state.recentEvents.length,
      decisionCount: this.state.decisionLog.length,
      lastDecision: this.state.lastDecision,
    };
  }
}

// ─── Otonom OS Fabrikası ────────────────────────────────────────────────────
export function createAutonomousOS(config) {
  return new AutonomousOS(config);
}
