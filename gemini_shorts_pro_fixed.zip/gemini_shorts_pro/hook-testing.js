/**
 * A/B Hook Testing — 5 Adaylı Hook Testi
 * ========================================
 * Sistem 5 farklı "Hook" (açılış) üretir, Gemini'ye izletir ve en yüksek
 * "Scroll-stop" (kaydırma durdurma) gücüne sahip olanı seçer.
 * Eğer hiçbiri eşik puanı geçemezse, yeni 5'li set üretir.
 */

import * as browser from './browser-automation.js';

// ─── Hook Tipleri ───────────────────────────────────────────────────────────
const HOOK_TYPES = {
  question: {
    name: 'Soru (Question)',
    template: 'Neden {topic}? Cevabı biliyorsun?',
    description: 'Merak uyandırıcı bir soru ile başla',
  },
  shock: {
    name: 'Şaşırtma (Shock)',
    template: 'Çoğu kişi {topic} hakkında yanılıyor.',
    description: 'Şaşırtıcı bir iddia ile başla',
  },
  mystery: {
    name: 'Gizem (Mystery)',
    template: 'Kimse {topic} hakkında bunu söylemiyor.',
    description: 'Gizli bilgi vaat ederek başla',
  },
  direct: {
    name: 'Doğrudan (Direct)',
    template: '{topic} hakkında bilmen gereken 1 şey: ...',
    description: 'Doğrudan ve net bir ifade ile başla',
  },
  visual: {
    name: 'Görsel (Visual)',
    template: 'Bu görsele bak... {topic} hakkında ne düşünüyorsun?',
    description: 'Görsel bir merak ile başla',
  },
};

// ─── 5 Adaylı Hook Seti Oluştur ─────────────────────────────────────────────
export function generateFiveHookCandidates(topic, category) {
  const candidates = [];
  const hookTypeKeys = Object.keys(HOOK_TYPES);

  for (let i = 0; i < 5; i++) {
    const hookType = hookTypeKeys[i % hookTypeKeys.length];
    const hookDef = HOOK_TYPES[hookType];
    const hookText = hookDef.template.replace('{topic}', topic);

    candidates.push({
      id: `hook_${Date.now()}_${i}`,
      type: hookType,
      typeName: hookDef.name,
      template: hookDef.template,
      text: hookText,
      description: hookDef.description,
      category,
      topic,
      scrollStopScore: null,
      safetyScore: null,
      selected: false,
    });
  }

  return candidates;
}

// ─── Hook'ları Gemini'ye Değerlendir ────────────────────────────────────────
export async function evaluateHooksWithGemini(hooks) {
  try {
    console.log(`🎣 ${hooks.length} Hook Gemini'ye değerlendiriliyor...`);

    const hooksList = hooks
      .map((h, i) => `${i + 1}. [${h.typeName}] "${h.text}"`)
      .join('\n');

    const prompt = `Aşağıdaki 5 video açılışını (Hook) değerlendir. 
Her birinin "Scroll-stop" (kaydırmayı durdurma) gücünü 0-100 arasında puan ver.

${hooksList}

Cevap JSON formatında (başka hiçbir şey yazma):
{
  "evaluations": [
    {"index": 1, "scrollStopScore": 88, "reason": "Merak uyandırıcı"},
    {"index": 2, "scrollStopScore": 75, "reason": "Biraz sıradan"},
    {"index": 3, "scrollStopScore": 92, "reason": "Çok etkili gizem"},
    {"index": 4, "scrollStopScore": 70, "reason": "Doğrudan ama sıkıcı"},
    {"index": 5, "scrollStopScore": 85, "reason": "İyi görsel merak"}
  ],
  "bestHook": 3,
  "recommendation": "3. Hook en yüksek scroll-stop gücüne sahip"
}`;

    const response = await browser.sendMessageToGemini(prompt);
    const jsonMatch = response.match(/\{[\s\S]*\}/);

    if (!jsonMatch) {
      console.warn('' Hook değerlendirmesi JSON bulunamadı, varsayılan puanlar veriliyor');
      return assignDefaultScores(hooks);
    }

    const evaluation = JSON.parse(jsonMatch[0]);

    // Puanları hook'lara ata
    for (const item of evaluation.evaluations) {
      if (hooks[item.index - 1]) {
        hooks[item.index - 1].scrollStopScore = item.scrollStopScore;
        hooks[item.index - 1].evaluationReason = item.reason;
      }
    }

    console.log(`✓ Hook değerlendirmesi tamamlandı`);
    return hooks;
  } catch (e) {
    console.error('Hook değerlendirme hatası:', e.message);
    return assignDefaultScores(hooks);
  }
}

// ─── Varsayılan Puanlar (Hata Durumunda) ────────────────────────────────────
function assignDefaultScores(hooks) {
  const scores = [88, 75, 92, 70, 85];
  hooks.forEach((h, i) => {
    h.scrollStopScore = scores[i] || 75;
    h.evaluationReason = 'Varsayılan puan';
  });
  return hooks;
}

// ─── En İyi Hook'u Seç ──────────────────────────────────────────────────────
export function selectBestHook(hooks, threshold = 85) {
  // Puanları sırala
  const sorted = [...hooks].sort((a, b) => (b.scrollStopScore || 0) - (a.scrollStopScore || 0));
  const best = sorted[0];

  return {
    hook: best,
    passedThreshold: (best.scrollStopScore || 0) >= threshold,
    score: best.scrollStopScore || 0,
    threshold,
    allScores: hooks.map(h => ({
      type: h.typeName,
      score: h.scrollStopScore || 0,
      reason: h.evaluationReason || 'Değerlendirilmedi',
    })),
  };
}

// ─── Hook Test Raporu Oluştur ──────────────────────────────────────────────
export function createHookTestReport(hooks, selectedHook, threshold, roundNumber = 1) {
  return {
    timestamp: new Date().toISOString(),
    roundNumber,
    threshold,
    totalCandidates: hooks.length,
    selectedHook: {
      type: selectedHook.typeName,
      text: selectedHook.text,
      score: selectedHook.scrollStopScore,
      reason: selectedHook.evaluationReason,
    },
    allScores: hooks.map(h => ({
      type: h.typeName,
      score: h.scrollStopScore || 0,
      text: h.text,
    })),
    passedThreshold: (selectedHook.scrollStopScore || 0) >= threshold,
    recommendation: (selectedHook.scrollStopScore || 0) >= threshold
      ? `✓ "${selectedHook.typeName}" hook ${selectedHook.scrollStopScore} puanla eşik değeri (${threshold}) geçti. Yayınlamaya hazır.`
      : `' "${selectedHook.typeName}" hook ${selectedHook.scrollStopScore} puanla eşik değeri (${threshold}) geçemedi. Yeni hook seti üretiliyor...`,
  };
}

// ─── Iteratif Hook Üretim (Eşik Geçene Kadar) ──────────────────────────────
export async function generateHooksUntilThreshold(topic, category, threshold = 85, maxRounds = 3) {
  console.log(`🎣 Hook üretimi başlıyor (Eşik: ${threshold}, Max Round: ${maxRounds})`);

  const reports = [];
  let round = 0;

  while (round < maxRounds) {
    round++;
    console.log(`\n📍 Round ${round}/${maxRounds}`);

    // 5 adaylı hook seti üret
    const hooks = generateFiveHookCandidates(topic, category);

    // Gemini'ye değerlendir
    const evaluatedHooks = await evaluateHooksWithGemini(hooks);

    // En iyisini seç
    const best = evaluatedHooks.reduce((prev, current) =>
      (prev.scrollStopScore || 0) > (current.scrollStopScore || 0) ? prev : current
    );

    const report = createHookTestReport(evaluatedHooks, best, threshold, round);
    reports.push(report);

    console.log(`  Skor: ${best.scrollStopScore}/${threshold}`);

    if ((best.scrollStopScore || 0) >= threshold) {
      console.log(`✓ Eşik değer geçildi! Seçilen hook: "${best.typeName}"`);
      return {
        success: true,
        selectedHook: best,
        roundsUsed: round,
        reports,
      };
    }

    console.log(`' Eşik geçilmedi, yeni round başlıyor...`);
  }

  // Max round'a ulaşıldı, en iyi hook'u döndür
  const allHooks = reports.flatMap(r => r.allScores);
  const bestOverall = allHooks.reduce((prev, current) =>
    (prev.score || 0) > (current.score || 0) ? prev : current
  );

  console.log(`' Max round'a ulaşıldı. En iyi hook: "${bestOverall.type}" (${bestOverall.score})`);

  return {
    success: false,
    selectedHook: bestOverall,
    roundsUsed: round,
    reports,
    note: 'Eşik değer geçilmedi ancak en iyi hook seçildi',
  };
}

// ─── Hook Performans Analizi ────────────────────────────────────────────────
export function analyzeHookPerformance(reports) {
  const typeScores = {};

  for (const report of reports) {
    for (const score of report.allScores) {
      if (!typeScores[score.type]) {
        typeScores[score.type] = { scores: [], avgScore: 0 };
      }
      typeScores[score.type].scores.push(score.score);
    }
  }

  // Ortalama hesapla
  for (const [type, data] of Object.entries(typeScores)) {
    const sum = data.scores.reduce((a, b) => a + b, 0);
    data.avgScore = sum / data.scores.length;
  }

  // Sırala
  const sorted = Object.entries(typeScores)
    .map(([type, data]) => ({
      type,
      avgScore: Math.round(data.avgScore),
      attempts: data.scores.length,
    }))
    .sort((a, b) => b.avgScore - a.avgScore);

  return {
    bestPerformingHook: sorted[0],
    allHookPerformance: sorted,
    recommendation: `"${sorted[0].type}" hook türü ortalama ${sorted[0].avgScore} puan alıyor. Bunu kullanmaya devam et.`,
  };
}
