/**
 * Music Engine v2 — Sonic Mastery (Ses Ustalığı)
 * ================================================
 * Müzik artık sadece "arka plan" değil, bir "Ses Tasarımcı" gibi çalışıyor
 * - Dinamik Frekans Ducking (Seslendirme sırasında müzik otomatik kısılır)
 * - Vurgu Senkronizasyonu (Önemli anlar müzikle vurgulanır)
 * - Duygusal Müzik Eşleştirme (Metin duygusu müzik seçimini belirler)
 */

import fs from 'fs';
import path from 'path';

// ─── Müzik Kategorileri ve Duygusal Eşleştirme ────────────────────────────
const MUSIC_CATEGORIES = {
  motivation: {
    name: 'Motivasyon',
    emotions: ['aspiration', 'relief', 'shock'],
    musicStyles: ['epic', 'inspirational', 'crescendo'],
    frequency: {
      voiceoverDuck: 0.4, // Seslendirme sırasında %40 kısılır
      emphasisBump: 1.3, // Vurgu anlarında %30 artırılır
    },
  },
  psychology: {
    name: 'Psikoloji',
    emotions: ['curiosity', 'fear', 'shock'],
    musicStyles: ['dark', 'mysterious', 'ambient'],
    frequency: {
      voiceoverDuck: 0.35,
      emphasisBump: 1.25,
    },
  },
  health: {
    name: 'Sağlık',
    emotions: ['relief', 'aspiration'],
    musicStyles: ['zen', 'minimalist', 'nature'],
    frequency: {
      voiceoverDuck: 0.5,
      emphasisBump: 1.15,
    },
  },
  shock: {
    name: 'Şok',
    emotions: ['shock', 'fear', 'curiosity'],
    musicStyles: ['suspense', 'fast', 'reverse'],
    frequency: {
      voiceoverDuck: 0.3,
      emphasisBump: 1.4,
    },
  },
  knowledge: {
    name: 'Bilgi',
    emotions: ['curiosity', 'relief'],
    musicStyles: ['educational', 'fast', 'uplifting'],
    frequency: {
      voiceoverDuck: 0.4,
      emphasisBump: 1.2,
    },
  },
  finance: {
    name: 'Finans',
    emotions: ['aspiration', 'relief'],
    musicStyles: ['professional', 'dynamic', 'uplifting'],
    frequency: {
      voiceoverDuck: 0.45,
      emphasisBump: 1.25,
    },
  },
};

// ─── Müzik Seçimi (Duygusal Eşleştirme ile) ────────────────────────────────
export function selectMusicByEmotion(category, dominantEmotion) {
  const categoryData = MUSIC_CATEGORIES[category];
  if (!categoryData) return null;

  const musicDir = path.join(process.cwd(), 'storage', 'music', category);
  
  if (!fs.existsSync(musicDir)) {
    console.warn(`' Müzik klasörü bulunamadı: ${musicDir}`);
    return null;
  }

  const musicFiles = fs.readdirSync(musicDir).filter(f => f.endsWith('.mp3'));
  
  if (musicFiles.length === 0) {
    console.warn(`' ${category} kategorisinde müzik bulunamadı`);
    return null;
  }

  // Duyguya uygun müzik seç
  let selectedMusic = musicFiles[0];
  for (const file of musicFiles) {
    if (file.toLowerCase().includes(dominantEmotion?.toLowerCase() || '')) {
      selectedMusic = file;
      break;
    }
  }

  return {
    category,
    emotion: dominantEmotion,
    musicFile: path.join(musicDir, selectedMusic),
    musicName: selectedMusic,
    duckingLevel: categoryData.frequency.voiceoverDuck,
    emphasisBump: categoryData.frequency.emphasisBump,
  };
}

// ─── Dinamik Frekans Ducking (Seslendirme Sırasında Müzik Kısılması) ────────
export function generateFrequencyDuckingFilter(duckingLevel = 0.4) {
  // FFmpeg kompleks filtreleri için ducking parametreleri
  return {
    filterType: 'volume',
    duckingLevel, // 0.4 = %40 kısılır (0.6 seviyesinde kalır)
    ffmpegFilter: `volume=${duckingLevel}:eval=frame`,
    description: `Seslendirme sırasında müzik ${Math.round((1 - duckingLevel) * 100)}% kısılacak`,
  };
}

// ─── Vurgu Senkronizasyonu (Önemli Anlar Müzikle Vurgulanır) ───────────────
export function generateEmphasisSync(emphasisBump = 1.2, startSecond, endSecond) {
  // Belirtilen saniyeler arasında müzik sesini artır
  return {
    filterType: 'volume',
    emphasisBump,
    startSecond,
    endSecond,
    ffmpegFilter: `volume=${emphasisBump}:eval=frame`,
    description: `${startSecond}-${endSecond}. saniyeler arasında müzik ${Math.round((emphasisBump - 1) * 100)}% artırılacak`,
  };
}

// ─── Müzik Layering (Katmanlama) ────────────────────────────────────────────
export function createMusicLayers(primaryMusic, secondaryMusic = null) {
  return {
    primary: {
      file: primaryMusic,
      volume: 1.0,
      description: 'Ana müzik katmanı',
    },
    secondary: secondaryMusic ? {
      file: secondaryMusic,
      volume: 0.3,
      description: 'Arka plan katmanı (hafif)',
    } : null,
    combined: {
      description: 'Her iki katman birleştirildi',
      ffmpegCommand: secondaryMusic
        ? `[0:a]volume=1.0[a1];[1:a]volume=0.3[a2];[a1][a2]amix=inputs=2:duration=longest[out]`
        : null,
    },
  };
}

// ─── Müzik Fade-In/Out (Yumuşak Geçiş) ──────────────────────────────────────
export function generateMusicFade(duration = 15, fadeInDuration = 1, fadeOutDuration = 1) {
  return {
    fadeIn: {
      duration: fadeInDuration,
      ffmpegFilter: `afade=t=in:st=0:d=${fadeInDuration}`,
      description: `${fadeInDuration} saniyede müzik yavaşça başlayacak`,
    },
    fadeOut: {
      duration: fadeOutDuration,
      startSecond: duration - fadeOutDuration,
      ffmpegFilter: `afade=t=out:st=${duration - fadeOutDuration}:d=${fadeOutDuration}`,
      description: `Son ${fadeOutDuration} saniyede müzik yavaşça bitecek`,
    },
    combined: {
      ffmpegFilter: `afade=t=in:st=0:d=${fadeInDuration},afade=t=out:st=${duration - fadeOutDuration}:d=${fadeOutDuration}`,
    },
  };
}

// ─── Müzik Kalitesi Analizi ─────────────────────────────────────────────────
export function analyzeMusicQuality(musicFile) {
  // Müzik dosyasının teknik özelliklerini kontrol et
  if (!fs.existsSync(musicFile)) {
    return { error: 'Müzik dosyası bulunamadı' };
  }

  const stats = fs.statSync(musicFile);
  const fileSizeKB = stats.size / 1024;

  return {
    file: musicFile,
    fileSizeKB: Math.round(fileSizeKB),
    quality: fileSizeKB > 5000 ? 'High (320kbps+)' : fileSizeKB > 2000 ? 'Medium (192kbps)' : 'Low (128kbps)',
    recommendation: fileSizeKB > 5000
      ? '✓ Müzik kalitesi mükemmel'
      : fileSizeKB > 2000
      ? '' Müzik kalitesi iyi ama daha yüksek olabilir'
      : '❌ Müzik kalitesi düşük, daha iyi bir versiyon kullan',
  };
}

// ─── Sonic Mastery Raporu ───────────────────────────────────────────────────
export function generateSonicMasteryReport(category, dominantEmotion, videoScript) {
  const musicSelection = selectMusicByEmotion(category, dominantEmotion);
  const duckingFilter = generateFrequencyDuckingFilter(musicSelection?.duckingLevel || 0.4);
  const fadeSettings = generateMusicFade(15, 1, 1);
  const musicQuality = analyzeMusicQuality(musicSelection?.musicFile);

  return {
    timestamp: new Date().toISOString(),
    category,
    emotion: dominantEmotion,
    musicSelection,
    audioProcessing: {
      ducking: duckingFilter,
      fade: fadeSettings,
      quality: musicQuality,
    },
    recommendation: `✓ ${musicSelection?.musicName} seçildi. Seslendirme sırasında ${Math.round((1 - (musicSelection?.duckingLevel || 0.4)) * 100)}% kısılacak.`,
  };
}

// ─── FFmpeg Kompleks Ses Filtresi Oluştur ───────────────────────────────────
export function buildComplexAudioFilter(duckingLevel = 0.4, emphasisPoints = []) {
  let filterChain = [];

  // Temel ducking
  filterChain.push(`volume=${duckingLevel}:eval=frame`);

  // Vurgu noktaları
  for (const point of emphasisPoints) {
    filterChain.push(`volume=${point.emphasisBump}:eval=frame`);
  }

  // Fade-in ve fade-out
  filterChain.push(`afade=t=in:st=0:d=1,afade=t=out:st=14:d=1`);

  return filterChain.join(',');
}

// ─── Müzik Kütüphanesi Durumu ───────────────────────────────────────────────
export function getMusicLibraryStatus() {
  const musicBasePath = path.join(process.cwd(), 'storage', 'music');
  const status = {};

  for (const category of Object.keys(MUSIC_CATEGORIES)) {
    const categoryPath = path.join(musicBasePath, category);
    const musicFiles = fs.existsSync(categoryPath) 
      ? fs.readdirSync(categoryPath).filter(f => f.endsWith('.mp3'))
      : [];

    status[category] = {
      category: MUSIC_CATEGORIES[category].name,
      musicCount: musicFiles.length,
      musicFiles,
      status: musicFiles.length > 0 ? '✓ Hazır' : '' Müzik yok',
    };
  }

  return {
    timestamp: new Date().toISOString(),
    totalCategories: Object.keys(MUSIC_CATEGORIES).length,
    categories: status,
    recommendation: Object.values(status).every(s => s.musicCount > 0)
      ? '✓ Müzik kütüphanesi tam donanımlı'
      : '' Bazı kategorilerde müzik eksik',
  };
}
